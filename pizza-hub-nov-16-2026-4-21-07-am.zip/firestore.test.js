const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validUserPayload(uid, overrides = {}) {
  return {
    userId: uid,
    displayName: "Alice Rahman",
    email: "alice@example.com",
    phone: "01974378075",
    deliveryAddress: "Zindabazar, Sylhet",
    role: "customer",
    preferredLanguage: "en",
    darkMode: "system",
    biometricEnabled: false,
    lowBandwidthSync: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

function validOrderPayload(uid, overrides = {}) {
  return {
    userId: uid,
    customerName: "Alice Rahman",
    customerPhone: "01974378075",
    deliveryAddress: "G-66 Eastern Plaza, Ambarkhana, Sylhet",
    itemsSummary: "1x Cheese Blast Pizza (Regular)",
    itemCount: 1,
    subtotal: 420,
    deliveryFee: 50,
    discount: 0,
    totalAmount: 470,
    paymentMethod: "bkash",
    paymentStatus: "paid",
    paymentRef: "BKASH-TXN-1001",
    orderStatus: "placed",
    riderName: "",
    riderPhone: "",
    etaMinutes: 35,
    deliveryNotes: "Ring bell",
    encryptedPayloadHash: "sha256_abc123",
    syncVersion: 1,
    lastConflictNote: "",
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

function validMenuItemPayload(uid, overrides = {}) {
  return {
    name: "Cheese Blast Pizza",
    description: "Loaded mozzarella and house special sauce",
    category: "pizza",
    price: 420,
    premiumPrice: 680,
    imageKey: "img_pizza_category",
    imageUrl: "https://pizzahubsylhet.com/images/cheese-blast.jpg",
    ingredients: ["Dough", "Mozzarella", "Grilled Chicken"],
    servingSize: "2 Slices (250g)",
    calories: 640,
    proteinGrams: 31,
    carbsGrams: 56,
    fatGrams: 32,
    available: true,
    prepMinutes: 20,
    isVeg: false,
    ratingAvg: 4.8,
    reviewCount: 12,
    version: 1,
    updatedBy: uid,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

function validUserOrderPayload(uid, orderId, overrides = {}) {
  return {
    orderId: orderId,
    userId: uid,
    customerName: "Alice Rahman",
    deliveryAddress: "G-66 Eastern Plaza, Ambarkhana, Sylhet",
    itemsSummary: "1x Cheese Blast Pizza (Regular)",
    itemCount: 1,
    subtotal: 420,
    deliveryFee: 50,
    discount: 0,
    totalAmount: 470,
    paymentMethod: "bkash",
    paymentStatus: "paid",
    paymentRef: "BKASH-TXN-1001",
    orderStatus: "placed",
    encryptedPayloadHash: "sha256_abc123",
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read menu, orders, users, or reviews", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("menu_items").get());
  await assertFails(unauthDb.collection("orders").get());
  await assertFails(unauthDb.collection("user_orders").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("reviews").get());
});

test("User profile: owner can create customer profile, cannot self-assign admin or inject ghost field", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID))
  );
  await assertFails(
    aliceDb.collection("users").doc("alice_admin_attempt").set(
      validUserPayload("alice_admin_attempt", { role: "admin" })
    )
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({ role: "admin" })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({ isVerified: true })
  );
});

test("PII isolation: Bob cannot read or list Alice's user profile or orders", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const adminDb = ctx.firestore();
    await adminDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID));
    await adminDb.collection("orders").doc("order_alice_1").set(validOrderPayload(ALICE_UID));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("orders").doc("order_alice_1").get());
  await assertFails(bobDb.collection("orders").get());

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("orders").where("userId", "==", ALICE_UID).get());
});

test("Email spoofing test: unverified admin email is rejected for admin menu creation", async () => {
  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: "monkeydesignersagency@gmail.com",
    email_verified: false,
  }).firestore();
  await assertFails(
    spoofDb.collection("menu_items").doc("pizza_1").set(validMenuItemPayload("spoof_uid"))
  );
});

test("Verified bootstrapped admin can manage menu items and update any order", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("orders").doc("order_alice_2").set(validOrderPayload(ALICE_UID));
  });

  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "monkeydesignersagency@gmail.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(
    adminDb.collection("menu_items").doc("pizza_cheese_blast").set(validMenuItemPayload(ADMIN_UID))
  );
  await assertSucceeds(
    adminDb.collection("orders").doc("order_alice_2").update({
      orderStatus: "out_for_delivery",
      riderName: "Karim Mia",
      riderPhone: "01711000000",
      etaMinutes: 15,
      syncVersion: 2,
      updatedAt: new Date(),
    })
  );
});

test("Customer order lifecycle: can cancel placed order, cannot cancel delivered order", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("orders").doc("order_placed").set(validOrderPayload(ALICE_UID));
    await db.collection("orders").doc("order_done").set(validOrderPayload(ALICE_UID, { orderStatus: "delivered" }));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("orders").doc("order_placed").update({
      orderStatus: "cancelled",
      syncVersion: 2,
      lastConflictNote: "Customer cancelled",
      updatedAt: new Date(),
    })
  );
  await assertFails(
    aliceDb.collection("orders").doc("order_done").update({
      orderStatus: "cancelled",
      syncVersion: 2,
      lastConflictNote: "Late cancel",
      updatedAt: new Date(),
    })
  );
});

test("Reviews & append-only audit logs: owner creates, audit log immutable", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("reviews").doc("rev_1").set({
      userId: ALICE_UID,
      authorName: "Alice",
      menuItemId: "pizza_cheese_blast",
      menuItemName: "Cheese Blast Pizza",
      rating: 5,
      comment: "Best cheesy crust in Sylhet!",
      orderId: "order_1",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("audit_logs").doc("log_1").set({
      userId: ALICE_UID,
      actorEmail: "alice@example.com",
      action: "ORDER_SYNC",
      entityType: "order",
      entityId: "order_1",
      resolutionStrategy: "LWW",
      details: "Synced after reconnect",
      createdAt: new Date(),
    })
  );
  await assertFails(aliceDb.collection("audit_logs").doc("log_1").update({ details: "tampered" }));
  await assertFails(aliceDb.collection("audit_logs").doc("log_1").delete());
});

test("User orders purchase history collection: owner access and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("user_orders").doc("ord_u_1").set(validUserOrderPayload(ALICE_UID, "ord_u_1"))
  );
  await assertSucceeds(
    aliceDb.collection("user_orders").where("userId", "==", ALICE_UID).get()
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("user_orders").doc("ord_u_1").get());
  await assertFails(bobDb.collection("user_orders").get());
  await assertFails(
    bobDb.collection("user_orders").doc("ord_u_2").set(validUserOrderPayload(ALICE_UID, "ord_u_2"))
  );
});

test("User favorites: owner can update favoriteItemIds, other user cannot tamper", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(
      validUserPayload(ALICE_UID, { favoriteItemIds: ["pizza_cheese_blast"] })
    )
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      favoriteItemIds: ["pizza_cheese_blast", "burger_smash_hub"],
      updatedAt: new Date(),
    })
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      favoriteItemIds: [],
      updatedAt: new Date(),
    })
  );
});

test("Delivery coordinates: admin can update riderLat/riderLng, customer and other users cannot", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("orders").doc("order_gps_1").set(
      validOrderPayload(ALICE_UID, {
        riderLat: 24.9036,
        riderLng: 91.8697,
        destinationLat: 24.8949,
        destinationLng: 91.8687,
      })
    );
  });

  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "monkeydesignersagency@gmail.com",
    email_verified: true,
  }).firestore();
  await assertSucceeds(
    adminDb.collection("orders").doc("order_gps_1").update({
      orderStatus: "out_for_delivery",
      riderLat: 24.8992,
      riderLng: 91.8691,
      etaMinutes: 12,
      syncVersion: 2,
      updatedAt: new Date(),
    })
  );

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("orders").doc("order_gps_1").update({
      riderLat: 24.8950,
      riderLng: 91.8688,
      updatedAt: new Date(),
    })
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("orders").doc("order_gps_1").update({
      riderLat: 24.8950,
      updatedAt: new Date(),
    })
  );
});
