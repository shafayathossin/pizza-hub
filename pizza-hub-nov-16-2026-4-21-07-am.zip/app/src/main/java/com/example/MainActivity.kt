package com.example

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalPizza
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.LocalPizza
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.StoreInfo
import com.example.data.remote.FirestoreProvider
import com.example.data.repository.PizzaHubRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutGoogle
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.OrdersAndTrackingScreen
import com.example.ui.screens.ProfileAndSettingsScreen
import com.example.ui.screens.ReviewsScreen
import com.example.ui.theme.PizzaHubTheme
import com.example.ui.viewmodel.PizzaHubViewModel
import com.example.ui.viewmodel.ShoppingCartViewModel
import com.example.ui.viewmodel.UiState
import com.example.util.AppPreferences
import com.example.util.ConnectivityObserver
import com.example.util.LocalAppSettings
import com.example.util.NotificationHelper
import com.example.util.stringsFor
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
  val listener = FirebaseAuth.AuthStateListener { auth ->
    trySend(auth.currentUser)
  }
  addAuthStateListener(listener)
  awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : FragmentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    NotificationHelper.ensureChannel(this)
    setContent {
      val context = LocalContext.current
      val prefs = remember { AppPreferences(context.applicationContext) }
      val localSettings by prefs.settingsFlow.collectAsStateWithLifecycle(initialValue = LocalAppSettings())

      PizzaHubTheme(darkModePreference = localSettings.darkMode) {
        AppRootNavigation()
      }
    }
  }
}

@Composable
fun AppRootNavigation(auth: FirebaseAuth = Firebase.auth) {
  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
  val user = currentUser

  if (user == null) {
    AuthScreen(onAuthSuccess = {})
  } else {
    key(user.uid) {
      MainPizzaHubScreen(
        currentUserId = user.uid,
        userEmail = user.email.orEmpty(),
        userDisplayName = user.displayName.orEmpty(),
        emailVerified = user.isEmailVerified,
      )
    }
  }
}

private data class NavTab(
  val key: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainPizzaHubScreen(
  currentUserId: String,
  userEmail: String,
  userDisplayName: String,
  emailVerified: Boolean,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }

  val viewModel: PizzaHubViewModel = viewModel(
    key = currentUserId,
    factory = viewModelFactory {
      initializer {
        val app = checkNotNull(this[APPLICATION_KEY])
        val db = FirestoreProvider.getDb(app)
        val repo = PizzaHubRepository(db, Firebase.auth)
        PizzaHubViewModel(
          repository = repo,
          connectivityObserver = ConnectivityObserver(app),
          appPreferences = AppPreferences(app),
          currentUserId = currentUserId,
          userEmail = userEmail,
          userDisplayName = userDisplayName,
          emailVerified = emailVerified,
        )
      }
    },
  )

  val cartViewModel: ShoppingCartViewModel = viewModel(
    key = "cart_$currentUserId",
    factory = viewModelFactory {
      initializer { ShoppingCartViewModel() }
    },
  )

  val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
  val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
  val localSettings by viewModel.localSettings.collectAsStateWithLifecycle()
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val favoriteItemIds by viewModel.favoriteItemIds.collectAsStateWithLifecycle()
  val menuState by viewModel.menuState.collectAsStateWithLifecycle()
  val ordersState by viewModel.ordersState.collectAsStateWithLifecycle()
  val cart by cartViewModel.items.collectAsStateWithLifecycle()
  val cartUiState by cartViewModel.uiState.collectAsStateWithLifecycle()
  val promoFeedback by cartViewModel.promoFeedback.collectAsStateWithLifecycle()
  val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
  val orderStatusAlert by viewModel.orderStatusAlert.collectAsStateWithLifecycle()

  val strings = remember(localSettings.language) { stringsFor(localSettings.language) }
  var currentTabIndex by remember { mutableIntStateOf(0) }
  var showFavoritesScreen by remember { mutableStateOf(false) }
  var showOrdersHistoryTab by remember { mutableStateOf(false) }
  var pendingReviewOrderId by remember { mutableStateOf<String?>(null) }
  val snackbarHostState = remember { SnackbarHostState() }

  val tabs = remember(isAdmin, strings) {
    buildList {
      add(NavTab("menu", strings.menuTab, Icons.Filled.LocalPizza, Icons.Outlined.LocalPizza))
      add(NavTab("orders", strings.ordersTab, Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong))
      add(NavTab("reviews", strings.reviewsTab, Icons.Filled.Star, Icons.Outlined.StarBorder))
      add(NavTab("profile", strings.profileTab, Icons.Filled.Person, Icons.Outlined.Person))
      if (isAdmin) {
        add(NavTab("admin", strings.adminTab, Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings))
      }
    }
  }

  val safeIndex = currentTabIndex.coerceIn(0, (tabs.size - 1).coerceAtLeast(0))

  BackHandler(enabled = showFavoritesScreen || safeIndex != 0) {
    if (showFavoritesScreen) {
      showFavoritesScreen = false
    } else {
      currentTabIndex = 0
    }
  }

  LaunchedEffect(statusMessage) {
    val msg = statusMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearStatusMessage()
    }
  }

  LaunchedEffect(orderStatusAlert) {
    val alertOrder = orderStatusAlert
    if (alertOrder != null) {
      NotificationHelper.notifyOrderStatus(
        context = context,
        orderId = alertOrder.id,
        title = "Pizza Hub Order Update",
        message = "Order #${alertOrder.id.take(6).uppercase()} is now ${alertOrder.orderStatus.replace('_', ' ')}",
      )
      viewModel.clearOrderStatusAlert()
    }
  }

  val hasPendingWrites = (ordersState as? UiState.Success)?.data?.hasPendingWrites == true ||
    (menuState as? UiState.Success)?.data?.hasPendingWrites == true

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val isExpanded = maxWidth >= 600.dp

    Scaffold(
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        Column(modifier = Modifier.background(MaterialTheme.colorScheme.surface).statusBarsPadding()) {
          TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            title = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  color = Color(0xFFFEFEFE),
                  shape = RoundedCornerShape(10.dp),
                  tonalElevation = 1.dp,
                  modifier = Modifier.size(38.dp),
                ) {
                  Image(
                    painter = painterResource(id = R.drawable.img_pizza_hub_logo),
                    contentDescription = "Pizza Hub logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(3.dp),
                  )
                }
                Spacer(Modifier.width(10.dp))
                Column {
                  Text(
                    text = StoreInfo.BRAND_NAME,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    text = "${StoreInfo.SUBTITLE} • ${StoreInfo.WEBSITE}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              }
            },
            actions = {
              // Dedicated Favorites quick-access button
              IconButton(
                onClick = { showFavoritesScreen = !showFavoritesScreen },
                modifier = Modifier.testTag("top_favorites_button"),
              ) {
                Icon(
                  imageVector = if (showFavoritesScreen || favoriteItemIds.isNotEmpty()) {
                    Icons.Filled.Favorite
                  } else {
                    Icons.Outlined.FavoriteBorder
                  },
                  contentDescription = strings.favoritesLabel,
                  tint = if (showFavoritesScreen || favoriteItemIds.isNotEmpty()) {
                    Color(0xFFE53935)
                  } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                  },
                )
              }

              // Live Sync & Connectivity Badge
              Surface(
                color = when {
                  !isOnline -> MaterialTheme.colorScheme.errorContainer
                  hasPendingWrites -> MaterialTheme.colorScheme.secondaryContainer
                  else -> MaterialTheme.colorScheme.tertiaryContainer
                },
                shape = RoundedCornerShape(50),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = when {
                      !isOnline -> Icons.Filled.CloudOff
                      hasPendingWrites -> Icons.Filled.Sync
                      else -> Icons.Filled.CloudDone
                    },
                    contentDescription = "Sync status",
                    modifier = Modifier.size(14.dp),
                  )
                  Spacer(Modifier.width(4.dp))
                  Text(
                    text = when {
                      !isOnline -> "Offline"
                      hasPendingWrites -> strings.pendingSyncLabel
                      else -> strings.syncedLabel
                    },
                    style = MaterialTheme.typography.labelSmall,
                  )
                }
              }

              IconButton(
                onClick = {
                  val next = if (localSettings.darkMode == "dark") "light" else "dark"
                  viewModel.setQuickDarkMode(next)
                },
                modifier = Modifier.testTag("top_dark_mode_toggle"),
              ) {
                Icon(
                  imageVector = if (localSettings.darkMode == "dark") Icons.Filled.LightMode else Icons.Filled.DarkMode,
                  contentDescription = "Toggle theme",
                )
              }
            },
          )

          AnimatedVisibility(visible = !isOnline) {
            Surface(
              color = MaterialTheme.colorScheme.errorContainer,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = strings.offlineBanner,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
              )
            }
          }
        }
      },
      bottomBar = {
        if (!isExpanded) {
          NavigationBar {
            tabs.forEachIndexed { index, tab ->
              NavigationBarItem(
                selected = !showFavoritesScreen && safeIndex == index,
                onClick = {
                  showFavoritesScreen = false
                  currentTabIndex = index
                },
                icon = {
                  Icon(
                    imageVector = if (!showFavoritesScreen && safeIndex == index) tab.selectedIcon else tab.unselectedIcon,
                    contentDescription = tab.label,
                  )
                },
                label = { Text(tab.label, maxLines = 1) },
                modifier = Modifier.testTag("nav_tab_${tab.key}"),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding),
      ) {
        if (isExpanded) {
          NavigationRail(modifier = Modifier.fillMaxHeight()) {
            tabs.forEachIndexed { index, tab ->
              NavigationRailItem(
                selected = !showFavoritesScreen && safeIndex == index,
                onClick = {
                  showFavoritesScreen = false
                  currentTabIndex = index
                },
                icon = {
                  Icon(
                    imageVector = if (!showFavoritesScreen && safeIndex == index) tab.selectedIcon else tab.unselectedIcon,
                    contentDescription = tab.label,
                  )
                },
                label = { Text(tab.label) },
                modifier = Modifier.testTag("nav_rail_${tab.key}"),
              )
            }
          }
        }

        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.TopCenter,
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .widthIn(max = 960.dp),
          ) {
            if (showFavoritesScreen) {
              FavoritesScreen(
                menuState = menuState,
                favoriteItemIds = favoriteItemIds,
                cart = cart,
                lowBandwidthSync = localSettings.lowBandwidthSync,
                strings = strings,
                onBackToMenu = {
                  showFavoritesScreen = false
                  currentTabIndex = 0
                },
                onToggleFavorite = viewModel::toggleFavorite,
                onAddToCart = { item, isPremium, extraCheese, qty ->
                  cartViewModel.addItem(item, isPremium, extraCheese, qty)
                  viewModel.showStatusMessage("Added ${item.name} to cart")
                },
                onDecrementMenuItem = cartViewModel::decrementOrRemoveMenuItem,
              )
            } else when (tabs[safeIndex].key) {
              "menu" -> MenuScreen(
                menuState = menuState,
                selectedCategory = selectedCategory,
                searchQuery = searchQuery,
                cart = cart,
                cartUiState = cartUiState,
                promoFeedback = promoFeedback,
                favoriteItemIds = favoriteItemIds,
                userProfile = userProfile,
                lowBandwidthSync = localSettings.lowBandwidthSync,
                biometricEnabled = localSettings.biometricEnabled,
                strings = strings,
                onSelectCategory = viewModel::setCategory,
                onSearchQueryChange = viewModel::setSearchQuery,
                onToggleFavorite = viewModel::toggleFavorite,
                onOpenFavoritesScreen = { showFavoritesScreen = true },
                onAddToCart = { item, isPremium, extraCheese, qty ->
                  cartViewModel.addItem(item, isPremium, extraCheese, qty)
                  viewModel.showStatusMessage("Added ${item.name} to cart")
                },
                onDecrementMenuItem = cartViewModel::decrementOrRemoveMenuItem,
                onUpdateCartQuantity = cartViewModel::updateQuantity,
                onRemoveCartItem = cartViewModel::removeItem,
                onApplyPromoCode = { code -> cartViewModel.applyPromoCode(code) },
                onRemovePromoCode = cartViewModel::removePromoCode,
                onClearCart = cartViewModel::clearCart,
                onPlaceOrder = { items, name, phone, addr, method, ref, promo, notes, onSuccess ->
                  viewModel.placeOrder(items, name, phone, addr, method, ref, promo, notes) { orderId ->
                    cartViewModel.clearCart()
                    onSuccess(orderId)
                  }
                },
                onOrderPlacedNavigate = {
                  showOrdersHistoryTab = false
                  currentTabIndex = 1
                },
              )
              "orders" -> {
                val userOrderHistoryState by viewModel.userOrderHistoryState.collectAsStateWithLifecycle()
                val reviewsState by viewModel.reviewsState.collectAsStateWithLifecycle()
                OrdersAndTrackingScreen(
                  ordersState = ordersState,
                  userOrderHistoryState = userOrderHistoryState,
                  reviewsState = reviewsState,
                  menuState = menuState,
                  currentUserId = currentUserId,
                  encryptedVaultReceipt = localSettings.encryptedVaultReceipt,
                  strings = strings,
                  showHistoryTab = showOrdersHistoryTab,
                  onSelectHistoryTab = { showOrdersHistoryTab = it },
                  onCancelOrder = viewModel::cancelOrder,
                  onReorderSummary = { summary ->
                    val matched = viewModel.matchedItemsForSummary(summary)
                    matched.forEach { cartViewModel.addItem(it) }
                    viewModel.showStatusMessage("Loaded ${matched.size} item(s) into cart")
                    currentTabIndex = 0
                  },
                  onSubmitOrderReview = viewModel::submitReview,
                  onReviewOrderItem = { orderId ->
                    pendingReviewOrderId = orderId
                    currentTabIndex = 2
                  },
                )
              }
              "reviews" -> {
                val reviewsState by viewModel.reviewsState.collectAsStateWithLifecycle()
                ReviewsScreen(
                  reviewsState = reviewsState,
                  menuState = menuState,
                  currentUserId = currentUserId,
                  isAdmin = isAdmin,
                  strings = strings,
                  initialOrderIdForReview = pendingReviewOrderId,
                  onClearInitialOrderId = { pendingReviewOrderId = null },
                  onSubmitReview = viewModel::submitReview,
                  onDeleteReview = viewModel::deleteReview,
                )
              }
              "profile" -> {
                val auditLogsState by viewModel.auditLogsState.collectAsStateWithLifecycle()
                ProfileAndSettingsScreen(
                  userProfile = userProfile,
                  userEmail = userEmail,
                  currentUserId = currentUserId,
                  isAdmin = isAdmin,
                  localSettings = localSettings,
                  auditLogsState = auditLogsState,
                  strings = strings,
                  onSaveProfile = viewModel::saveProfileAndSettings,
                  onQuickDarkMode = viewModel::setQuickDarkMode,
                  onQuickLanguage = viewModel::setQuickLanguage,
                  onOpenPurchaseHistory = {
                    showOrdersHistoryTab = true
                    currentTabIndex = 1
                  },
                  onSignOut = {
                    signOutGoogle(credentialManager, scope)
                  },
                )
              }
              "admin" -> {
                val adminOrdersState by viewModel.adminOrdersState.collectAsStateWithLifecycle()
                val auditLogsState by viewModel.auditLogsState.collectAsStateWithLifecycle()
                val admins by viewModel.adminsState.collectAsStateWithLifecycle()
                AdminDashboardScreen(
                  menuState = menuState,
                  adminOrdersState = adminOrdersState,
                  auditLogsState = auditLogsState,
                  admins = admins,
                  onSeedCatalog = viewModel::seedMenuCatalog,
                  onUpsertMenuItem = viewModel::upsertMenuItem,
                  onDeleteMenuItem = viewModel::deleteMenuItem,
                  onUpdateOrder = viewModel::adminUpdateOrder,
                  onGrantAdmin = viewModel::grantAdminAccess,
                )
              }
            }
          }
        }
      }
    }
  }
}
