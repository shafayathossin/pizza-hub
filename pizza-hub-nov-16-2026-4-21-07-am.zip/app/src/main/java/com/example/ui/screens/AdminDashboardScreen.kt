package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminEntry
import com.example.data.model.AuditLog
import com.example.data.model.MenuItem
import com.example.data.model.Order
import com.example.data.repository.SyncSnapshot
import com.example.ui.viewmodel.UiState
import com.example.util.ImageUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
  menuState: UiState<SyncSnapshot<MenuItem>>,
  adminOrdersState: UiState<SyncSnapshot<Order>>,
  auditLogsState: UiState<List<AuditLog>>,
  admins: List<AdminEntry>,
  onSeedCatalog: () -> Unit,
  onUpsertMenuItem: (String?, MenuItem) -> Unit,
  onDeleteMenuItem: (String) -> Unit,
  onUpdateOrder: (Order, String, String, String, String, Long, String, Double?, Double?) -> Unit,
  onGrantAdmin: (String, String, String) -> Unit,
) {
  var subTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("Overview", "Orders", "Menu & Photos", "Billing", "RBAC & Sync")

  val orders = (adminOrdersState as? UiState.Success)?.data?.items ?: emptyList()
  val menuItems = (menuState as? UiState.Success)?.data?.items ?: emptyList()
  val logs = (auditLogsState as? UiState.Success)?.data ?: emptyList()

  Column(modifier = Modifier.fillMaxSize()) {
    PrimaryScrollableTabRow(selectedTabIndex = subTab, edgePadding = 12.dp) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = subTab == index,
          onClick = { subTab = index },
          text = { Text(title) },
          modifier = Modifier.testTag("admin_subtab_$index"),
        )
      }
    }

    when (subTab) {
      0 -> AdminOverviewPane(orders = orders, menuCount = menuItems.size)
      1 -> AdminOrdersPane(orders = orders, onUpdateOrder = onUpdateOrder)
      2 -> AdminMenuPane(
        menuItems = menuItems,
        onSeedCatalog = onSeedCatalog,
        onUpsertMenuItem = onUpsertMenuItem,
        onDeleteMenuItem = onDeleteMenuItem,
      )
      3 -> AdminBillingPane(orders = orders, onUpdateOrder = onUpdateOrder)
      4 -> AdminRbacSyncPane(admins = admins, logs = logs, onGrantAdmin = onGrantAdmin)
    }
  }
}

@Composable
private fun AdminOverviewPane(orders: List<Order>, menuCount: Int) {
  val totalRevenue = orders.filter { it.orderStatus != "cancelled" }.sumOf { it.totalAmount }
  val activeCount = orders.count { it.orderStatus !in listOf("delivered", "cancelled") }
  val paidCount = orders.count { it.paymentStatus == "paid" }
  val avgOrder = if (orders.isNotEmpty()) totalRevenue / orders.size else 0L

  val statusCounts = listOf(
    "Placed" to orders.count { it.orderStatus == "placed" },
    "Baking" to orders.count { it.orderStatus in listOf("confirmed", "preparing") },
    "On Way" to orders.count { it.orderStatus == "out_for_delivery" },
    "Done" to orders.count { it.orderStatus == "delivered" },
  )

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Text("Real-Time Store Metrics", style = MaterialTheme.typography.headlineSmall)
    }
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        MetricKpiCard("Revenue", "৳$totalRevenue", Modifier.weight(1f))
        MetricKpiCard("Active Orders", "$activeCount", Modifier.weight(1f))
      }
    }
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        MetricKpiCard("Paid Invoices", "$paidCount / ${orders.size}", Modifier.weight(1f))
        MetricKpiCard("Avg Ticket / Items", "৳$avgOrder • $menuCount dishes", Modifier.weight(1f))
      }
    }
    item {
      Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Order Pipeline Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          val primaryColor = MaterialTheme.colorScheme.primary
          val trackColor = MaterialTheme.colorScheme.surfaceVariant
          val maxVal = (statusCounts.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)

          Canvas(modifier = Modifier.fillMaxWidth().height(150.dp)) {
            val barWidth = size.width / (statusCounts.size * 2f)
            statusCounts.forEachIndexed { idx, (_, count) ->
              val x = barWidth * (idx * 2f + 0.5f)
              drawRoundRect(
                color = trackColor,
                topLeft = Offset(x, 0f),
                size = Size(barWidth, size.height),
                cornerRadius = CornerRadius(14f, 14f),
              )
              val barHeight = (count.toFloat() / maxVal.toFloat()) * size.height
              if (barHeight > 0f) {
                drawRoundRect(
                  color = primaryColor,
                  topLeft = Offset(x, size.height - barHeight),
                  size = Size(barWidth, barHeight),
                  cornerRadius = CornerRadius(14f, 14f),
                )
              }
            }
          }

          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            statusCounts.forEach { (label, count) ->
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$count", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(label, style = MaterialTheme.typography.labelSmall)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun MetricKpiCard(title: String, value: String, modifier: Modifier = Modifier) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
  }
}

@Composable
private fun AdminOrdersPane(
  orders: List<Order>,
  onUpdateOrder: (Order, String, String, String, String, Long, String, Double?, Double?) -> Unit,
) {
  var editingOrder by remember { mutableStateOf<Order?>(null) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    if (orders.isEmpty()) {
      item {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
          Text("No customer orders placed yet.", modifier = Modifier.padding(20.dp))
        }
      }
    } else {
      items(orders, key = { it.id }) { order ->
        Card(shape = RoundedCornerShape(18.dp)) {
          Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("${order.customerName} (#${order.id.take(6)})", style = MaterialTheme.typography.titleMedium)
              Text("৳${order.totalAmount}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
            Text(order.itemsSummary, style = MaterialTheme.typography.bodyMedium)
            Text("Addr: ${order.deliveryAddress} • Tel: ${order.customerPhone}", style = MaterialTheme.typography.labelSmall)
            Text("Status: ${order.orderStatus} • Pay: ${order.paymentMethod}/${order.paymentStatus} • v${order.syncVersion}", style = MaterialTheme.typography.labelMedium)

            val nextStep = when (order.orderStatus) {
              "placed" -> "confirmed" to "Confirm"
              "confirmed" -> "preparing" to "Start Baking"
              "preparing" -> "out_for_delivery" to "Dispatch Rider"
              "out_for_delivery" -> "delivered" to "Mark Delivered"
              else -> null
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              if (nextStep != null) {
                Button(
                  onClick = {
                    val rider = order.riderName.ifBlank { "Rahim Rider" }
                    val rPhone = order.riderPhone.ifBlank { "01711-889900" }
                    val eta = if (nextStep.first == "delivered") 0L else (order.etaMinutes - 8L).coerceAtLeast(10L)
                    onUpdateOrder(order, nextStep.first, order.paymentStatus, rider, rPhone, eta, "Advanced to ${nextStep.first}", null, null)
                  },
                  modifier = Modifier.testTag("advance_order_${order.id}"),
                ) {
                  Text(nextStep.second)
                }
              }
              OutlinedButton(onClick = { editingOrder = order }) {
                Text("Edit / Rider")
              }
            }
            if (order.orderStatus !in listOf("delivered", "cancelled")) {
              OutlinedButton(
                onClick = {
                  val rider = order.riderName.ifBlank { "Rahim Rider" }
                  val rPhone = order.riderPhone.ifBlank { "01711-889900" }
                  val nextLat = order.riderLat + (order.destinationLat - order.riderLat) * 0.35
                  val nextLng = order.riderLng + (order.destinationLng - order.riderLng) * 0.35
                  val nextStatus = if (order.orderStatus in listOf("placed", "confirmed", "preparing")) "out_for_delivery" else order.orderStatus
                  val nextEta = (order.etaMinutes - 5L).coerceAtLeast(3L)
                  onUpdateOrder(
                    order,
                    nextStatus,
                    order.paymentStatus,
                    rider,
                    rPhone,
                    nextEta,
                    "Rider GPS moved closer",
                    nextLat,
                    nextLng,
                  )
                },
                modifier = Modifier.testTag("move_driver_${order.id}"),
              ) {
                Text("Move Driver Closer")
              }
            }
          }
        }
      }
    }
  }

  editingOrder?.let { order ->
    var status by remember { mutableStateOf(order.orderStatus) }
    var paymentStatus by remember { mutableStateOf(order.paymentStatus) }
    var riderName by remember { mutableStateOf(order.riderName) }
    var riderPhone by remember { mutableStateOf(order.riderPhone) }
    var etaText by remember { mutableStateOf(order.etaMinutes.toString()) }
    var riderLatText by remember { mutableStateOf(order.riderLat.toString()) }
    var riderLngText by remember { mutableStateOf(order.riderLng.toString()) }

    AlertDialog(
      onDismissRequest = { editingOrder = null },
      title = { Text("Manage Order #${order.id.take(6)}") },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Order Status", style = MaterialTheme.typography.labelLarge)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf("placed", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled")) { st ->
              FilterChip(selected = status == st, onClick = { status = st }, label = { Text(st) })
            }
          }
          Text("Payment Status", style = MaterialTheme.typography.labelLarge)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("pending", "paid", "refunded").forEach { pst ->
              FilterChip(selected = paymentStatus == pst, onClick = { paymentStatus = pst }, label = { Text(pst) })
            }
          }
          OutlinedTextField(value = riderName, onValueChange = { riderName = it }, label = { Text("Rider Name") })
          OutlinedTextField(value = riderPhone, onValueChange = { riderPhone = it }, label = { Text("Rider Phone") })
          OutlinedTextField(value = etaText, onValueChange = { etaText = it }, label = { Text("ETA (Minutes)") })
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = riderLatText,
              onValueChange = { riderLatText = it },
              label = { Text("Rider Lat") },
              modifier = Modifier.weight(1f),
              singleLine = true,
            )
            OutlinedTextField(
              value = riderLngText,
              onValueChange = { riderLngText = it },
              label = { Text("Rider Lng") },
              modifier = Modifier.weight(1f),
              singleLine = true,
            )
          }
        }
      },
      confirmButton = {
        Button(onClick = {
          onUpdateOrder(
            order,
            status,
            paymentStatus,
            riderName,
            riderPhone,
            etaText.toLongOrNull() ?: 25L,
            "Admin manual update",
            riderLatText.toDoubleOrNull(),
            riderLngText.toDoubleOrNull(),
          )
          editingOrder = null
        }) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { editingOrder = null }) { Text("Cancel") }
      },
    )
  }
}

@Composable
private fun AdminMenuPane(
  menuItems: List<MenuItem>,
  onSeedCatalog: () -> Unit,
  onUpsertMenuItem: (String?, MenuItem) -> Unit,
  onDeleteMenuItem: (String) -> Unit,
) {
  var editingItem by remember { mutableStateOf<MenuItem?>(null) }
  var showCreateDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
          onClick = { showCreateDialog = true },
          modifier = Modifier.weight(1f).testTag("admin_add_dish_button"),
        ) {
          Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("New Dish")
        }
        OutlinedButton(
          onClick = onSeedCatalog,
          modifier = Modifier.weight(1f).testTag("admin_seed_catalog_button"),
        ) {
          Icon(Icons.Filled.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("Sync Sylhet Menu")
        }
      }
    }

    items(menuItems, key = { it.id }) { item ->
      val customBmp = remember(item.imageBase64) { ImageUtils.decodeBase64ToImageBitmap(item.imageBase64) }
      Card(shape = RoundedCornerShape(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
          ) {
            if (customBmp != null) {
              Image(bitmap = customBmp, contentDescription = item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
              Image(
                painter = painterResource(id = ImageUtils.drawableForKey(item.imageKey, item.category)),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
            }
          }
          Spacer(Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.titleMedium)
            Text("${item.category.uppercase()} • ৳${item.price} / ৳${item.premiumPrice} • v${item.version}", style = MaterialTheme.typography.labelSmall)
            Text(if (item.available) "In Stock" else "Paused", color = if (item.available) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
          }
          IconButton(onClick = { editingItem = item }) {
            Icon(Icons.Filled.Edit, contentDescription = "Edit dish")
          }
          IconButton(onClick = { onDeleteMenuItem(item.id) }) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete dish", tint = MaterialTheme.colorScheme.error)
          }
        }
      }
    }
  }

  if (showCreateDialog) {
    MenuItemEditorDialog(
      initial = MenuItem(category = "pizza", price = 420L, premiumPrice = 690L, prepMinutes = 20L),
      isNew = true,
      onDismiss = { showCreateDialog = false },
      onSave = { updated ->
        onUpsertMenuItem(null, updated)
        showCreateDialog = false
      },
    )
  }

  editingItem?.let { item ->
    MenuItemEditorDialog(
      initial = item,
      isNew = false,
      onDismiss = { editingItem = null },
      onSave = { updated ->
        onUpsertMenuItem(item.id, updated)
        editingItem = null
      },
    )
  }
}

@Composable
private fun MenuItemEditorDialog(
  initial: MenuItem,
  isNew: Boolean,
  onDismiss: () -> Unit,
  onSave: (MenuItem) -> Unit,
) {
  val context = LocalContext.current
  var name by remember { mutableStateOf(initial.name) }
  var description by remember { mutableStateOf(initial.description) }
  var category by remember { mutableStateOf(initial.category) }
  var price by remember { mutableStateOf(initial.price.toString()) }
  var premiumPrice by remember { mutableStateOf(initial.premiumPrice.toString()) }
  var imageUrl by remember { mutableStateOf(initial.imageUrl) }
  var ingredientsText by remember { mutableStateOf(initial.ingredients.joinToString(", ")) }
  var caloriesText by remember { mutableStateOf(if (initial.calories > 0L) initial.calories.toString() else "") }
  var available by remember { mutableStateOf(initial.available) }
  var isVeg by remember { mutableStateOf(initial.isVeg) }
  var imageBase64 by remember { mutableStateOf(initial.imageBase64) }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri ->
      if (uri != null) {
        val encoded = ImageUtils.uriToCompactBase64(context, uri)
        if (encoded != null) {
          imageBase64 = encoded
        }
      }
    },
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (isNew) "Add Menu Dish" else "Edit ${initial.name}") },
    text = {
      Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val previewBmp = remember(imageBase64) { ImageUtils.decodeBase64ToImageBitmap(imageBase64) }
        if (previewBmp != null) {
          Image(
            bitmap = previewBmp,
            contentDescription = "Selected dish photo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(14.dp)),
          )
        }
        OutlinedButton(
          onClick = {
            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
          },
          modifier = Modifier.fillMaxWidth().testTag("admin_pick_photo_button"),
        ) {
          Icon(Icons.Filled.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(8.dp))
          Text(if (imageBase64 == null) "Upload Dish Photo (Photo Picker)" else "Change Uploaded Photo")
        }

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Dish Name") }, singleLine = true)
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Full Description") })
        OutlinedTextField(
          value = ingredientsText,
          onValueChange = { ingredientsText = it },
          label = { Text("Ingredients (comma-separated)") },
        )
        OutlinedTextField(value = imageUrl, onValueChange = { imageUrl = it }, label = { Text("Image URL (Optional)") }, singleLine = true)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(listOf("pizza", "burger", "sandwich", "sides")) { cat ->
            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Regular ৳") }, modifier = Modifier.weight(1f), singleLine = true)
          OutlinedTextField(value = premiumPrice, onValueChange = { premiumPrice = it }, label = { Text("Large ৳") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedTextField(value = caloriesText, onValueChange = { caloriesText = it }, label = { Text("Calories (kcal, Optional)") }, singleLine = true)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Available for Ordering")
          Switch(checked = available, onCheckedChange = { available = it })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Vegetarian")
          Switch(checked = isVeg, onCheckedChange = { isVeg = it })
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val parsedIngredients = ingredientsText.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(30)
          onSave(
            initial.copy(
              name = name.ifBlank { "Special Dish" },
              description = description.ifBlank { "Prepared fresh at Pizza Hub Sylhet." },
              category = category,
              price = price.toLongOrNull()?.coerceAtLeast(1L) ?: 350L,
              premiumPrice = premiumPrice.toLongOrNull()?.coerceAtLeast(0L) ?: 550L,
              imageKey = when (category) {
                "burger" -> "img_burger_category"
                "sandwich" -> "img_sandwich_category"
                "sides" -> "img_hero_pizzahub"
                else -> "img_pizza_category"
              },
              imageUrl = imageUrl.trim(),
              imageBase64 = imageBase64,
              ingredients = parsedIngredients,
              calories = caloriesText.toLongOrNull()?.coerceIn(0L, 10000L) ?: initial.calories,
              available = available,
              isVeg = isVeg,
            )
          )
        },
        modifier = Modifier.testTag("admin_save_dish_button"),
      ) {
        Text("Save Dish")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
private fun AdminBillingPane(
  orders: List<Order>,
  onUpdateOrder: (Order, String, String, String, String, Long, String, Double?, Double?) -> Unit,
) {
  val paidTotal = orders.filter { it.paymentStatus == "paid" }.sumOf { it.totalAmount }
  val pendingTotal = orders.filter { it.paymentStatus == "pending" && it.orderStatus != "cancelled" }.sumOf { it.totalAmount }
  val refundedTotal = orders.filter { it.paymentStatus == "refunded" }.sumOf { it.totalAmount }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MetricKpiCard("Collected", "৳$paidTotal", Modifier.weight(1f))
        MetricKpiCard("Pending COD", "৳$pendingTotal", Modifier.weight(1f))
        MetricKpiCard("Refunded", "৳$refundedTotal", Modifier.weight(1f))
      }
    }
    items(orders, key = { "bill_${it.id}" }) { order ->
      Card(shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("#${order.id.take(6).uppercase()} • ${order.paymentMethod.uppercase()}", style = MaterialTheme.typography.titleMedium)
            Text("৳${order.totalAmount} (${order.paymentStatus.uppercase()})", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
          }
          Text("Ref: ${order.paymentRef} • Hash: ${order.encryptedPayloadHash.take(16)}...", style = MaterialTheme.typography.labelSmall)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (order.paymentStatus != "paid") {
              Button(onClick = {
                onUpdateOrder(order, order.orderStatus, "paid", order.riderName, order.riderPhone, order.etaMinutes, "Marked paid in Billing", null, null)
              }) {
                Text("Mark Paid")
              }
            }
            if (order.paymentStatus != "refunded") {
              OutlinedButton(onClick = {
                onUpdateOrder(order, "cancelled", "refunded", order.riderName, order.riderPhone, 0L, "Refunded in Billing", null, null)
              }) {
                Text("Refund")
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AdminRbacSyncPane(
  admins: List<AdminEntry>,
  logs: List<AuditLog>,
  onGrantAdmin: (String, String, String) -> Unit,
) {
  var targetUid by remember { mutableStateOf("") }
  var targetEmail by remember { mutableStateOf("") }
  var roleLabel by remember { mutableStateOf("Store Manager") }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Card(shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text("Role-Based Access Control (RBAC)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          }
          OutlinedTextField(value = targetUid, onValueChange = { targetUid = it }, label = { Text("Staff Firebase UID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(value = targetEmail, onValueChange = { targetEmail = it }, label = { Text("Staff Google Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          OutlinedTextField(value = roleLabel, onValueChange = { roleLabel = it }, label = { Text("Role Title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
          Button(onClick = {
            onGrantAdmin(targetUid, targetEmail, roleLabel)
            targetUid = ""
            targetEmail = ""
          }) {
            Text("Grant Admin Access")
          }
          if (admins.isNotEmpty()) {
            HorizontalDivider()
            admins.forEach { a ->
              Text("${a.email} (${a.roleLabel}) • ${a.uid.take(8)}...", style = MaterialTheme.typography.labelMedium)
            }
          }
        }
      }
    }

    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Sync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text("LWW Sync Conflict & Audit Stream", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }
    }

    items(logs, key = { it.id }) { log ->
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(14.dp),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(log.action, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = RoundedCornerShape(6.dp)) {
              Text(log.resolutionStrategy, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
          }
          Text(log.details, style = MaterialTheme.typography.bodyMedium)
          Text("${log.actorEmail} • ${log.entityType}:${log.entityId.take(8)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }
}
