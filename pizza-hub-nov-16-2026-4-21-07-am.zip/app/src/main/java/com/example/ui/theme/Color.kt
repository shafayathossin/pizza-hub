package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode — Warm Parchment & Brick-Oven Crimson
val BrickCrimson = Color(0xFFB71C1C)
val BrickCrimsonContainer = Color(0xFFFFDAD6)
val OnBrickCrimsonContainer = Color(0xFF410002)

val MoltenAmber = Color(0xFFE65100)
val MoltenAmberContainer = Color(0xFFFFDCC8)
val OnMoltenAmberContainer = Color(0xFF331200)

val BasilGreen = Color(0xFF2E7D32)
val BasilGreenContainer = Color(0xFFC8E6C9)
val OnBasilGreenContainer = Color(0xFF072109)

val LightBackground = Color(0xFFFFF9F5)
val LightSurface = Color(0xFFFFF9F5)
val LightSurfaceVariant = Color(0xFFF5E6DE)
val LightOnSurface = Color(0xFF201A18)
val LightOnSurfaceVariant = Color(0xFF53433E)
val LightOutline = Color(0xFF85736D)

// Dark Mode — Hearth Charcoal & Ember Glow
val EmberRed = Color(0xFFFFB4AB)
val EmberRedContainer = Color(0xFF93000A)
val OnEmberRedContainer = Color(0xFFFFDAD6)

val CheddarGold = Color(0xFFFFB77C)
val CheddarGoldContainer = Color(0xFF6B2F00)
val OnCheddarGoldContainer = Color(0xFFFFDCC8)

val MintBasil = Color(0xFF81C784)
val MintBasilContainer = Color(0xFF1B5E20)

val DarkBackground = Color(0xFF16110F)
val DarkSurface = Color(0xFF16110F)
val DarkSurfaceVariant = Color(0xFF2C221E)
val DarkOnSurface = Color(0xFFEDE0DB)
val DarkOnSurfaceVariant = Color(0xFFD7C2BA)
val DarkOutline = Color(0xFF9F8C85)
