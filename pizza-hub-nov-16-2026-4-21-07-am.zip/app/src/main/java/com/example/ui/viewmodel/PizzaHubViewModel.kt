package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminEntry
import com.example.data.model.AuditLog
import com.example.data.model.CartItem
import com.example.data.model.DefaultMenuCatalog
import com.example.data.model.MenuItem
import com.example.data.model.Order
import com.example.data.model.Review
import com.example.data.model.SylhetLocations
import com.example.data.model.UserOrder
import com.example.data.model.UserProfile
import com.example.data.repository.PizzaHubRepository
import com.example.data.repository.SyncSnapshot
import com.example.util.AppPreferences
import com.example.util.ConnectivityObserver
import com.example.util.CryptoSecurityHelper
import com.example.util.LocalAppSettings
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
class PizzaHubViewModel(
  private val repository: PizzaHubRepository,
  connectivityObserver: ConnectivityObserver,
  private val appPreferences: AppPreferences,
  val currentUserId: String,
  val userEmail: String,
  val userDisplayName: String,
  val emailVerified: Boolean,
) : ViewModel() {

  private val _selectedCategory = MutableStateFlow("all")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _statusMessage = MutableStateFlow<String?>(null)
  val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

  private val _orderStatusAlert = MutableStateFlow<Order?>(null)
  val orderStatusAlert: StateFlow<Order?> = _orderStatusAlert.asStateFlow()

  private val knownOrderStatuses = mutableMapOf<String, String>()

  val isOnline: StateFlow<Boolean> = connectivityObserver.isOnline
    .distinctUntilChanged()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

  val localSettings: StateFlow<LocalAppSettings> = appPreferences.settingsFlow
    .distinctUntilChanged()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), LocalAppSettings())

  private val _optimisticFavorites = MutableStateFlow<Map<String, Boolean>>(emptyMap())

  val userProfile: StateFlow<UserProfile?> = repository.observeUserProfile(currentUserId)
    .distinctUntilChanged()
    .catch { e -> unwrapAndLog("observeUserProfile", e) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

  val favoriteItemIds: StateFlow<Set<String>> = combine(userProfile, _optimisticFavorites) { profile, overrides ->
    val base = profile?.favoriteItemIds?.toSet().orEmpty()
    val result = base.toMutableSet()
    overrides.forEach { (id, isFav) ->
      if (isFav) result.add(id) else result.remove(id)
    }
    result.toSet()
  }
    .distinctUntilChanged()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

  val isAdmin: StateFlow<Boolean> = repository.observeIsAdmin(currentUserId, userEmail, emailVerified)
    .distinctUntilChanged()
    .catch { e ->
      unwrapAndLog("observeIsAdmin", e)
      emit(false)
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)

  val menuState: StateFlow<UiState<SyncSnapshot<MenuItem>>> = repository.observeMenuItems()
    .map<SyncSnapshot<MenuItem>, UiState<SyncSnapshot<MenuItem>>> { snap ->
      val effective = if (snap.items.isEmpty()) {
        snap.copy(items = DefaultMenuCatalog.items)
      } else {
        snap
      }
      UiState.Success(effective)
    }
    .catch { error ->
      val root = unwrapFirestore(error)
      if (root == null && error is CancellationException) throw error
      val err = root ?: error
      Log.w(TAG, "Error observing menu", err)
      emit(UiState.Error(err.message ?: "Failed to load menu"))
    }
    .stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5000L),
      UiState.Success(SyncSnapshot(DefaultMenuCatalog.items, isFromCache = true)),
    )

  val ordersState: StateFlow<UiState<SyncSnapshot<Order>>> = repository.observeCustomerOrders(currentUserId)
    .onEach { snap ->
      snap.items.forEach { order ->
        val prev = knownOrderStatuses[order.id]
        if (prev != null && prev != order.orderStatus) {
          _orderStatusAlert.value = order
        }
        knownOrderStatuses[order.id] = order.orderStatus
      }
    }
    .map<SyncSnapshot<Order>, UiState<SyncSnapshot<Order>>> { UiState.Success(it) }
    .catch { error ->
      val root = unwrapFirestore(error)
      if (root == null && error is CancellationException) throw error
      val err = root ?: error
      Log.w(TAG, "Error observing customer orders", err)
      emit(UiState.Error(err.message ?: "Failed to load orders"))
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val userOrderHistoryState: StateFlow<UiState<SyncSnapshot<UserOrder>>> = repository.observeUserOrderHistory(currentUserId)
    .map<SyncSnapshot<UserOrder>, UiState<SyncSnapshot<UserOrder>>> { UiState.Success(it) }
    .catch { error ->
      val root = unwrapFirestore(error)
      if (root == null && error is CancellationException) throw error
      val err = root ?: error
      Log.w(TAG, "Error observing user_orders history", err)
      emit(UiState.Error(err.message ?: "Failed to load purchase history"))
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val adminOrdersState: StateFlow<UiState<SyncSnapshot<Order>>> = isAdmin
    .flatMapLatest { admin ->
      if (!admin) {
        emptyFlow()
      } else {
        repository.observeAllOrdersAdmin()
          .map<SyncSnapshot<Order>, UiState<SyncSnapshot<Order>>> { UiState.Success(it) }
          .catch { error ->
            val root = unwrapFirestore(error)
            if (root == null && error is CancellationException) throw error
            val err = root ?: error
            Log.w(TAG, "Error observing admin orders", err)
            emit(UiState.Error(err.message ?: "Failed to load store orders"))
          }
      }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val reviewsState: StateFlow<UiState<List<Review>>> = repository.observeReviews()
    .map<List<Review>, UiState<List<Review>>> { UiState.Success(it) }
    .catch { error ->
      val root = unwrapFirestore(error)
      if (root == null && error is CancellationException) throw error
      val err = root ?: error
      Log.w(TAG, "Error observing reviews", err)
      emit(UiState.Error(err.message ?: "Failed to load reviews"))
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val auditLogsState: StateFlow<UiState<List<AuditLog>>> = isAdmin
    .flatMapLatest { admin ->
      repository.observeAuditLogs(currentUserId, admin)
        .map<List<AuditLog>, UiState<List<AuditLog>>> { UiState.Success(it) }
        .catch { error ->
          val root = unwrapFirestore(error)
          if (root == null && error is CancellationException) throw error
          val err = root ?: error
          Log.w(TAG, "Error observing audit logs", err)
          emit(UiState.Error(err.message ?: "Failed to load audit logs"))
        }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val adminsState: StateFlow<List<AdminEntry>> = isAdmin
    .flatMapLatest { admin ->
      if (!admin) emptyFlow() else repository.observeAdmins().catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  init {
    viewModelScope.launch {
      repository.ensureUserProfile(currentUserId, userDisplayName, userEmail)
    }
  }

  fun setCategory(category: String) {
    _selectedCategory.value = category
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun clearStatusMessage() {
    _statusMessage.value = null
  }

  fun clearOrderStatusAlert() {
    _orderStatusAlert.value = null
  }

  fun showStatusMessage(msg: String) {
    _statusMessage.value = msg
  }

  fun toggleFavorite(menuItem: MenuItem) {
    val currentlyFav = favoriteItemIds.value.contains(menuItem.id)
    val nextState = !currentlyFav
    _optimisticFavorites.update { it + (menuItem.id to nextState) }
    viewModelScope.launch {
      val res = repository.toggleFavoriteMenuItem(
        userId = currentUserId,
        menuItemId = menuItem.id,
        shouldBeFavorite = nextState,
      )
      if (res.isSuccess) {
        _optimisticFavorites.update { it - menuItem.id }
        _statusMessage.value = if (nextState) {
          "Saved ${menuItem.name} to favorites"
        } else {
          "Removed ${menuItem.name} from favorites"
        }
      } else {
        _optimisticFavorites.update { it - menuItem.id }
        _statusMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to update favorites"
      }
    }
  }

  fun placeOrder(
    cartItems: List<CartItem>,
    customerName: String,
    customerPhone: String,
    deliveryAddress: String,
    paymentMethod: String,
    paymentRef: String,
    promoCode: String,
    deliveryNotes: String,
    onSuccess: (String) -> Unit,
  ) {
    if (cartItems.isEmpty()) {
      _statusMessage.value = "Your cart is empty."
      return
    }
    val subtotal = cartItems.sumOf { it.lineTotal }
    val deliveryFee = if (subtotal >= 800L) 0L else 50L
    val promoEval = PromoCodeEngine.evaluate(promoCode, subtotal)
    val discount = when (promoEval) {
      is PromoFeedback.Applied -> promoEval.discountAmount
      is PromoFeedback.Error -> 0L
    }.coerceAtMost(subtotal)
    val totalAmount = (subtotal + deliveryFee - discount).coerceAtLeast(1L)
    val summary = cartItems.joinToString(", ") {
      val cheeseTag = if (it.extraCheese) " +Extra Cheese" else ""
      "${it.quantity}x ${it.menuItem.name} (${it.sizeLabel}$cheeseTag)"
    }
    val totalCount = cartItems.sumOf { it.quantity.toLong() }
    val paymentStatus = if (paymentMethod == "cod") "pending" else "paid"
    val resolvedRef = if (paymentMethod == "cod") {
      "COD-SYLHET"
    } else {
      paymentRef.ifBlank { "${paymentMethod.uppercase()}-${System.currentTimeMillis().toString().takeLast(6)}" }
    }
    val eta = (cartItems.maxOfOrNull { it.menuItem.prepMinutes } ?: 20L) + 15L
    val (destLat, destLng) = SylhetLocations.resolveAddressLatLng(deliveryAddress)

    val order = Order(
      userId = currentUserId,
      customerName = customerName.ifBlank { userDisplayName },
      customerPhone = customerPhone,
      deliveryAddress = deliveryAddress,
      itemsSummary = summary,
      itemCount = totalCount,
      subtotal = subtotal,
      deliveryFee = deliveryFee,
      discount = discount,
      totalAmount = totalAmount,
      paymentMethod = paymentMethod,
      paymentStatus = paymentStatus,
      paymentRef = resolvedRef,
      riderLat = SylhetLocations.KITCHEN_LAT,
      riderLng = SylhetLocations.KITCHEN_LNG,
      destinationLat = destLat,
      destinationLng = destLng,
      etaMinutes = eta,
      deliveryNotes = deliveryNotes,
    )

    viewModelScope.launch {
      val result = repository.placeOrder(order, userEmail)
      result.onSuccess { orderId ->
        val plainReceipt = "Order #$orderId | $summary | Total ৳$totalAmount | $paymentMethod ($resolvedRef)"
        val encrypted = CryptoSecurityHelper.encryptPayload(plainReceipt, currentUserId)
        appPreferences.saveEncryptedReceipt(encrypted)
        _statusMessage.value = "Order placed! Tracking #$orderId"
        onSuccess(orderId)
      }.onFailure { err ->
        _statusMessage.value = err.localizedMessage ?: "Failed to place order"
      }
    }
  }

  fun matchedItemsForOrder(order: Order): List<MenuItem> = matchedItemsForSummary(order.itemsSummary)

  fun matchedItemsForSummary(itemsSummary: String): List<MenuItem> {
    val menuItems = (menuState.value as? UiState.Success)?.data?.items ?: DefaultMenuCatalog.items
    val matched = menuItems.filter { item ->
      itemsSummary.contains(item.name, ignoreCase = true)
    }
    return matched.ifEmpty { menuItems.take(1) }
  }

  fun cancelOrder(order: Order) {
    viewModelScope.launch {
      val res = repository.cancelOrderByCustomer(order, userEmail)
      _statusMessage.value = if (res.isSuccess) {
        "Order cancelled"
      } else {
        res.exceptionOrNull()?.localizedMessage ?: "Cannot cancel this order"
      }
    }
  }

  fun submitReview(menuItem: MenuItem, rating: Int, comment: String, orderId: String = "") {
    if (comment.trim().length < 2) {
      _statusMessage.value = "Please enter at least 2 characters for your review."
      return
    }
    val author = userProfile.value?.displayName?.ifBlank { userDisplayName } ?: userDisplayName
    viewModelScope.launch {
      val res = repository.submitReview(
        Review(
          userId = currentUserId,
          authorName = author.ifBlank { "Pizza Hub Guest" },
          menuItemId = menuItem.id,
          menuItemName = menuItem.name,
          rating = rating.toLong().coerceIn(1L, 5L),
          comment = comment.trim(),
          orderId = orderId,
        )
      )
      _statusMessage.value = if (res.isSuccess) {
        "Thank you for reviewing ${menuItem.name}!"
      } else {
        res.exceptionOrNull()?.localizedMessage ?: "Failed to post review"
      }
    }
  }

  fun deleteReview(reviewId: String) {
    viewModelScope.launch {
      val res = repository.deleteReview(reviewId)
      _statusMessage.value = if (res.isSuccess) "Review deleted" else "Could not delete review"
    }
  }

  fun saveProfileAndSettings(
    displayName: String,
    phone: String,
    deliveryAddress: String,
    preferredLanguage: String,
    darkMode: String,
    biometricEnabled: Boolean,
    lowBandwidthSync: Boolean,
  ) {
    viewModelScope.launch {
      appPreferences.setLanguage(preferredLanguage)
      appPreferences.setDarkMode(darkMode)
      appPreferences.setBiometricEnabled(biometricEnabled)
      appPreferences.setLowBandwidthSync(lowBandwidthSync)
      val res = repository.updateUserProfile(
        userId = currentUserId,
        displayName = displayName,
        phone = phone,
        deliveryAddress = deliveryAddress,
        preferredLanguage = preferredLanguage,
        darkMode = darkMode,
        biometricEnabled = biometricEnabled,
        lowBandwidthSync = lowBandwidthSync,
      )
      _statusMessage.value = if (res.isSuccess) {
        "Profile & sync preferences saved"
      } else {
        "Saved locally; cloud sync queued"
      }
    }
  }

  fun setQuickDarkMode(mode: String) {
    viewModelScope.launch {
      appPreferences.setDarkMode(mode)
      val p = userProfile.value
      if (p != null) {
        repository.updateUserProfile(
          userId = currentUserId,
          displayName = p.displayName,
          phone = p.phone,
          deliveryAddress = p.deliveryAddress,
          preferredLanguage = p.preferredLanguage,
          darkMode = mode,
          biometricEnabled = p.biometricEnabled,
          lowBandwidthSync = p.lowBandwidthSync,
        )
      }
    }
  }

  fun setQuickLanguage(lang: String) {
    viewModelScope.launch {
      appPreferences.setLanguage(lang)
      val p = userProfile.value
      if (p != null) {
        repository.updateUserProfile(
          userId = currentUserId,
          displayName = p.displayName,
          phone = p.phone,
          deliveryAddress = p.deliveryAddress,
          preferredLanguage = lang,
          darkMode = p.darkMode,
          biometricEnabled = p.biometricEnabled,
          lowBandwidthSync = p.lowBandwidthSync,
        )
      }
    }
  }

  // --- Admin Operations ---

  fun seedMenuCatalog() {
    viewModelScope.launch {
      val res = repository.seedDefaultMenuIfEmpty(currentUserId, userEmail)
      _statusMessage.value = res.fold(
        onSuccess = { count ->
          if (count > 0) "Synced $count Pizza Hub Sylhet items to Cloud" else "Catalog already populated in Cloud"
        },
        onFailure = { it.localizedMessage ?: "Admin access required to seed catalog" },
      )
    }
  }

  fun upsertMenuItem(itemId: String?, item: MenuItem) {
    viewModelScope.launch {
      val res = repository.upsertMenuItem(itemId, item, currentUserId, userEmail)
      _statusMessage.value = res.fold(
        onSuccess = { "Saved ${item.name} to live menu" },
        onFailure = { it.localizedMessage ?: "Failed to save menu item" },
      )
    }
  }

  fun deleteMenuItem(itemId: String) {
    viewModelScope.launch {
      val res = repository.deleteMenuItem(itemId, currentUserId, userEmail)
      _statusMessage.value = if (res.isSuccess) "Menu item deleted" else "Delete failed"
    }
  }

  fun adminUpdateOrder(
    order: Order,
    newStatus: String,
    newPaymentStatus: String,
    riderName: String,
    riderPhone: String,
    etaMinutes: Long,
    conflictNote: String = "",
    riderLat: Double? = null,
    riderLng: Double? = null,
  ) {
    viewModelScope.launch {
      val res = repository.updateOrderByAdmin(
        order = order,
        newStatus = newStatus,
        newPaymentStatus = newPaymentStatus,
        riderName = riderName,
        riderPhone = riderPhone,
        etaMinutes = etaMinutes,
        conflictNote = conflictNote,
        actorEmail = userEmail,
        riderLat = riderLat,
        riderLng = riderLng,
      )
      _statusMessage.value = if (res.isSuccess) {
        "Order updated to ${newStatus.replace('_', ' ')}"
      } else {
        res.exceptionOrNull()?.localizedMessage ?: "Order update failed"
      }
    }
  }

  fun grantAdminAccess(targetUid: String, targetEmail: String, roleLabel: String) {
    if (targetUid.isBlank() || targetEmail.isBlank()) {
      _statusMessage.value = "Enter both UID and Email"
      return
    }
    viewModelScope.launch {
      val res = repository.grantAdminRole(targetUid, targetEmail, roleLabel, currentUserId, userEmail)
      _statusMessage.value = if (res.isSuccess) {
        "Granted $roleLabel access to $targetEmail"
      } else {
        res.exceptionOrNull()?.localizedMessage ?: "Failed to grant admin role"
      }
    }
  }

  private fun unwrapFirestore(error: Throwable): FirebaseFirestoreException? =
    generateSequence(error) { it.cause }
      .filterIsInstance<FirebaseFirestoreException>()
      .firstOrNull()

  private fun unwrapAndLog(opName: String, error: Throwable) {
    val fs = unwrapFirestore(error)
    if (fs == null && error is CancellationException) throw error
    Log.w(TAG, "Stream error in $opName", fs ?: error)
  }

  private companion object {
    const val TAG = "PizzaHubVM"
  }
}
