package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalPizza
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.data.model.CartItem
import com.example.data.model.MenuItem
import com.example.data.model.StoreInfo
import com.example.data.model.UserProfile
import com.example.data.repository.SyncSnapshot
import com.example.ui.viewmodel.PromoCodeEngine
import com.example.ui.viewmodel.PromoFeedback
import com.example.ui.viewmodel.ShoppingCartUiState
import com.example.ui.viewmodel.UiState
import com.example.util.AppStrings
import com.example.util.BiometricHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
  menuState: UiState<SyncSnapshot<MenuItem>>,
  selectedCategory: String,
  searchQuery: String,
  cart: List<CartItem>,
  cartUiState: ShoppingCartUiState,
  promoFeedback: PromoFeedback?,
  favoriteItemIds: Set<String>,
  userProfile: UserProfile?,
  lowBandwidthSync: Boolean,
  biometricEnabled: Boolean,
  strings: AppStrings,
  onSelectCategory: (String) -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onToggleFavorite: (MenuItem) -> Unit,
  onOpenFavoritesScreen: () -> Unit,
  onAddToCart: (MenuItem, Boolean, Boolean, Int) -> Unit,
  onDecrementMenuItem: (String) -> Unit,
  onUpdateCartQuantity: (CartItem, Int) -> Unit,
  onRemoveCartItem: (CartItem) -> Unit,
  onApplyPromoCode: (String) -> Unit,
  onRemovePromoCode: () -> Unit,
  onClearCart: () -> Unit,
  onPlaceOrder: (List<CartItem>, String, String, String, String, String, String, String, (String) -> Unit) -> Unit,
  onOrderPlacedNavigate: () -> Unit,
) {
  var selectedDetailItem by remember { mutableStateOf<MenuItem?>(null) }
  var showCartSheet by remember { mutableStateOf(false) }
  var vegOnly by remember { mutableStateOf(false) }

  val qtyByMenuId = remember(cart) {
    cart.groupBy { it.menuItem.id }.mapValues { (_, entries) -> entries.sumOf { it.quantity } }
  }

  val activeDetail = selectedDetailItem
  if (activeDetail != null) {
    FoodItemDetailScreen(
      item = activeDetail,
      inCartQuantity = qtyByMenuId[activeDetail.id] ?: 0,
      isFavorite = favoriteItemIds.contains(activeDetail.id),
      lowBandwidthSync = lowBandwidthSync,
      onToggleFavorite = { onToggleFavorite(activeDetail) },
      onBack = { selectedDetailItem = null },
      onConfirmAdd = { isPremium, extraCheese, qty ->
        onAddToCart(activeDetail, isPremium, extraCheese, qty)
        selectedDetailItem = null
      },
    )
    return
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val gridSpec = remember(maxWidth) { computeResponsiveGridSpec(maxWidth) }

    val allItems = (menuState as? UiState.Success)?.data?.items.orEmpty()
    val itemsByCategory = remember(allItems) {
      allItems.groupBy { it.category.lowercase().ifBlank { "sides" } }
    }
    val orderedCategoryKeys = remember(itemsByCategory) {
      val base = listOf("pizza", "burger", "sandwich", "sides")
      (base + itemsByCategory.keys).distinct().filter { itemsByCategory[it].orEmpty().isNotEmpty() || it in base }
    }
    val categoryMetas = remember(orderedCategoryKeys, strings) {
      orderedCategoryKeys.map { categoryMetaFor(it, strings) }
    }

    val categories = remember(strings, favoriteItemIds.size, itemsByCategory, orderedCategoryKeys) {
      buildList {
        add("all" to strings.allCategory)
        add("favorites" to "${strings.favoritesLabel} (${favoriteItemIds.size})")
        orderedCategoryKeys.forEach { catKey ->
          val meta = categoryMetaFor(catKey, strings)
          val count = itemsByCategory[catKey]?.size ?: 0
          add(catKey to if (count > 0) "${meta.title} ($count)" else meta.title)
        }
      }
    }

    val savedFavorites = remember(allItems, favoriteItemIds) {
      allItems.filter { favoriteItemIds.contains(it.id) }
    }

    val filtered = remember(allItems, selectedCategory, searchQuery, vegOnly, favoriteItemIds) {
      val q = searchQuery.trim()
      allItems.filter { item ->
        val itemCat = item.category.lowercase()
        val catMatch = when (selectedCategory) {
          "all" -> true
          "favorites" -> favoriteItemIds.contains(item.id)
          else -> itemCat == selectedCategory.lowercase()
        }
        val vegMatch = !vegOnly || item.isVeg
        val queryMatch = q.isEmpty() ||
          item.name.contains(q, ignoreCase = true) ||
          item.description.contains(q, ignoreCase = true) ||
          item.category.contains(q, ignoreCase = true) ||
          item.resolvedIngredients().any { it.contains(q, ignoreCase = true) }
        catMatch && vegMatch && queryMatch
      }
    }

    val groupedFiltered = remember(filtered, orderedCategoryKeys) {
      val grouped = filtered.groupBy { it.category.lowercase().ifBlank { "sides" } }
      val keys = (orderedCategoryKeys + grouped.keys)
        .distinct()
        .sortedBy { categoryOrderIndex(it) }
      keys.mapNotNull { key ->
        val list = grouped[key].orEmpty()
        if (list.isEmpty()) null else key to list
      }
    }

    Column(modifier = Modifier.fillMaxSize()) {
      // Pinned Search Bar at the top of the Menu Screen
      Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = gridSpec.horizontalPadding, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("menu_search_input"),
            placeholder = { Text(strings.searchHint) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search menu") },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(
                  onClick = { onSearchQueryChange("") },
                  modifier = Modifier.testTag("clear_menu_search"),
                ) {
                  Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
          )
        }
      }

      LazyVerticalGrid(
        columns = GridCells.Fixed(gridSpec.columns),
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .testTag("menu_lazy_vertical_grid"),
        contentPadding = PaddingValues(
          start = gridSpec.horizontalPadding,
          end = gridSpec.horizontalPadding,
          top = 10.dp,
          bottom = 104.dp,
        ),
        horizontalArrangement = Arrangement.spacedBy(gridSpec.spacing),
        verticalArrangement = Arrangement.spacedBy(gridSpec.spacing),
      ) {
        if (searchQuery.isBlank()) {
          item(
            key = "hero_banner",
            span = { GridItemSpan(maxLineSpan) },
            contentType = { "banner" },
          ) {
            HeroStoreBanner(lowBandwidthSync = lowBandwidthSync)
          }

          if (allItems.isNotEmpty()) {
            item(
              key = "category_showcase",
              span = { GridItemSpan(maxLineSpan) },
              contentType = { "category_showcase" },
            ) {
              CategoryShowcaseRow(
                categories = categoryMetas,
                itemsByCategory = itemsByCategory,
                selectedCategory = selectedCategory,
                lowBandwidthSync = lowBandwidthSync,
                isWideLayout = gridSpec.isWideLayout,
                onSelectCategory = onSelectCategory,
              )
            }
          }
        }

        // Full-width Category & Dietary Filter Chips
        item(
          key = "category_chips",
          span = { GridItemSpan(maxLineSpan) },
          contentType = { "chips" },
        ) {
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories, key = { it.first }) { (key, label) ->
              FilterChip(
                selected = selectedCategory == key,
                onClick = { onSelectCategory(key) },
                leadingIcon = when (key) {
                  "favorites" -> {
                    {
                      Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = null,
                        tint = if (selectedCategory == "favorites") MaterialTheme.colorScheme.primary else Color(0xFFE53935),
                        modifier = Modifier.size(16.dp),
                      )
                    }
                  }
                  "all" -> null
                  else -> {
                    val catIcon = categoryMetaFor(key, strings).icon
                    {
                      Icon(
                        imageVector = catIcon,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                      )
                    }
                  }
                },
                label = { Text(label) },
                modifier = Modifier.testTag("category_chip_$key"),
              )
            }
            item(key = "veg_only_chip") {
              FilterChip(
                selected = vegOnly,
                onClick = { vegOnly = !vegOnly },
                leadingIcon = {
                  Icon(
                    imageVector = Icons.Filled.Eco,
                    contentDescription = null,
                    tint = if (vegOnly) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                  )
                },
                label = { Text("Veg Only") },
                modifier = Modifier.testTag("veg_only_chip"),
              )
            }
          }
        }

        // Firestore-backed Responsive Category Grid
        when (menuState) {
          is UiState.Loading -> {
            item(
              key = "loading",
              span = { GridItemSpan(maxLineSpan) },
              contentType = { "status" },
            ) {
              Text(
                text = "Loading Pizza Hub Sylhet menu...",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(24.dp),
              )
            }
          }
          is UiState.Error -> {
            item(
              key = "error",
              span = { GridItemSpan(maxLineSpan) },
              contentType = { "status" },
            ) {
              Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                shape = RoundedCornerShape(16.dp),
              ) {
                Text(
                  text = menuState.message,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                  modifier = Modifier.padding(16.dp),
                )
              }
            }
          }
          is UiState.Success -> {
            if (savedFavorites.isNotEmpty() && searchQuery.isBlank() && selectedCategory == "all" && !vegOnly) {
              item(
                key = "saved_favorites",
                span = { GridItemSpan(maxLineSpan) },
                contentType = { "favorites_strip" },
              ) {
                SavedFavoritesQuickSection(
                  favorites = savedFavorites,
                  lowBandwidthSync = lowBandwidthSync,
                  onOpenAllFavorites = onOpenFavoritesScreen,
                  onItemClick = { selectedDetailItem = it },
                  onQuickAdd = { item -> if (item.available) onAddToCart(item, false, false, 1) },
                )
              }
            }

            if (searchQuery.isNotBlank()) {
              item(
                key = "search_count",
                span = { GridItemSpan(maxLineSpan) },
                contentType = { "search_count" },
              ) {
                Text(
                  text = "${filtered.size} item(s) matching \"${searchQuery.trim()}\"",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.testTag("search_results_count"),
                )
              }
            }

            if (groupedFiltered.isEmpty()) {
              item(
                key = "empty_state",
                span = { GridItemSpan(maxLineSpan) },
                contentType = { "empty" },
              ) {
                Card(
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                  shape = RoundedCornerShape(18.dp),
                ) {
                  Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                  ) {
                    Icon(
                      imageVector = if (selectedCategory == "favorites") Icons.Outlined.FavoriteBorder else Icons.Filled.LocalPizza,
                      contentDescription = null,
                      modifier = Modifier.size(36.dp),
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                      text = if (selectedCategory == "favorites") {
                        "No saved favorites yet. Tap the heart icon on any dish!"
                      } else {
                        "No items match your search or category."
                      },
                      style = MaterialTheme.typography.titleMedium,
                    )
                  }
                }
              }
            } else {
              groupedFiltered.forEach { (catKey, categoryItems) ->
                val meta = categoryMetaFor(catKey, strings)
                val isSingleFocus = selectedCategory == catKey
                item(
                  key = "section_header_$catKey",
                  span = { GridItemSpan(maxLineSpan) },
                  contentType = { "section_header" },
                ) {
                  CategorySectionHeader(
                    meta = meta,
                    itemCount = categoryItems.size,
                    minPrice = categoryItems.minOfOrNull { it.price },
                    isFilteredSingleCategory = isSingleFocus,
                    onToggleCategoryFocus = {
                      onSelectCategory(if (isSingleFocus) "all" else catKey)
                    },
                  )
                }

                items(
                  items = categoryItems,
                  key = { it.id },
                  contentType = { "menu_item_card" },
                ) { item ->
                  val inCartQty = qtyByMenuId[item.id] ?: 0
                  val isFav = favoriteItemIds.contains(item.id)
                  MenuItemGridCard(
                    item = item,
                    inCartQuantity = inCartQty,
                    isFavorite = isFav,
                    lowBandwidthSync = lowBandwidthSync,
                    imageHeight = gridSpec.imageHeight,
                    addLabel = strings.addToCart,
                    onClick = { selectedDetailItem = item },
                    onToggleFavorite = { onToggleFavorite(item) },
                    onQuickAdd = { if (item.available) onAddToCart(item, false, false, 1) },
                    onDecrement = { onDecrementMenuItem(item.id) },
                  )
                }
              }
            }
          }
        }
      }
    }

    // Floating Cart Bar
    if (cart.isNotEmpty()) {
      val totalCount = cart.sumOf { it.quantity }
      val displayPrice = (cartUiState.subtotal - cartUiState.discount).coerceAtLeast(1L)
      Surface(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .padding(16.dp)
          .testTag("floating_cart_bar")
          .clickable { showCartSheet = true },
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 8.dp,
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f),
              shape = CircleShape,
            ) {
              Text(
                text = "$totalCount",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              )
            }
            Spacer(Modifier.width(12.dp))
            Column {
              Text(strings.viewCart, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              Text(
                text = if (cartUiState.discount > 0L) {
                  "Promo ${cartUiState.appliedPromoCode}: Saved ৳${cartUiState.discount}"
                } else {
                  "Tap to manage cart & checkout"
                },
                style = MaterialTheme.typography.labelSmall,
              )
            }
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "৳$displayPrice",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Filled.ShoppingBag, contentDescription = strings.viewCart)
          }
        }
      }
    }
  }

  // Cart & Secure Checkout Bottom Sheet
  if (showCartSheet) {
    CartCheckoutSheet(
      cart = cart,
      cartUiState = cartUiState,
      promoFeedback = promoFeedback,
      userProfile = userProfile,
      biometricEnabled = biometricEnabled,
      strings = strings,
      onDismiss = { showCartSheet = false },
      onUpdateQuantity = onUpdateCartQuantity,
      onRemoveCartItem = onRemoveCartItem,
      onApplyPromoCode = onApplyPromoCode,
      onRemovePromoCode = onRemovePromoCode,
      onClearCart = onClearCart,
      onPlaceOrder = { name, phone, addr, method, ref, promo, notes ->
        onPlaceOrder(cart, name, phone, addr, method, ref, promo, notes) {
          showCartSheet = false
          onOrderPlacedNavigate()
        }
      },
    )
  }
}

@Composable
fun FavoritesScreen(
  menuState: UiState<SyncSnapshot<MenuItem>>,
  favoriteItemIds: Set<String>,
  cart: List<CartItem>,
  lowBandwidthSync: Boolean,
  strings: AppStrings,
  onBackToMenu: () -> Unit,
  onToggleFavorite: (MenuItem) -> Unit,
  onAddToCart: (MenuItem, Boolean, Boolean, Int) -> Unit,
  onDecrementMenuItem: (String) -> Unit,
) {
  BackHandler(onBack = onBackToMenu)
  var selectedDetailItem by remember { mutableStateOf<MenuItem?>(null) }

  val qtyByMenuId = remember(cart) {
    cart.groupBy { it.menuItem.id }.mapValues { (_, entries) -> entries.sumOf { it.quantity } }
  }

  val activeDetail = selectedDetailItem
  if (activeDetail != null) {
    FoodItemDetailScreen(
      item = activeDetail,
      inCartQuantity = qtyByMenuId[activeDetail.id] ?: 0,
      isFavorite = favoriteItemIds.contains(activeDetail.id),
      lowBandwidthSync = lowBandwidthSync,
      onToggleFavorite = { onToggleFavorite(activeDetail) },
      onBack = { selectedDetailItem = null },
      onConfirmAdd = { isPremium, extraCheese, qty ->
        onAddToCart(activeDetail, isPremium, extraCheese, qty)
        selectedDetailItem = null
      },
    )
    return
  }

  val allItems = (menuState as? UiState.Success)?.data?.items.orEmpty()
  val savedItems = remember(allItems, favoriteItemIds) {
    allItems.filter { favoriteItemIds.contains(it.id) }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize().testTag("favorites_screen")) {
    val gridSpec = remember(maxWidth) { computeResponsiveGridSpec(maxWidth) }

    Column(modifier = Modifier.fillMaxSize()) {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onBackToMenu,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("favorites_back_button"),
            ) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to menu")
            }
            Spacer(Modifier.width(4.dp))
            Column {
              Text(
                text = strings.favoritesLabel,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = "${savedItems.size} saved dish(es) synced to your profile",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Icon(
            imageVector = Icons.Filled.Favorite,
            contentDescription = null,
            tint = Color(0xFFE53935),
            modifier = Modifier.padding(end = 8.dp),
          )
        }
      }

      if (savedItems.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize().padding(24.dp),
          contentAlignment = Alignment.Center,
        ) {
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(24.dp),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(
                imageVector = Icons.Outlined.FavoriteBorder,
                contentDescription = null,
                tint = Color(0xFFE53935),
                modifier = Modifier.size(48.dp),
              )
              Text("No Saved Favorites Yet", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
              Text(
                text = "Tap the heart icon on any pizza, burger, or sandwich to keep your go-to cravings ready here.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Button(
                onClick = onBackToMenu,
                modifier = Modifier.padding(top = 6.dp).testTag("browse_menu_from_favorites"),
                shape = RoundedCornerShape(14.dp),
              ) {
                Text("Browse Menu")
              }
            }
          }
        }
      } else {
        LazyVerticalGrid(
          columns = GridCells.Fixed(gridSpec.columns),
          modifier = Modifier.fillMaxSize().testTag("favorites_grid"),
          contentPadding = PaddingValues(gridSpec.horizontalPadding),
          horizontalArrangement = Arrangement.spacedBy(gridSpec.spacing),
          verticalArrangement = Arrangement.spacedBy(gridSpec.spacing),
        ) {
          items(
            items = savedItems,
            key = { "fav_page_${it.id}" },
            contentType = { "menu_item_card" },
          ) { item ->
            MenuItemGridCard(
              item = item,
              inCartQuantity = qtyByMenuId[item.id] ?: 0,
              isFavorite = true,
              lowBandwidthSync = lowBandwidthSync,
              imageHeight = gridSpec.imageHeight,
              addLabel = strings.addToCart,
              onClick = { selectedDetailItem = item },
              onToggleFavorite = { onToggleFavorite(item) },
              onQuickAdd = { if (item.available) onAddToCart(item, false, false, 1) },
              onDecrement = { onDecrementMenuItem(item.id) },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun FoodItemDetailScreen(
  item: MenuItem,
  inCartQuantity: Int,
  isFavorite: Boolean,
  lowBandwidthSync: Boolean,
  onToggleFavorite: () -> Unit,
  onBack: () -> Unit,
  onConfirmAdd: (Boolean, Boolean, Int) -> Unit,
) {
  BackHandler(onBack = onBack)

  var isPremium by remember(item.id) { mutableStateOf(false) }
  var extraCheese by remember(item.id) { mutableStateOf(false) }
  var quantity by remember(item.id) { mutableIntStateOf(1) }

  val ingredients = remember(item) { item.resolvedIngredients() }
  val nutrition = remember(item) { item.resolvedNutrition() }
  val unitPrice = (if (isPremium && item.premiumPrice > 0L) item.premiumPrice else item.price) +
    if (extraCheese) 60L else 0L

  Column(modifier = Modifier.fillMaxSize().testTag("food_item_detail_screen")) {
    // Sticky Detail Top Header
    Surface(
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 2.dp,
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          IconButton(
            onClick = onBack,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("detail_back_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to menu")
          }
          Spacer(Modifier.width(4.dp))
          Column {
            Text(
              text = item.name,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = "${item.category.replaceFirstChar { it.uppercase() }} • ${nutrition.servingSize}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("detail_favorite_toggle_${item.id}"),
          ) {
            Icon(
              imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
              contentDescription = if (isFavorite) "Remove from favorites" else "Save to favorites",
              tint = if (isFavorite) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Surface(
            color = if (item.isVeg) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(50),
          ) {
            Text(
              text = if (item.isVeg) "VEG" else item.category.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              color = if (item.isVeg) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
          }
        }
      }
    }

    // Scrollable Body
    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Hero Image with Key Metrics
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(220.dp)
          .clip(RoundedCornerShape(24.dp)),
      ) {
        MenuItemImage(
          item = item,
          lowBandwidthSync = lowBandwidthSync,
          modifier = Modifier.fillMaxSize(),
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color(0xCC1A110E))
              )
            ),
        )
        Row(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          DetailHeroBadge(icon = Icons.Filled.Star, text = "${item.ratingAvg} (${item.reviewCount})")
          DetailHeroBadge(icon = Icons.Filled.Timer, text = "${item.prepMinutes} min")
          DetailHeroBadge(icon = Icons.Filled.LocalFireDepartment, text = "${nutrition.calories} kcal")
          if (inCartQuantity > 0) {
            DetailHeroBadge(icon = Icons.Filled.ShoppingBag, text = "$inCartQuantity in cart")
          }
        }
      }

      // Full Description Section
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = "About This Dish",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = item.description,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.testTag("detail_full_description"),
          )
        }
      }

      // Ingredients List Section
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("detail_ingredients_section"),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.Restaurant,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
              text = "Ingredients (${ingredients.size})",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
          }
          ingredients.forEach { ingredient ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = CircleShape,
                modifier = Modifier.size(22.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(13.dp),
                  )
                }
              }
              Spacer(Modifier.width(10.dp))
              Text(
                text = ingredient,
                style = MaterialTheme.typography.bodyMedium,
              )
            }
          }
        }
      }

      // Nutritional Information Card
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("detail_nutrition_section"),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.LocalFireDepartment,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
              )
              Spacer(Modifier.width(8.dp))
              Text(
                text = "Nutritional Information",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
              )
            }
            Text(
              text = nutrition.servingSize,
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            NutritionMacroTile(
              label = "Calories",
              value = "${nutrition.calories}",
              unit = "kcal",
              modifier = Modifier.weight(1f),
            )
            NutritionMacroTile(
              label = "Protein",
              value = "${nutrition.proteinGrams}",
              unit = "g",
              modifier = Modifier.weight(1f),
            )
            NutritionMacroTile(
              label = "Carbs",
              value = "${nutrition.carbsGrams}",
              unit = "g",
              modifier = Modifier.weight(1f),
            )
            NutritionMacroTile(
              label = "Fat",
              value = "${nutrition.fatGrams}",
              unit = "g",
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Size & Customization Options
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          if (item.premiumPrice > item.price) {
            Text("Choose Size", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              FilterChip(
                selected = !isPremium,
                onClick = { isPremium = false },
                label = { Text(if (item.category == "pizza") "8\" Regular (৳${item.price})" else "Standard (৳${item.price})") },
              )
              FilterChip(
                selected = isPremium,
                onClick = { isPremium = true },
                label = { Text(if (item.category == "pizza") "12\" Premium (৳${item.premiumPrice})" else "Large Combo (৳${item.premiumPrice})") },
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column {
              Text("Extra Molten Mozzarella", style = MaterialTheme.typography.titleMedium)
              Text("+৳60 per item", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = extraCheese, onCheckedChange = { extraCheese = it })
          }
        }
      }
    }

    // Sticky Bottom Add-to-Cart Bar
    Surface(
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp,
      shadowElevation = 8.dp,
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = { if (quantity > 1) quantity-- },
            enabled = item.available,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Filled.Remove, contentDescription = "Decrease quantity")
          }
          Text("$quantity", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 8.dp))
          IconButton(
            onClick = { if (quantity < 20) quantity++ },
            enabled = item.available,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Filled.Add, contentDescription = "Increase quantity")
          }
        }

        Button(
          onClick = { onConfirmAdd(isPremium, extraCheese, quantity) },
          enabled = item.available,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.height(52.dp).testTag("confirm_add_to_cart_button"),
        ) {
          Text(
            if (item.available) "Add to Cart • ৳${unitPrice * quantity}" else "Currently Sold Out"
          )
        }
      }
    }
  }
}

@Composable
private fun DetailHeroBadge(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  text: String,
) {
  Surface(
    color = Color.Black.copy(alpha = 0.55f),
    shape = RoundedCornerShape(50),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
      Spacer(Modifier.width(4.dp))
      Text(text, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
  }
}

@Composable
private fun NutritionMacroTile(
  label: String,
  value: String,
  unit: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 1.dp,
  ) {
    Column(
      modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
      )
      Text(
        text = unit,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(Modifier.height(2.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
      )
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CartCheckoutSheet(
  cart: List<CartItem>,
  cartUiState: ShoppingCartUiState,
  promoFeedback: PromoFeedback?,
  userProfile: UserProfile?,
  biometricEnabled: Boolean,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onUpdateQuantity: (CartItem, Int) -> Unit,
  onRemoveCartItem: (CartItem) -> Unit,
  onApplyPromoCode: (String) -> Unit,
  onRemovePromoCode: () -> Unit,
  onClearCart: () -> Unit,
  onPlaceOrder: (String, String, String, String, String, String, String) -> Unit,
) {
  val context = LocalContext.current
  var name by remember(userProfile) { mutableStateOf(userProfile?.displayName ?: "") }
  var phone by remember(userProfile) { mutableStateOf(userProfile?.phone?.ifBlank { StoreInfo.PHONE } ?: StoreInfo.PHONE) }
  var address by remember(userProfile) { mutableStateOf(userProfile?.deliveryAddress?.ifBlank { "Ambarkhana, Sylhet" } ?: "Ambarkhana, Sylhet") }
  var notes by remember { mutableStateOf("") }
  var promoInput by remember(cartUiState.appliedPromoCode) { mutableStateOf(cartUiState.appliedPromoCode) }
  var paymentMethod by remember { mutableStateOf("bkash") }
  var paymentRef by remember { mutableStateOf("") }
  var validationError by remember { mutableStateOf<String?>(null) }

  val subtotal = cartUiState.subtotal
  val deliveryFee = cartUiState.deliveryFee
  val discount = cartUiState.discount
  val total = cartUiState.total

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(strings.checkoutTitle, style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = onClearCart) {
          Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text("Clear")
        }
      }

      cart.forEach { entry ->
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(14.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(entry.menuItem.name, style = MaterialTheme.typography.titleMedium)
              Text(
                text = "${entry.sizeLabel}${if (entry.extraCheese) " • +Extra Cheese" else ""}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Text(
                text = "৳${entry.lineTotal}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
              )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = { onUpdateQuantity(entry, -1) }) {
                Icon(Icons.Filled.Remove, contentDescription = "Decrease")
              }
              Text("${entry.quantity}", style = MaterialTheme.typography.titleMedium)
              IconButton(onClick = { onUpdateQuantity(entry, 1) }) {
                Icon(Icons.Filled.Add, contentDescription = "Increase")
              }
              IconButton(
                onClick = { onRemoveCartItem(entry) },
                modifier = Modifier.testTag("remove_cart_item_${entry.menuItem.id}"),
              ) {
                Icon(
                  imageVector = Icons.Filled.DeleteOutline,
                  contentDescription = "Remove item",
                  tint = MaterialTheme.colorScheme.error,
                )
              }
            }
          }
        }
      }

      HorizontalDivider()

      OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text("Recipient Name") },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
      )
      OutlinedTextField(
        value = phone,
        onValueChange = { phone = it },
        label = { Text("Sylhet Contact Number") },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
      )
      OutlinedTextField(
        value = address,
        onValueChange = { address = it },
        label = { Text("Delivery Address (Sylhet)") },
        modifier = Modifier.fillMaxWidth(),
      )

      // Promo Code Section
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedTextField(
            value = promoInput,
            onValueChange = { promoInput = it.uppercase() },
            label = { Text("Promo Code") },
            placeholder = { Text("HUB10, SYLHET50, PIZZA100") },
            leadingIcon = { Icon(Icons.Filled.LocalOffer, contentDescription = null) },
            trailingIcon = {
              if (promoInput.isNotEmpty()) {
                IconButton(
                  onClick = {
                    promoInput = ""
                    onRemovePromoCode()
                  },
                  modifier = Modifier.testTag("clear_promo_input"),
                ) {
                  Icon(Icons.Filled.Clear, contentDescription = "Clear promo code")
                }
              }
            },
            modifier = Modifier.weight(1f).testTag("cart_promo_input"),
            singleLine = true,
          )
          Button(
            onClick = { onApplyPromoCode(promoInput) },
            enabled = promoInput.isNotBlank() && cart.isNotEmpty(),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.height(54.dp).testTag("apply_promo_button"),
          ) {
            Text("Apply")
          }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(PromoCodeEngine.availablePromos, key = { it.code }) { promo ->
            val isSelected = cartUiState.appliedPromoCode == promo.code
            FilterChip(
              selected = isSelected,
              onClick = {
                promoInput = promo.code
                onApplyPromoCode(promo.code)
              },
              label = { Text("${promo.code} (${promo.label})") },
              modifier = Modifier.testTag("promo_chip_${promo.code}"),
            )
          }
          if (cartUiState.appliedPromoCode.isNotBlank()) {
            item(key = "remove_applied_promo") {
              FilterChip(
                selected = false,
                onClick = {
                  promoInput = ""
                  onRemovePromoCode()
                },
                leadingIcon = { Icon(Icons.Filled.Clear, contentDescription = null, modifier = Modifier.size(16.dp)) },
                label = { Text("Remove") },
                modifier = Modifier.testTag("remove_promo_button"),
              )
            }
          }
        }

        if (promoFeedback != null) {
          val isSuccess = promoFeedback is PromoFeedback.Applied
          val msg = when (promoFeedback) {
            is PromoFeedback.Applied -> promoFeedback.message
            is PromoFeedback.Error -> promoFeedback.message
          }
          Surface(
            color = if (isSuccess) {
              MaterialTheme.colorScheme.tertiaryContainer
            } else {
              MaterialTheme.colorScheme.errorContainer
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("promo_feedback_banner"),
          ) {
            Text(
              text = msg,
              style = MaterialTheme.typography.labelMedium,
              color = if (isSuccess) {
                MaterialTheme.colorScheme.onTertiaryContainer
              } else {
                MaterialTheme.colorScheme.onErrorContainer
              },
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            )
          }
        }
      }

      OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("Kitchen / Rider Instructions") },
        modifier = Modifier.fillMaxWidth(),
      )

      Text("Payment Gateway", style = MaterialTheme.typography.titleMedium)
      val gateways = listOf(
        Triple("bkash", "bKash", Icons.Filled.PhoneAndroid),
        Triple("nagad", "Nagad", Icons.Filled.PhoneAndroid),
        Triple("card", "Card", Icons.Filled.CreditCard),
        Triple("cod", "Cash", Icons.Filled.Payments),
      )
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(gateways) { (key, label, icon) ->
          FilterChip(
            selected = paymentMethod == key,
            onClick = { paymentMethod = key },
            leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
            label = { Text(label) },
            modifier = Modifier.testTag("gateway_$key"),
          )
        }
      }

      if (paymentMethod != "cod") {
        OutlinedTextField(
          value = paymentRef,
          onValueChange = { paymentRef = it },
          label = { Text("${paymentMethod.uppercase()} Transaction / Last 4 Digits (Optional)") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
        )
      }

      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(16.dp),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Subtotal")
            Text("৳$subtotal", style = MaterialTheme.typography.labelLarge)
          }
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Sylhet Delivery (Free >= ৳800)")
            Text(if (deliveryFee == 0L) "FREE" else "৳$deliveryFee", style = MaterialTheme.typography.labelLarge)
          }
          if (discount > 0L) {
            Row(
              modifier = Modifier.fillMaxWidth().testTag("checkout_discount_row"),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = if (cartUiState.appliedPromoCode.isNotBlank()) {
                  "Promo (${cartUiState.appliedPromoCode})"
                } else {
                  "Promo Discount"
                },
                color = MaterialTheme.colorScheme.tertiary,
              )
              Text("-৳$discount", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelLarge)
            }
          }
          HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Grand Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
              text = "৳$total",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.testTag("checkout_final_total"),
            )
          }
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.tertiary)
            Spacer(Modifier.width(6.dp))
            Text(
              text = "AES-256-GCM Encrypted Receipt & SHA-256 Verified",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.tertiary,
            )
          }
        }
      }

      if (!validationError.isNullOrBlank()) {
        Text(
          text = validationError.orEmpty(),
          color = MaterialTheme.colorScheme.error,
          style = MaterialTheme.typography.bodyMedium,
        )
      }

      Button(
        onClick = {
          if (phone.trim().length < 5 || address.trim().length < 4) {
            validationError = "Please enter a valid Sylhet phone number and delivery address."
            return@Button
          }
          validationError = null
          val effectivePromo = cartUiState.appliedPromoCode.ifBlank { promoInput }
          val activity = context as? FragmentActivity
          if (biometricEnabled && activity != null && BiometricHelper.isAvailable(activity)) {
            BiometricHelper.authenticate(
              activity = activity,
              title = "Confirm Pizza Hub Order",
              subtitle = "Verify biometrics to authorize ৳$total checkout",
              onSuccess = {
                onPlaceOrder(name, phone, address, paymentMethod, paymentRef, effectivePromo, notes)
              },
              onFallbackOrError = { err ->
                validationError = err
              },
            )
          } else {
            onPlaceOrder(name, phone, address, paymentMethod, paymentRef, effectivePromo, notes)
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .padding(bottom = 8.dp)
          .testTag("place_order_button"),
        shape = RoundedCornerShape(16.dp),
      ) {
        if (biometricEnabled) {
          Icon(Icons.Filled.Fingerprint, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(Modifier.width(8.dp))
        } else {
          Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(Modifier.width(8.dp))
        }
        Text("${strings.placeOrder} • ৳$total", style = MaterialTheme.typography.titleMedium)
      }
    }
  }
}
