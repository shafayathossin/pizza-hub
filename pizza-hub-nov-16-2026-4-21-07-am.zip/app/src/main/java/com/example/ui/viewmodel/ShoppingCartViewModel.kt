package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CartItem
import com.example.data.model.MenuItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

sealed interface PromoFeedback {
  data class Applied(val code: String, val discountAmount: Long, val message: String) : PromoFeedback
  data class Error(val message: String) : PromoFeedback
}

object PromoCodeEngine {
  data class PromoDefinition(
    val code: String,
    val label: String,
    val minSubtotal: Long,
  )

  val availablePromos = listOf(
    PromoDefinition("HUB10", "10% OFF", 0L),
    PromoDefinition("SYLHET50", "৳50 OFF", 150L),
    PromoDefinition("PIZZA100", "৳100 OFF", 500L),
  )

  fun evaluate(rawCode: String, subtotal: Long): PromoFeedback {
    val code = rawCode.trim().uppercase()
    if (code.isEmpty()) {
      return PromoFeedback.Error("Enter a promo code such as HUB10, SYLHET50, or PIZZA100.")
    }
    if (subtotal <= 0L) {
      return PromoFeedback.Error("Add items to your cart before applying a promo code.")
    }
    return when (code) {
      "HUB10" -> {
        val discount = ((subtotal * 10L) / 100L).coerceAtMost(subtotal)
        PromoFeedback.Applied(code, discount, "HUB10 applied: 10% off (-৳$discount)")
      }
      "SYLHET50" -> {
        if (subtotal < 150L) {
          PromoFeedback.Error("SYLHET50 requires a minimum subtotal of ৳150.")
        } else {
          val discount = 50L.coerceAtMost(subtotal)
          PromoFeedback.Applied(code, discount, "SYLHET50 applied: ৳$discount off")
        }
      }
      "PIZZA100" -> {
        if (subtotal < 500L) {
          PromoFeedback.Error("PIZZA100 requires a minimum subtotal of ৳500.")
        } else {
          val discount = 100L.coerceAtMost(subtotal)
          PromoFeedback.Applied(code, discount, "PIZZA100 applied: ৳$discount off")
        }
      }
      else -> PromoFeedback.Error("Invalid promo code \"$code\". Try HUB10, SYLHET50, or PIZZA100.")
    }
  }
}

data class ShoppingCartUiState(
  val items: List<CartItem> = emptyList(),
  val totalQuantity: Int = 0,
  val subtotal: Long = 0L,
  val deliveryFee: Long = 0L,
  val appliedPromoCode: String = "",
  val discount: Long = 0L,
  val total: Long = 0L,
)

class ShoppingCartViewModel : ViewModel() {

  private val _items = MutableStateFlow<List<CartItem>>(emptyList())
  val items: StateFlow<List<CartItem>> = _items.asStateFlow()

  private val _appliedPromoCode = MutableStateFlow("")
  val appliedPromoCode: StateFlow<String> = _appliedPromoCode.asStateFlow()

  private val _promoFeedback = MutableStateFlow<PromoFeedback?>(null)
  val promoFeedback: StateFlow<PromoFeedback?> = _promoFeedback.asStateFlow()

  val uiState: StateFlow<ShoppingCartUiState> = combine(_items, _appliedPromoCode) { list, promoCode ->
    val subtotal = list.sumOf { it.lineTotal }
    val deliveryFee = when {
      list.isEmpty() -> 0L
      subtotal >= 800L -> 0L
      else -> 50L
    }
    val discount = if (list.isEmpty() || promoCode.isBlank()) {
      0L
    } else {
      when (val eval = PromoCodeEngine.evaluate(promoCode, subtotal)) {
        is PromoFeedback.Applied -> eval.discountAmount
        is PromoFeedback.Error -> 0L
      }
    }
    val total = if (list.isEmpty()) 0L else (subtotal + deliveryFee - discount).coerceAtLeast(1L)
    ShoppingCartUiState(
      items = list,
      totalQuantity = list.sumOf { it.quantity },
      subtotal = subtotal,
      deliveryFee = deliveryFee,
      appliedPromoCode = if (discount > 0L) promoCode else "",
      discount = discount,
      total = total,
    )
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), ShoppingCartUiState())

  fun applyPromoCode(rawCode: String): PromoFeedback {
    val subtotal = _items.value.sumOf { it.lineTotal }
    val feedback = PromoCodeEngine.evaluate(rawCode, subtotal)
    _promoFeedback.value = feedback
    if (feedback is PromoFeedback.Applied) {
      _appliedPromoCode.value = feedback.code
    }
    return feedback
  }

  fun removePromoCode() {
    _appliedPromoCode.value = ""
    _promoFeedback.value = null
  }

  fun clearPromoFeedback() {
    _promoFeedback.value = null
  }

  fun addItem(
    item: MenuItem,
    isPremiumSize: Boolean = false,
    extraCheese: Boolean = false,
    quantity: Int = 1,
  ) {
    _items.update { current ->
      val idx = current.indexOfFirst {
        it.menuItem.id == item.id &&
          it.isPremiumSize == isPremiumSize &&
          it.extraCheese == extraCheese
      }
      if (idx >= 0) {
        current.toMutableList().also { list ->
          val existing = list[idx]
          list[idx] = existing.copy(quantity = (existing.quantity + quantity).coerceAtMost(25))
        }
      } else {
        current + CartItem(
          menuItem = item,
          isPremiumSize = isPremiumSize,
          quantity = quantity.coerceIn(1, 25),
          extraCheese = extraCheese,
        )
      }
    }
  }

  fun updateQuantity(cartItem: CartItem, delta: Int) {
    _items.update { current ->
      current.mapNotNull { entry ->
        if (entry == cartItem) {
          val nextQty = entry.quantity + delta
          if (nextQty <= 0) null else entry.copy(quantity = nextQty.coerceAtMost(25))
        } else {
          entry
        }
      }
    }
  }

  fun removeItem(cartItem: CartItem) {
    _items.update { current -> current.filterNot { it == cartItem } }
  }

  fun decrementOrRemoveMenuItem(menuItemId: String) {
    _items.update { current ->
      val idx = current.indexOfLast { it.menuItem.id == menuItemId }
      if (idx < 0) return@update current
      val entry = current[idx]
      if (entry.quantity <= 1) {
        current.toMutableList().apply { removeAt(idx) }
      } else {
        current.toMutableList().apply { set(idx, entry.copy(quantity = entry.quantity - 1)) }
      }
    }
  }

  fun removeAllOfMenuItem(menuItemId: String) {
    _items.update { current -> current.filterNot { it.menuItem.id == menuItemId } }
  }

  fun clearCart() {
    _items.value = emptyList()
    _appliedPromoCode.value = ""
    _promoFeedback.value = null
  }
}
