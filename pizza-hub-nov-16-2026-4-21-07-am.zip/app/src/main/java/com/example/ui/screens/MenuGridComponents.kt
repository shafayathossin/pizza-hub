package com.example.ui.screens

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BakeryDining
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalPizza
import androidx.compose.material.icons.filled.LunchDining
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.MenuItem
import com.example.data.model.StoreInfo
import com.example.util.AppStrings
import com.example.util.ImageUtils

internal data class ResponsiveGridSpec(
  val columns: Int,
  val horizontalPadding: Dp,
  val spacing: Dp,
  val imageHeight: Dp,
  val isWideLayout: Boolean,
)

internal fun computeResponsiveGridSpec(maxWidth: Dp): ResponsiveGridSpec = when {
  maxWidth < 320.dp -> ResponsiveGridSpec(
    columns = 1,
    horizontalPadding = 12.dp,
    spacing = 10.dp,
    imageHeight = 160.dp,
    isWideLayout = false,
  )
  maxWidth < 540.dp -> ResponsiveGridSpec(
    columns = 2,
    horizontalPadding = 14.dp,
    spacing = 10.dp,
    imageHeight = 126.dp,
    isWideLayout = false,
  )
  maxWidth < 800.dp -> ResponsiveGridSpec(
    columns = 3,
    horizontalPadding = 18.dp,
    spacing = 14.dp,
    imageHeight = 142.dp,
    isWideLayout = true,
  )
  else -> ResponsiveGridSpec(
    columns = 4,
    horizontalPadding = 20.dp,
    spacing = 16.dp,
    imageHeight = 152.dp,
    isWideLayout = true,
  )
}

internal data class MenuCategoryMeta(
  val key: String,
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  @DrawableRes val drawableRes: Int,
)

internal fun categoryOrderIndex(category: String): Int = when (category.lowercase()) {
  "pizza" -> 0
  "burger" -> 1
  "sandwich" -> 2
  "sides" -> 3
  else -> 4
}

internal fun categoryMetaFor(category: String, strings: AppStrings): MenuCategoryMeta = when (category.lowercase()) {
  "pizza" -> MenuCategoryMeta(
    key = "pizza",
    title = strings.pizzaCategory,
    subtitle = "Stone-baked crust",
    icon = Icons.Filled.LocalPizza,
    drawableRes = R.drawable.img_pizza_category,
  )
  "burger" -> MenuCategoryMeta(
    key = "burger",
    title = strings.burgerCategory,
    subtitle = "Seared & loaded",
    icon = Icons.Filled.LunchDining,
    drawableRes = R.drawable.img_burger_category,
  )
  "sandwich" -> MenuCategoryMeta(
    key = "sandwich",
    title = strings.sandwichCategory,
    subtitle = "Toasted artisan subs",
    icon = Icons.Filled.BakeryDining,
    drawableRes = R.drawable.img_sandwich_category,
  )
  "sides" -> MenuCategoryMeta(
    key = "sides",
    title = strings.sidesCategory,
    subtitle = "Baked pasta & dips",
    icon = Icons.Filled.RestaurantMenu,
    drawableRes = R.drawable.img_hero_pizzahub,
  )
  else -> MenuCategoryMeta(
    key = category,
    title = category.replaceFirstChar { it.uppercase() },
    subtitle = "Chef specials",
    icon = Icons.Filled.RestaurantMenu,
    drawableRes = R.drawable.img_hero_pizzahub,
  )
}

@Composable
internal fun HeroStoreBanner(lowBandwidthSync: Boolean) {
  Card(
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(if (lowBandwidthSync) 124.dp else 160.dp),
    ) {
      if (!lowBandwidthSync) {
        Image(
          painter = painterResource(id = R.drawable.img_hero_pizzahub),
          contentDescription = "Pizza Hub Sylhet signature dishes",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.horizontalGradient(
                listOf(Color(0xDD1A110E), Color(0x551A110E))
              )
            ),
        )
      } else {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.primaryContainer),
        )
      }

      val titleColor = if (lowBandwidthSync) MaterialTheme.colorScheme.onPrimaryContainer else Color.White
      val bodyColor = if (lowBandwidthSync) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.88f)

      Column(
        modifier = Modifier
          .align(Alignment.CenterStart)
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Surface(
          color = MaterialTheme.colorScheme.secondary,
          shape = RoundedCornerShape(50),
        ) {
          Text(
            text = "USE CODE HUB10 • 10% OFF",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          )
        }
        Text(
          text = "Eastern Plaza, Ambarkhana",
          style = MaterialTheme.typography.headlineSmall,
          color = titleColor,
        )
        Text(
          text = "${StoreInfo.HOURS} • Call ${StoreInfo.PHONE}",
          style = MaterialTheme.typography.bodyMedium,
          color = bodyColor,
        )
      }
    }
  }
}

@Composable
internal fun CategoryShowcaseRow(
  categories: List<MenuCategoryMeta>,
  itemsByCategory: Map<String, List<MenuItem>>,
  selectedCategory: String,
  lowBandwidthSync: Boolean,
  isWideLayout: Boolean,
  onSelectCategory: (String) -> Unit,
) {
  val cardWidth = if (isWideLayout) 156.dp else 134.dp
  val cardHeight = if (isWideLayout) 96.dp else 86.dp

  Column(
    modifier = Modifier.fillMaxWidth().testTag("category_showcase_row"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "Browse by Category",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
      )
      if (selectedCategory != "all") {
        TextButton(
          onClick = { onSelectCategory("all") },
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
        ) {
          Text("Show All", style = MaterialTheme.typography.labelLarge)
        }
      }
    }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      items(categories, key = { "showcase_${it.key}" }) { meta ->
        val groupItems = itemsByCategory[meta.key].orEmpty()
        val isSelected = selectedCategory == meta.key
        val minPrice = groupItems.minOfOrNull { it.price }
        val borderColor by animateColorAsState(
          targetValue = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
          label = "catBorder",
        )

        Card(
          modifier = Modifier
            .width(cardWidth)
            .height(cardHeight)
            .testTag("category_showcase_card_${meta.key}")
            .clickable { onSelectCategory(if (isSelected) "all" else meta.key) },
          shape = RoundedCornerShape(18.dp),
          border = BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor),
          elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp),
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            if (!lowBandwidthSync) {
              Image(
                painter = painterResource(id = meta.drawableRes),
                contentDescription = meta.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(
                    Brush.verticalGradient(
                      listOf(
                        Color(0x33160D09),
                        if (isSelected) Color(0xD97F1D1D) else Color(0xCC160D09),
                      )
                    )
                  ),
              )
            } else {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(
                    if (isSelected) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                  ),
              )
            }

            val textColor = if (lowBandwidthSync) MaterialTheme.colorScheme.onSurface else Color.White

            Surface(
              color = if (isSelected) MaterialTheme.colorScheme.secondary else Color.Black.copy(alpha = 0.45f),
              shape = CircleShape,
              modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
            ) {
              Text(
                text = "${groupItems.size}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) MaterialTheme.colorScheme.onSecondary else Color.White,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
              )
            }

            Column(
              modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(
                  imageVector = meta.icon,
                  contentDescription = null,
                  tint = textColor,
                  modifier = Modifier.size(15.dp),
                )
                Text(
                  text = meta.title,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = textColor,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              if (minPrice != null) {
                Text(
                  text = "From ৳$minPrice",
                  style = MaterialTheme.typography.labelSmall,
                  color = textColor.copy(alpha = 0.85f),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
internal fun CategorySectionHeader(
  meta: MenuCategoryMeta,
  itemCount: Int,
  minPrice: Long?,
  isFilteredSingleCategory: Boolean,
  onToggleCategoryFocus: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(top = 6.dp, bottom = 2.dp)
      .testTag("category_section_header_${meta.key}"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.weight(1f),
    ) {
      Box(
        modifier = Modifier
          .width(4.dp)
          .height(30.dp)
          .clip(RoundedCornerShape(4.dp))
          .background(MaterialTheme.colorScheme.primary),
      )
      Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = CircleShape,
        modifier = Modifier.size(34.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = meta.icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(18.dp),
          )
        }
      }
      Column {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = meta.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Surface(
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(50),
          ) {
            Text(
              text = "$itemCount",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
            )
          }
        }
        Text(
          text = if (minPrice != null) "${meta.subtitle} • Starting ৳$minPrice" else meta.subtitle,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }

    TextButton(
      onClick = onToggleCategoryFocus,
      contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
    ) {
      Text(
        text = if (isFilteredSingleCategory) "All" else "Focus",
        style = MaterialTheme.typography.labelLarge,
      )
    }
  }
}

@Composable
internal fun MenuItemImage(
  item: MenuItem,
  lowBandwidthSync: Boolean,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val customBitmap by produceState<ImageBitmap?>(
    initialValue = if (lowBandwidthSync) null else ImageUtils.cachedBase64Bitmap(item.imageBase64),
    key1 = item.imageBase64,
    key2 = lowBandwidthSync,
  ) {
    value = if (lowBandwidthSync || item.imageBase64.isNullOrBlank()) {
      null
    } else {
      ImageUtils.decodeBase64Async(item.imageBase64)
    }
  }

  val fallbackRes = remember(item.imageKey, item.category) {
    ImageUtils.drawableForKey(item.imageKey, item.category)
  }

  Box(
    modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
    contentAlignment = Alignment.Center,
  ) {
    if (lowBandwidthSync) {
      Icon(
        imageVector = Icons.Filled.LocalPizza,
        contentDescription = item.name,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(36.dp),
      )
    } else if (customBitmap != null) {
      Image(
        bitmap = customBitmap!!,
        contentDescription = item.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
    } else if (item.imageUrl.isNotBlank()) {
      val imageRequest = remember(context, item.imageUrl, fallbackRes) {
        ImageRequest.Builder(context)
          .data(item.imageUrl)
          .crossfade(120)
          .allowRgb565(true)
          .size(420)
          .placeholder(fallbackRes)
          .error(fallbackRes)
          .build()
      }
      AsyncImage(
        model = imageRequest,
        contentDescription = item.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
    } else {
      Image(
        painter = painterResource(id = fallbackRes),
        contentDescription = item.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
    }

    if (!item.available) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
      ) {
        Text("Sold Out", color = Color.White, style = MaterialTheme.typography.labelMedium)
      }
    }
  }
}

@Composable
internal fun SavedFavoritesQuickSection(
  favorites: List<MenuItem>,
  lowBandwidthSync: Boolean,
  onOpenAllFavorites: () -> Unit,
  onItemClick: (MenuItem) -> Unit,
  onQuickAdd: (MenuItem) -> Unit,
) {
  Column(
    modifier = Modifier.fillMaxWidth().testTag("saved_favorites_section"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Favorite,
          contentDescription = null,
          tint = Color(0xFFE53935),
          modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(6.dp))
        Text(
          text = "Your Saved Favorites (${favorites.size})",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
        )
      }
      OutlinedButton(
        onClick = onOpenAllFavorites,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = Modifier.testTag("see_all_favorites_button"),
      ) {
        Text("View All", style = MaterialTheme.typography.labelMedium)
      }
    }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      items(favorites, key = { "fav_quick_${it.id}" }) { favItem ->
        Card(
          modifier = Modifier
            .width(188.dp)
            .clickable { onItemClick(favItem) }
            .testTag("quick_favorite_card_${favItem.id}"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            MenuItemImage(
              item = favItem,
              lowBandwidthSync = lowBandwidthSync,
              modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)),
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = favItem.name,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "৳${favItem.price}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
              )
            }
            IconButton(
              onClick = { onQuickAdd(favItem) },
              enabled = favItem.available,
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Filled.Add, contentDescription = "Quick add ${favItem.name}", tint = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }
  }
}

@Composable
internal fun MenuItemGridCard(
  item: MenuItem,
  inCartQuantity: Int,
  isFavorite: Boolean,
  lowBandwidthSync: Boolean,
  imageHeight: Dp,
  addLabel: String,
  onClick: () -> Unit,
  onToggleFavorite: () -> Unit,
  onQuickAdd: () -> Unit,
  onDecrement: () -> Unit,
) {
  val heartScale by animateFloatAsState(
    targetValue = if (isFavorite) 1.15f else 1.0f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
    label = "heartScale",
  )

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("menu_card_${item.id}")
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.16f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(imageHeight)
          .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
      ) {
        MenuItemImage(
          item = item,
          lowBandwidthSync = lowBandwidthSync,
          modifier = Modifier.fillMaxSize(),
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color.Transparent, Color(0x99120A07))
              )
            ),
        )
        Surface(
          color = if (item.isVeg) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
        ) {
          Text(
            text = if (item.isVeg) "VEG" else item.category.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (item.isVeg) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
          )
        }
        IconButton(
          onClick = onToggleFavorite,
          modifier = Modifier
            .align(Alignment.TopEnd)
            .minimumInteractiveComponentSize()
            .testTag("favorite_toggle_${item.id}"),
        ) {
          Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
            shape = CircleShape,
            modifier = Modifier.size(34.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = if (isFavorite) "Remove ${item.name} from favorites" else "Save ${item.name} to favorites",
                tint = if (isFavorite) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp).scale(heartScale),
              )
            }
          }
        }
        Surface(
          color = Color.Black.copy(alpha = 0.58f),
          shape = RoundedCornerShape(50),
          modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Star,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(12.dp),
            )
            Text(
              text = "${item.ratingAvg}",
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
            )
            Text(
              text = "•",
              style = MaterialTheme.typography.labelSmall,
              color = Color.White.copy(alpha = 0.7f),
            )
            Icon(
              imageVector = Icons.Filled.Timer,
              contentDescription = null,
              tint = Color.White.copy(alpha = 0.85f),
              modifier = Modifier.size(11.dp),
            )
            Text(
              text = "${item.prepMinutes}m",
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
            )
          }
        }
        if (inCartQuantity > 0) {
          Surface(
            color = MaterialTheme.colorScheme.primary,
            shape = CircleShape,
            modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp),
          ) {
            Text(
              text = "${inCartQuantity}x",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimary,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
          }
        }
      }

      Column(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Text(
          text = item.name,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )

        Text(
          text = item.description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          minLines = 2,
        )

        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column {
            Text(
              text = "৳${item.price}",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold,
            )
            if (item.premiumPrice > item.price) {
              Text(
                text = "Lg ৳${item.premiumPrice}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          if (inCartQuantity > 0) {
            Surface(
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
              shape = RoundedCornerShape(12.dp),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = onDecrement,
                  modifier = Modifier.size(34.dp).testTag("dec_item_${item.id}"),
                ) {
                  Icon(Icons.Filled.Remove, contentDescription = "Remove one", modifier = Modifier.size(16.dp))
                }
                Text(
                  text = "$inCartQuantity",
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 2.dp),
                )
                IconButton(
                  onClick = onQuickAdd,
                  enabled = item.available,
                  modifier = Modifier.size(34.dp).testTag("inc_item_${item.id}"),
                ) {
                  Icon(Icons.Filled.Add, contentDescription = "Add one more", modifier = Modifier.size(16.dp))
                }
              }
            }
          } else {
            Button(
              onClick = onQuickAdd,
              enabled = item.available,
              shape = RoundedCornerShape(12.dp),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
              modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("add_item_${item.id}"),
            ) {
              Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(15.dp))
              Spacer(Modifier.width(3.dp))
              Text(addLabel, style = MaterialTheme.typography.labelMedium)
            }
          }
        }
      }
    }
  }
}
