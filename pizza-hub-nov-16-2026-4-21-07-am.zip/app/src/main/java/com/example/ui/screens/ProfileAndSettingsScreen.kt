package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.R
import com.example.data.model.AuditLog
import com.example.data.model.StoreInfo
import com.example.data.model.UserProfile
import com.example.ui.viewmodel.UiState
import com.example.util.AppStrings
import com.example.util.BiometricHelper
import com.example.util.LocalAppSettings

@Composable
fun ProfileAndSettingsScreen(
  userProfile: UserProfile?,
  userEmail: String,
  currentUserId: String,
  isAdmin: Boolean,
  localSettings: LocalAppSettings,
  auditLogsState: UiState<List<AuditLog>>,
  strings: AppStrings,
  onSaveProfile: (String, String, String, String, String, Boolean, Boolean) -> Unit,
  onQuickDarkMode: (String) -> Unit,
  onQuickLanguage: (String) -> Unit,
  onOpenPurchaseHistory: () -> Unit,
  onSignOut: () -> Unit,
) {
  val context = LocalContext.current
  var displayName by remember(userProfile) { mutableStateOf(userProfile?.displayName ?: "") }
  var phone by remember(userProfile) { mutableStateOf(userProfile?.phone ?: "") }
  var address by remember(userProfile) { mutableStateOf(userProfile?.deliveryAddress ?: "Ambarkhana, Sylhet") }
  var biometricEnabled by remember(localSettings.biometricEnabled) { mutableStateOf(localSettings.biometricEnabled) }
  var lowBandwidth by remember(localSettings.lowBandwidthSync) { mutableStateOf(localSettings.lowBandwidthSync) }
  var biometricMsg by remember { mutableStateOf<String?>(null) }

  var notificationsGranted by remember {
    mutableStateOf(
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      } else {
        true
      }
    )
  }

  val notifLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission(),
    onResult = { granted -> notificationsGranted = granted },
  )

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // Account Header Card
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(14.dp)) {
              Icon(
                imageVector = if (isAdmin) Icons.Filled.AdminPanelSettings else Icons.Filled.Person,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(12.dp).size(28.dp),
              )
            }
            Spacer(Modifier.width(12.dp))
            Column {
              Text(
                text = displayName.ifBlank { "Pizza Hub Customer" },
                style = MaterialTheme.typography.titleLarge,
              )
              Text(userEmail, style = MaterialTheme.typography.bodyMedium)
              Text(
                text = "UID: ${currentUserId.take(10)}...",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Surface(
            color = if (isAdmin) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary,
            shape = RoundedCornerShape(50),
          ) {
            Text(
              text = if (isAdmin) "ADMIN" else "CUSTOMER",
              style = MaterialTheme.typography.labelSmall,
              color = ColorWhiteOrContrast(isAdmin),
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            )
          }
        }
      }
    }

    // Past Purchases Quick Link
    item {
      OutlinedButton(
        onClick = onOpenPurchaseHistory,
        modifier = Modifier.fillMaxWidth().testTag("profile_open_purchase_history"),
        shape = RoundedCornerShape(16.dp),
      ) {
        Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("View Past Purchases History")
      }
    }

    // Delivery Profile Editor
    item {
      Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Delivery Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          OutlinedTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = { Text("Display Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
          )
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Phone Number") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
          )
          OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("Default Sylhet Address") },
            modifier = Modifier.fillMaxWidth(),
          )
          Button(
            onClick = {
              onSaveProfile(
                displayName,
                phone,
                address,
                localSettings.language,
                localSettings.darkMode,
                biometricEnabled,
                lowBandwidth,
              )
            },
            modifier = Modifier.fillMaxWidth().testTag("save_profile_button"),
            shape = RoundedCornerShape(14.dp),
          ) {
            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Save Profile & Sync Settings")
          }
        }
      }
    }

    // Theme & Multi-Language
    item {
      Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text(strings.darkModeLabel, style = MaterialTheme.typography.titleMedium)
          }
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("system" to "System", "light" to "Light", "dark" to "Dark")) { (key, label) ->
              FilterChip(
                selected = localSettings.darkMode == key,
                onClick = { onQuickDarkMode(key) },
                label = { Text(label) },
                modifier = Modifier.testTag("theme_chip_$key"),
              )
            }
          }

          HorizontalDivider()

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text(strings.languageLabel, style = MaterialTheme.typography.titleMedium)
          }
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("en" to "English", "bn" to "বাংলা", "ar" to "العربية")) { (key, label) ->
              FilterChip(
                selected = localSettings.language == key,
                onClick = { onQuickLanguage(key) },
                label = { Text(label) },
                modifier = Modifier.testTag("lang_chip_$key"),
              )
            }
          }
        }
      }
    }

    // Security, Biometric, Offline Low-Bandwidth & Notifications
    item {
      Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(Modifier.width(10.dp))
              Column {
                Text(strings.biometricLabel, style = MaterialTheme.typography.titleMedium)
                Text("Require fingerprint/PIN before checkout", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            Switch(
              checked = biometricEnabled,
              onCheckedChange = { wantEnable ->
                val activity = context as? FragmentActivity
                if (wantEnable && activity != null && BiometricHelper.isAvailable(activity)) {
                  BiometricHelper.authenticate(
                    activity = activity,
                    title = "Enable Pizza Hub Biometric Guard",
                    subtitle = "Verify your identity to protect checkout",
                    onSuccess = {
                      biometricEnabled = true
                      biometricMsg = "Biometric protection enabled"
                      onSaveProfile(displayName, phone, address, localSettings.language, localSettings.darkMode, true, lowBandwidth)
                    },
                    onFallbackOrError = { err -> biometricMsg = err },
                  )
                } else {
                  biometricEnabled = wantEnable
                  biometricMsg = if (wantEnable && (activity == null || !BiometricHelper.isAvailable(activity))) {
                    "Device lock/biometrics unavailable on this device; preference saved"
                  } else {
                    null
                  }
                  onSaveProfile(displayName, phone, address, localSettings.language, localSettings.darkMode, wantEnable, lowBandwidth)
                }
              },
              modifier = Modifier.testTag("biometric_switch"),
            )
          }
          if (!biometricMsg.isNullOrBlank()) {
            Text(biometricMsg.orEmpty(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
          }

          HorizontalDivider()

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.OfflineBolt, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
              Spacer(Modifier.width(10.dp))
              Column {
                Text(strings.lowBandwidthLabel, style = MaterialTheme.typography.titleMedium)
                Text("Skip heavy images on slow mobile networks", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            Switch(
              checked = lowBandwidth,
              onCheckedChange = { enabled ->
                lowBandwidth = enabled
                onSaveProfile(displayName, phone, address, localSettings.language, localSettings.darkMode, biometricEnabled, enabled)
              },
              modifier = Modifier.testTag("low_bandwidth_switch"),
            )
          }

          HorizontalDivider()

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
              Spacer(Modifier.width(10.dp))
              Column {
                Text("Order Status Push Alerts", style = MaterialTheme.typography.titleMedium)
                Text(
                  text = if (notificationsGranted) "Active for live oven & rider updates" else "Tap to enable notifications",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            if (!notificationsGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
              OutlinedButton(onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                Text("Enable")
              }
            }
          }
        }
      }
    }

    // Conflict Resolution & LWW Audit Trail
    item {
      Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Sync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text("Sync Conflict & LWW Audit Log", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          }
          when (auditLogsState) {
            is UiState.Loading -> Text("Loading audit history...")
            is UiState.Error -> Text(auditLogsState.message, color = MaterialTheme.colorScheme.error)
            is UiState.Success -> {
              val logs = auditLogsState.data.take(6)
              if (logs.isEmpty()) {
                Text("No sync conflicts or mutations recorded yet.", style = MaterialTheme.typography.bodyMedium)
              } else {
                logs.forEach { log ->
                  Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                  ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                      Text(
                        text = "${log.action} • ${log.resolutionStrategy}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                      )
                      Text(log.details, style = MaterialTheme.typography.bodyMedium)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Official Store Info Card (pizzahubsylhet.com)
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(20.dp),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = Color(0xFFFEFEFE),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.size(48.dp),
            ) {
              Image(
                painter = painterResource(id = R.drawable.img_pizza_hub_logo),
                contentDescription = "Pizza Hub logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(4.dp),
              )
            }
            Spacer(Modifier.width(12.dp))
            Column {
              Text("${StoreInfo.BRAND_NAME} ${StoreInfo.SUBTITLE}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              Text(StoreInfo.WEBSITE, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
          }
          Text(StoreInfo.ADDRESS, style = MaterialTheme.typography.bodyMedium)
          Text("Phone: ${StoreInfo.PHONE} • Email: ${StoreInfo.EMAIL}", style = MaterialTheme.typography.bodyMedium)
          Text(StoreInfo.HOURS, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }

    // Sign Out
    item {
      Button(
        onClick = onSignOut,
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.errorContainer,
          contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("sign_out_button"),
      ) {
        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(strings.signOut, style = MaterialTheme.typography.titleMedium)
      }
      Spacer(Modifier.height(24.dp))
    }
  }
}

@Composable
private fun ColorWhiteOrContrast(isAdmin: Boolean) =
  if (isAdmin) MaterialTheme.colorScheme.onTertiary else MaterialTheme.colorScheme.onSecondary
