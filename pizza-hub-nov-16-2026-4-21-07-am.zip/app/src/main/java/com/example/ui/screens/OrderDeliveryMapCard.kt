package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.model.Order
import com.example.data.model.SylhetLocations
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun OrderDeliveryMapCard(
  order: Order,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  val isPlayServicesAvailable = remember(context) {
    runCatching {
      GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
    }.getOrDefault(false)
  }
  val hasValidMapsKey = remember {
    BuildConfig.MAPS_API_KEY.isNotBlank() && BuildConfig.MAPS_API_KEY != "MY_MAPS_API_KEY"
  }

  val animatedDriverLat by animateFloatAsState(
    targetValue = order.riderLat.toFloat(),
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "driverLat",
  )
  val animatedDriverLng by animateFloatAsState(
    targetValue = order.riderLng.toFloat(),
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "driverLng",
  )

  val kitchenPos = remember {
    LatLng(SylhetLocations.KITCHEN_LAT, SylhetLocations.KITCHEN_LNG)
  }
  val destPos = remember(order.destinationLat, order.destinationLng) {
    LatLng(order.destinationLat, order.destinationLng)
  }
  val driverPos = LatLng(animatedDriverLat.toDouble(), animatedDriverLng.toDouble())

  val distanceRemainingKm = remember(order.riderLat, order.riderLng, order.destinationLat, order.destinationLng) {
    SylhetLocations.distanceKm(
      order.riderLat,
      order.riderLng,
      order.destinationLat,
      order.destinationLng,
    )
  }

  val driverTitle = order.riderName.ifBlank { "Pizza Hub Rider" }
  val driverMarkerState = remember(order.id) { MarkerState(position = driverPos) }
  val kitchenMarkerState = remember(order.id) { MarkerState(position = kitchenPos) }
  val destMarkerState = remember(order.id) { MarkerState(position = destPos) }

  LaunchedEffect(animatedDriverLat, animatedDriverLng) {
    driverMarkerState.position = LatLng(animatedDriverLat.toDouble(), animatedDriverLng.toDouble())
  }
  LaunchedEffect(order.destinationLat, order.destinationLng) {
    destMarkerState.position = LatLng(order.destinationLat, order.destinationLng)
  }

  val cameraPositionState = rememberCameraPositionState {
    position = CameraPosition.fromLatLngZoom(driverPos, 14.5f)
  }
  var mapLoaded by remember(order.id) { mutableStateOf(false) }

  LaunchedEffect(context, isPlayServicesAvailable) {
    if (isPlayServicesAvailable) {
      runCatching { MapsInitializer.initialize(context.applicationContext) }
    }
  }

  fun recenterCamera() {
    coroutineScope.launch {
      runCatching {
        val bounds = LatLngBounds.builder()
          .include(kitchenPos)
          .include(driverPos)
          .include(destPos)
          .build()
        cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 72))
      }.onFailure {
        runCatching {
          cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(driverPos, 14.5f))
        }
      }
    }
  }

  LaunchedEffect(order.riderLat, order.riderLng, mapLoaded) {
    if (mapLoaded && isPlayServicesAvailable) {
      recenterCamera()
    }
  }

  Surface(
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
    shape = RoundedCornerShape(18.dp),
    modifier = modifier.fillMaxWidth().testTag("order_delivery_map_card_${order.id}"),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(
            imageVector = Icons.Filled.DeliveryDining,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
          )
          Spacer(Modifier.width(8.dp))
          Column {
            Text(
              text = "Live Driver Location",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "$driverTitle • ${String.format(Locale.US, "%.2f", distanceRemainingKm)} km away",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
        FilledTonalButton(
          onClick = { recenterCamera() },
          modifier = Modifier.testTag("recenter_map_${order.id}"),
        ) {
          Icon(Icons.Filled.MyLocation, contentDescription = "Recenter map", modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text("Recenter", style = MaterialTheme.typography.labelMedium)
        }
      }

      if (isPlayServicesAvailable) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(14.dp))
            .testTag("google_map_container_${order.id}"),
        ) {
          GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(mapType = MapType.NORMAL),
            uiSettings = MapUiSettings(
              zoomControlsEnabled = true,
              compassEnabled = true,
              mapToolbarEnabled = false,
            ),
            onMapLoaded = { mapLoaded = true },
          ) {
            Polyline(
              points = listOf(kitchenPos, driverPos, destPos),
              color = MaterialTheme.colorScheme.primary,
              width = 10f,
            )
            Marker(
              state = kitchenMarkerState,
              title = "Pizza Hub Sylhet Kitchen",
              snippet = "G-66 Eastern Plaza, Ambarkhana",
              icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE),
            )
            Marker(
              state = driverMarkerState,
              title = driverTitle,
              snippet = if (order.orderStatus == "out_for_delivery") {
                "En route • ETA ${order.etaMinutes} min"
              } else {
                "Status: ${order.orderStatus.replace('_', ' ')}"
              },
              icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE),
            )
            Marker(
              state = destMarkerState,
              title = "Delivery Destination",
              snippet = order.deliveryAddress,
              icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN),
            )
          }
        }
      } else {
        Surface(
          color = MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(
              text = "Google Play Services unavailable on this device/emulator",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold,
            )
            Text(
              text = "Live GPS coordinates are still synced in real time below.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }

      if (!hasValidMapsKey) {
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "Map tiles require MAPS_API_KEY configured in the AI Studio Secrets panel.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(Icons.Filled.Storefront, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
          Spacer(Modifier.width(4.dp))
          Text(
            text = String.format(Locale.US, "Rider: %.4f, %.4f", order.riderLat, order.riderLng),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(Icons.Filled.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.tertiary)
          Spacer(Modifier.width(4.dp))
          Text(
            text = order.deliveryAddress,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}
