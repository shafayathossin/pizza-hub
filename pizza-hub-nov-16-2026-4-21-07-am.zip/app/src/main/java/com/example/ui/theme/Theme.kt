package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = EmberRed,
  onPrimary = Color(0xFF690005),
  primaryContainer = EmberRedContainer,
  onPrimaryContainer = OnEmberRedContainer,
  secondary = CheddarGold,
  onSecondary = Color(0xFF4A1F00),
  secondaryContainer = CheddarGoldContainer,
  onSecondaryContainer = OnCheddarGoldContainer,
  tertiary = MintBasil,
  tertiaryContainer = MintBasilContainer,
  background = DarkBackground,
  onBackground = DarkOnSurface,
  surface = DarkSurface,
  onSurface = DarkOnSurface,
  surfaceVariant = DarkSurfaceVariant,
  onSurfaceVariant = DarkOnSurfaceVariant,
  outline = DarkOutline,
)

private val LightColorScheme = lightColorScheme(
  primary = BrickCrimson,
  onPrimary = Color.White,
  primaryContainer = BrickCrimsonContainer,
  onPrimaryContainer = OnBrickCrimsonContainer,
  secondary = MoltenAmber,
  onSecondary = Color.White,
  secondaryContainer = MoltenAmberContainer,
  onSecondaryContainer = OnMoltenAmberContainer,
  tertiary = BasilGreen,
  tertiaryContainer = BasilGreenContainer,
  onTertiaryContainer = OnBasilGreenContainer,
  background = LightBackground,
  onBackground = LightOnSurface,
  surface = LightSurface,
  onSurface = LightOnSurface,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = LightOnSurfaceVariant,
  outline = LightOutline,
)

@Composable
fun PizzaHubTheme(
  darkModePreference: String = "system",
  content: @Composable () -> Unit,
) {
  val useDark = when (darkModePreference) {
    "dark" -> true
    "light" -> false
    else -> isSystemInDarkTheme()
  }
  val colorScheme = if (useDark) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = PizzaHubTypography,
    content = content,
  )
}
