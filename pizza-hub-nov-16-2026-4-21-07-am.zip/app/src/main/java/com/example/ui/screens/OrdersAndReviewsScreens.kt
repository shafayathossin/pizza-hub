package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DefaultMenuCatalog
import com.example.data.model.MenuItem
import com.example.data.model.Order
import com.example.data.model.Review
import com.example.data.model.UserOrder
import com.example.data.repository.SyncSnapshot
import com.example.ui.viewmodel.UiState
import com.example.util.AppStrings
import com.example.util.CryptoSecurityHelper
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersAndTrackingScreen(
  ordersState: UiState<SyncSnapshot<Order>>,
  userOrderHistoryState: UiState<SyncSnapshot<UserOrder>>,
  reviewsState: UiState<List<Review>>,
  menuState: UiState<SyncSnapshot<MenuItem>>,
  currentUserId: String,
  encryptedVaultReceipt: String,
  strings: AppStrings,
  showHistoryTab: Boolean,
  onSelectHistoryTab: (Boolean) -> Unit,
  onCancelOrder: (Order) -> Unit,
  onReorderSummary: (String) -> Unit,
  onSubmitOrderReview: (MenuItem, Int, String, String) -> Unit,
  onReviewOrderItem: (String) -> Unit,
) {
  BackHandler(enabled = showHistoryTab) {
    onSelectHistoryTab(false)
  }

  Column(modifier = Modifier.fillMaxSize()) {
    PrimaryTabRow(selectedTabIndex = if (showHistoryTab) 1 else 0) {
      Tab(
        selected = !showHistoryTab,
        onClick = { onSelectHistoryTab(false) },
        text = { Text(strings.liveTracking, maxLines = 1) },
        icon = { Icon(Icons.Filled.DeliveryDining, contentDescription = null) },
        modifier = Modifier.testTag("orders_subtab_tracking"),
      )
      Tab(
        selected = showHistoryTab,
        onClick = { onSelectHistoryTab(true) },
        text = { Text(strings.orderHistory, maxLines = 1) },
        icon = { Icon(Icons.Filled.History, contentDescription = null) },
        modifier = Modifier.testTag("orders_subtab_history"),
      )
    }

    if (showHistoryTab) {
      PurchaseHistoryScreen(
        historyState = userOrderHistoryState,
        reviewsState = reviewsState,
        menuState = menuState,
        currentUserId = currentUserId,
        encryptedVaultReceipt = encryptedVaultReceipt,
        strings = strings,
        onReorder = { userOrder -> onReorderSummary(userOrder.itemsSummary) },
        onSubmitOrderReview = onSubmitOrderReview,
        onReviewOrderItem = onReviewOrderItem,
      )
    } else {
      LiveTrackingPane(
        ordersState = ordersState,
        strings = strings,
        onCancelOrder = onCancelOrder,
        onOpenPurchaseHistory = { onSelectHistoryTab(true) },
      )
    }
  }
}

@Composable
private fun LiveTrackingPane(
  ordersState: UiState<SyncSnapshot<Order>>,
  strings: AppStrings,
  onCancelOrder: (Order) -> Unit,
  onOpenPurchaseHistory: () -> Unit,
) {
  val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("live_tracking_pane"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    when (ordersState) {
      is UiState.Loading -> {
        item {
          Text("Syncing live deliveries from Pizza Hub...", modifier = Modifier.padding(16.dp))
        }
      }
      is UiState.Error -> {
        item {
          Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text(ordersState.message, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(16.dp))
          }
        }
      }
      is UiState.Success -> {
        val orders = ordersState.data.items
        val activeOrders = orders.filter { it.orderStatus !in listOf("delivered", "cancelled") }

        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
            shape = RoundedCornerShape(18.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = if (activeOrders.isNotEmpty()) "${activeOrders.size} Active Delivery" else "No Active Deliveries",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  text = "${orders.size} total purchase(s) recorded",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              OutlinedButton(
                onClick = onOpenPurchaseHistory,
                modifier = Modifier.testTag("jump_to_purchase_history_button"),
              ) {
                Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Past Purchases")
              }
            }
          }
        }

        if (activeOrders.isEmpty()) {
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              shape = RoundedCornerShape(18.dp),
            ) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Icon(Icons.Filled.DeliveryDining, contentDescription = null, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                Text("No active order in progress", style = MaterialTheme.typography.titleMedium)
                Text(
                  text = "Order a hot Cheese Blast Pizza from the Menu tab or check Past Purchases for your full order archive.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        } else {
          item {
            Text(strings.liveTracking, style = MaterialTheme.typography.headlineSmall)
          }
          items(activeOrders, key = { "live_${it.id}" }) { active ->
            LiveOrderTrackerCard(
              order = active,
              dateFmt = dateFmt,
              onCancel = { onCancelOrder(active) },
            )
          }
        }
      }
    }
  }
}

@Composable
fun PurchaseHistoryScreen(
  historyState: UiState<SyncSnapshot<UserOrder>>,
  reviewsState: UiState<List<Review>>,
  menuState: UiState<SyncSnapshot<MenuItem>>,
  currentUserId: String,
  encryptedVaultReceipt: String,
  strings: AppStrings,
  onReorder: (UserOrder) -> Unit,
  onSubmitOrderReview: (MenuItem, Int, String, String) -> Unit,
  onReviewOrderItem: (String) -> Unit,
) {
  var filterStatus by remember { mutableStateOf("all") }
  var historyQuery by remember { mutableStateOf("") }
  val dateFmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
  val allReviews = (reviewsState as? UiState.Success)?.data ?: emptyList()
  val allMenuItems = (menuState as? UiState.Success)?.data?.items ?: DefaultMenuCatalog.items

  val decryptedLastReceipt = remember(encryptedVaultReceipt, currentUserId) {
    if (encryptedVaultReceipt.isNotBlank()) {
      CryptoSecurityHelper.decryptPayload(encryptedVaultReceipt, currentUserId)
    } else {
      null
    }
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("purchase_history_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    if (!decryptedLastReceipt.isNullOrBlank()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(18.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Filled.Lock,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.tertiary,
            )
            Spacer(Modifier.width(12.dp))
            Column {
              Text("AES-256 Encrypted Receipt Vault (Offline Ready)", style = MaterialTheme.typography.labelLarge)
              Text(decryptedLastReceipt, style = MaterialTheme.typography.bodyMedium)
            }
          }
        }
      }
    }

    when (historyState) {
      is UiState.Loading -> {
        item {
          Text("Loading your past purchases...", modifier = Modifier.padding(16.dp))
        }
      }
      is UiState.Error -> {
        item {
          Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text(historyState.message, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(16.dp))
          }
        }
      }
      is UiState.Success -> {
        val purchases = historyState.data.items
        val completedCount = purchases.count { it.orderStatus == "delivered" }
        val totalSpent = purchases.filter { it.orderStatus != "cancelled" }.sumOf { it.totalAmount }

        // Summary KPI Row
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            PurchaseSummaryTile(label = "Purchases", value = "${purchases.size}", modifier = Modifier.weight(1f))
            PurchaseSummaryTile(label = "Delivered", value = "$completedCount", modifier = Modifier.weight(1f))
            PurchaseSummaryTile(label = "Total Spent", value = "৳$totalSpent", modifier = Modifier.weight(1f))
          }
        }

        item {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text(strings.orderHistory, style = MaterialTheme.typography.headlineSmall)
          }
        }

        item {
          OutlinedTextField(
            value = historyQuery,
            onValueChange = { historyQuery = it },
            placeholder = { Text("Search past purchases by dish, ref, or address") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
              if (historyQuery.isNotEmpty()) {
                IconButton(onClick = { historyQuery = "" }) {
                  Icon(Icons.Filled.Clear, contentDescription = "Clear history search")
                }
              }
            },
            modifier = Modifier.fillMaxWidth().testTag("order_history_search"),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
          )
        }

        item {
          val filters = listOf("all" to "All", "delivered" to "Delivered", "active" to "Active", "cancelled" to "Cancelled")
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filters) { (key, label) ->
              FilterChip(
                selected = filterStatus == key,
                onClick = { filterStatus = key },
                label = { Text(label) },
              )
            }
          }
        }

        val filteredHistory = purchases.filter { order ->
          val statusOk = when (filterStatus) {
            "active" -> order.orderStatus !in listOf("delivered", "cancelled")
            "delivered" -> order.orderStatus == "delivered"
            "cancelled" -> order.orderStatus == "cancelled"
            else -> true
          }
          val q = historyQuery.trim()
          val queryOk = q.isEmpty() ||
            order.itemsSummary.contains(q, ignoreCase = true) ||
            order.paymentRef.contains(q, ignoreCase = true) ||
            order.deliveryAddress.contains(q, ignoreCase = true) ||
            order.orderId.contains(q, ignoreCase = true) ||
            order.id.contains(q, ignoreCase = true)
          statusOk && queryOk
        }

        if (filteredHistory.isEmpty()) {
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              shape = RoundedCornerShape(18.dp),
            ) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                Text("No past purchases found", style = MaterialTheme.typography.titleMedium)
                Text(
                  text = "Your completed and recent orders from the Menu tab will appear here.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        } else {
          items(filteredHistory, key = { "hist_${it.id}" }) { purchase ->
            val orderKey = purchase.orderId.ifBlank { purchase.id }
            val existingReview = allReviews.firstOrNull {
              it.orderId == orderKey && it.userId == currentUserId
            }
            val matchedDishes = remember(purchase.itemsSummary, allMenuItems) {
              val found = allMenuItems.filter { purchase.itemsSummary.contains(it.name, ignoreCase = true) }
              found.ifEmpty { allMenuItems.take(1) }
            }
            PastPurchaseHistoryCard(
              purchase = purchase,
              dateFmt = dateFmt,
              matchedDishes = matchedDishes,
              existingReview = existingReview,
              onReorder = { onReorder(purchase) },
              onSubmitInlineReview = { dish, rating, comment ->
                onSubmitOrderReview(dish, rating, comment, orderKey)
              },
              onReview = { onReviewOrderItem(orderKey) },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun PurchaseSummaryTile(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
      Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(Modifier.height(4.dp))
      Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
  }
}

@Composable
private fun LiveOrderTrackerCard(
  order: Order,
  dateFmt: SimpleDateFormat,
  onCancel: () -> Unit,
) {
  val steps = listOf(
    "placed" to "Placed",
    "confirmed" to "Confirmed",
    "preparing" to "Baking",
    "out_for_delivery" to "On Way",
    "delivered" to "Delivered",
  )
  val currentStepIdx = steps.indexOfFirst { it.first == order.orderStatus }.coerceAtLeast(0)
  val infiniteTransition = rememberInfiniteTransition(label = "orderStatusPulse")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1.0f,
    targetValue = 1.32f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 900),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "pulseScale",
  )
  val pulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.38f,
    targetValue = 0.08f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 900),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "pulseAlpha",
  )

  Card(
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "Order #${order.id.take(8).uppercase()}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = order.createdAt?.toDate()?.let { dateFmt.format(it) } ?: "Just now",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        AnimatedContent(
          targetState = order.orderStatus to order.etaMinutes,
          transitionSpec = {
            (scaleIn(initialScale = 0.9f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith fadeOut()
          },
          label = "orderStatusBadgeTransition",
        ) { (status, eta) ->
          val badgeColor by animateColorAsState(
            targetValue = if (status == "delivered") MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer,
            label = "statusBadgeBg",
          )
          Surface(
            color = badgeColor,
            shape = RoundedCornerShape(50),
          ) {
            Text(
              text = "${status.replace('_', ' ').uppercase()} • ETA $eta min",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            )
          }
        }
      }

      // Live 5-Stage Progress Stepper with spring scale & subtle pulse feedback
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        steps.forEachIndexed { idx, (_, label) ->
          val active = idx <= currentStepIdx
          val isCurrent = idx == currentStepIdx
          val dotColor by animateColorAsState(
            targetValue = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            label = "stepColor",
          )
          val stepScale by animateFloatAsState(
            targetValue = when {
              isCurrent -> 1.18f
              active -> 1.0f
              else -> 0.88f
            },
            animationSpec = spring(
              dampingRatio = Spring.DampingRatioMediumBouncy,
              stiffness = Spring.StiffnessMediumLow,
            ),
            label = "stepScale",
          )
          Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
            Box(
              modifier = Modifier.size(34.dp),
              contentAlignment = Alignment.Center,
            ) {
              if (isCurrent && order.orderStatus != "delivered") {
                Box(
                  modifier = Modifier
                    .size(28.dp)
                    .scale(pulseScale)
                    .alpha(pulseAlpha)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                )
              }
              Box(
                modifier = Modifier
                  .size(26.dp)
                  .scale(stepScale)
                  .clip(CircleShape)
                  .background(dotColor),
                contentAlignment = Alignment.Center,
              ) {
                if (active) {
                  Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(15.dp),
                  )
                }
              }
            }
            Spacer(Modifier.height(4.dp))
            Text(
              text = label,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
            )
          }
        }
      }

      if (order.riderName.isNotBlank()) {
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
          shape = RoundedCornerShape(14.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.DeliveryDining, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(Modifier.width(10.dp))
              Column {
                Text("Rider: ${order.riderName}", style = MaterialTheme.typography.titleMedium)
                if (order.riderPhone.isNotBlank()) {
                  Text(order.riderPhone, style = MaterialTheme.typography.labelMedium)
                }
              }
            }
            Icon(Icons.Filled.Phone, contentDescription = "Rider phone", tint = MaterialTheme.colorScheme.primary)
          }
        }
      }

      OrderDeliveryMapCard(order = order)

      Text(order.itemsSummary, style = MaterialTheme.typography.bodyMedium)

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "৳${order.totalAmount} • ${order.paymentMethod.uppercase()} (${order.paymentStatus}) • v${order.syncVersion}",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (order.orderStatus in listOf("placed", "confirmed")) {
          TextButton(onClick = onCancel, modifier = Modifier.testTag("cancel_order_${order.id}")) {
            Icon(Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Cancel")
          }
        }
      }
    }
  }
}

@Composable
private fun PastPurchaseHistoryCard(
  purchase: UserOrder,
  dateFmt: SimpleDateFormat,
  matchedDishes: List<MenuItem>,
  existingReview: Review?,
  onReorder: () -> Unit,
  onSubmitInlineReview: (MenuItem, Int, String) -> Unit,
  onReview: () -> Unit,
) {
  val displayOrderId = purchase.orderId.ifBlank { purchase.id }
  val statusBg by animateColorAsState(
    targetValue = when (purchase.orderStatus) {
      "delivered" -> MaterialTheme.colorScheme.tertiaryContainer
      "cancelled" -> MaterialTheme.colorScheme.errorContainer
      else -> MaterialTheme.colorScheme.secondaryContainer
    },
    label = "historyStatusBg",
  )
  val statusFg by animateColorAsState(
    targetValue = when (purchase.orderStatus) {
      "delivered" -> MaterialTheme.colorScheme.onTertiaryContainer
      "cancelled" -> MaterialTheme.colorScheme.onErrorContainer
      else -> MaterialTheme.colorScheme.onSecondaryContainer
    },
    label = "historyStatusFg",
  )
  val pillScale by animateFloatAsState(
    targetValue = if (purchase.orderStatus == "delivered") 1.04f else 1.0f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
    label = "historyStatusScale",
  )

  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
    modifier = Modifier.testTag("purchase_history_card_$displayOrderId"),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        AnimatedContent(
          targetState = purchase.orderStatus,
          transitionSpec = {
            (scaleIn(initialScale = 0.92f) + fadeIn()) togetherWith fadeOut()
          },
          label = "historyStatusTransition",
        ) { status ->
          Surface(
            color = statusBg,
            shape = RoundedCornerShape(50),
            modifier = Modifier.scale(pillScale),
          ) {
            Text(
              text = "#${displayOrderId.take(8).uppercase()} • ${status.replace('_', ' ').uppercase()}",
              style = MaterialTheme.typography.labelMedium,
              color = statusFg,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
          }
        }
        Text(
          text = "৳${purchase.totalAmount}",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
        )
      }
      Text(purchase.itemsSummary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
      Text(
        text = "${purchase.deliveryAddress} • ${purchase.createdAt?.toDate()?.let { dateFmt.format(it) } ?: "Pending sync"}",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = "Subtotal ৳${purchase.subtotal} • Delivery ৳${purchase.deliveryFee}${if (purchase.discount > 0L) " • Discount -৳${purchase.discount}" else ""}",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = "Gateway: ${purchase.paymentMethod.uppercase()} (${purchase.paymentStatus}) • Ref: ${purchase.paymentRef}",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      // Inline Star Rating & Review Component for Completed Orders
      if (purchase.orderStatus == "delivered") {
        if (existingReview != null) {
          Surface(
            color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.55f),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("order_reviewed_badge_$displayOrderId"),
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(Modifier.width(6.dp))
                  Text("Your Verified Review • ${existingReview.menuItemName}", style = MaterialTheme.typography.labelLarge)
                }
                Row {
                  repeat(5) { idx ->
                    Icon(
                      imageVector = if (idx < existingReview.rating) Icons.Filled.Star else Icons.Outlined.StarBorder,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.secondary,
                      modifier = Modifier.size(16.dp),
                    )
                  }
                }
              }
              Text(existingReview.comment, style = MaterialTheme.typography.bodyMedium)
            }
          }
        } else if (matchedDishes.isNotEmpty()) {
          OrderInlineReviewComposer(
            orderId = displayOrderId,
            matchedDishes = matchedDishes,
            onSubmit = onSubmitInlineReview,
          )
        }
      }

      HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onReorder, modifier = Modifier.testTag("reorder_$displayOrderId")) {
          Icon(Icons.Filled.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text("Reorder")
        }
        if (purchase.orderStatus != "delivered") {
          OutlinedButton(onClick = onReview, modifier = Modifier.testTag("review_from_order_$displayOrderId")) {
            Icon(Icons.Filled.RateReview, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Review")
          }
        }
      }
    }
  }
}

@Composable
private fun OrderInlineReviewComposer(
  orderId: String,
  matchedDishes: List<MenuItem>,
  onSubmit: (MenuItem, Int, String) -> Unit,
) {
  var selectedDish by remember(orderId, matchedDishes) { mutableStateOf(matchedDishes.first()) }
  var rating by remember(orderId) { mutableIntStateOf(5) }
  var comment by remember(orderId) { mutableStateOf("") }

  Surface(
    color = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(14.dp),
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth().testTag("inline_order_review_card_$orderId"),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Text(
        text = "Rate Your Completed Order",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
      )
      if (matchedDishes.size > 1) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(matchedDishes, key = { "rev_dish_${orderId}_${it.id}" }) { dish ->
            FilterChip(
              selected = selectedDish.id == dish.id,
              onClick = { selectedDish = dish },
              label = { Text(dish.name, maxLines = 1) },
            )
          }
        }
      }
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        (1..5).forEach { star ->
          IconButton(
            onClick = { rating = star },
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("order_review_star_${orderId}_$star"),
          ) {
            Icon(
              imageVector = if (star <= rating) Icons.Filled.Star else Icons.Outlined.StarBorder,
              contentDescription = "Rate $star stars",
              tint = MaterialTheme.colorScheme.secondary,
            )
          }
        }
        Spacer(Modifier.width(4.dp))
        Text("$rating/5", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
      }
      OutlinedTextField(
        value = comment,
        onValueChange = { if (it.length <= 500) comment = it },
        label = { Text("Write a short review for ${selectedDish.name}") },
        placeholder = { Text("How was the taste, crust & delivery?") },
        modifier = Modifier.fillMaxWidth().testTag("order_review_input_$orderId"),
        minLines = 2,
        maxLines = 3,
      )
      Button(
        onClick = {
          onSubmit(selectedDish, rating, comment)
          comment = ""
        },
        enabled = comment.trim().length >= 2,
        modifier = Modifier.fillMaxWidth().testTag("order_review_submit_$orderId"),
        shape = RoundedCornerShape(12.dp),
      ) {
        Icon(Icons.Filled.RateReview, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text("Post Review")
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewsScreen(
  reviewsState: UiState<List<Review>>,
  menuState: UiState<SyncSnapshot<MenuItem>>,
  currentUserId: String,
  isAdmin: Boolean,
  strings: AppStrings,
  initialOrderIdForReview: String?,
  onClearInitialOrderId: () -> Unit,
  onSubmitReview: (MenuItem, Int, String, String) -> Unit,
  onDeleteReview: (String) -> Unit,
) {
  var showDialog by remember(initialOrderIdForReview) { mutableStateOf(initialOrderIdForReview != null) }
  val menuItems = (menuState as? UiState.Success)?.data?.items ?: DefaultMenuCatalog.items

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text("Sylhet Diner Reviews", style = MaterialTheme.typography.headlineSmall)
          Text("Verified ratings across Pizza Hub menu", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Button(
          onClick = { showDialog = true },
          modifier = Modifier.testTag("open_write_review_button"),
          shape = RoundedCornerShape(14.dp),
        ) {
          Icon(Icons.Filled.RateReview, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text(strings.writeReview)
        }
      }
    }

    when (reviewsState) {
      is UiState.Loading -> item { Text("Loading reviews...", modifier = Modifier.padding(16.dp)) }
      is UiState.Error -> item {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
          Text(reviewsState.message, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(16.dp))
        }
      }
      is UiState.Success -> {
        val list = reviewsState.data
        if (list.isNotEmpty()) {
          val avg = list.map { it.rating }.average()
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(18.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column {
                  Text("Community Rating", style = MaterialTheme.typography.labelLarge)
                  Text(String.format(Locale.US, "%.1f / 5.0", avg), style = MaterialTheme.typography.displaySmall)
                }
                Text("${list.size} Reviews", style = MaterialTheme.typography.titleMedium)
              }
            }
          }
        } else {
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              shape = RoundedCornerShape(18.dp),
            ) {
              Text(
                text = "No reviews yet. Be the first to rate your favorite Cheese Blast Pizza or Smash Burger!",
                modifier = Modifier.padding(20.dp),
              )
            }
          }
        }

        items(list, key = { it.id }) { rev ->
          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column {
                  Text(rev.authorName, style = MaterialTheme.typography.titleMedium)
                  Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(6.dp),
                  ) {
                    Text(
                      text = rev.menuItemName,
                      style = MaterialTheme.typography.labelSmall,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                  }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                  repeat(5) { idx ->
                    Icon(
                      imageVector = if (idx < rev.rating) Icons.Filled.Star else Icons.Outlined.StarBorder,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.secondary,
                      modifier = Modifier.size(18.dp),
                    )
                  }
                  if (rev.userId == currentUserId || isAdmin) {
                    IconButton(onClick = { onDeleteReview(rev.id) }) {
                      Icon(Icons.Filled.Delete, contentDescription = "Delete review", tint = MaterialTheme.colorScheme.error)
                    }
                  }
                }
              }
              Text(rev.comment, style = MaterialTheme.typography.bodyLarge)
            }
          }
        }
      }
    }
  }

  if (showDialog && menuItems.isNotEmpty()) {
    var selectedItem by remember { mutableStateOf(menuItems.first()) }
    var expanded by remember { mutableStateOf(false) }
    var rating by remember { mutableIntStateOf(5) }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
      onDismissRequest = {
        showDialog = false
        onClearInitialOrderId()
      },
      title = { Text(strings.writeReview) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(
              value = selectedItem.name,
              onValueChange = {},
              readOnly = true,
              label = { Text("Select Dish") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
              modifier = Modifier.menuAnchor().fillMaxWidth(),
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
              menuItems.forEach { item ->
                DropdownMenuItem(
                  text = { Text(item.name) },
                  onClick = {
                    selectedItem = item
                    expanded = false
                  },
                )
              }
            }
          }

          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (1..5).forEach { star ->
              IconButton(onClick = { rating = star }) {
                Icon(
                  imageVector = if (star <= rating) Icons.Filled.Star else Icons.Outlined.StarBorder,
                  contentDescription = "$star stars",
                  tint = MaterialTheme.colorScheme.secondary,
                )
              }
            }
          }

          OutlinedTextField(
            value = comment,
            onValueChange = { comment = it },
            label = { Text("Your experience") },
            modifier = Modifier.fillMaxWidth().testTag("review_comment_input"),
            minLines = 3,
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onSubmitReview(selectedItem, rating, comment, initialOrderIdForReview.orEmpty())
            showDialog = false
            onClearInitialOrderId()
          },
          modifier = Modifier.testTag("submit_review_button"),
        ) {
          Text("Post Review")
        }
      },
      dismissButton = {
        TextButton(onClick = {
          showDialog = false
          onClearInitialOrderId()
        }) {
          Text("Cancel")
        }
      },
    )
  }
}
