package com.example.util

import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricHelper {

  private fun supportedAuthenticators(): Int {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    } else {
      BiometricManager.Authenticators.BIOMETRIC_WEAK
    }
  }

  fun isAvailable(activity: FragmentActivity): Boolean {
    return try {
      val manager = BiometricManager.from(activity)
      val result = manager.canAuthenticate(supportedAuthenticators())
      result == BiometricManager.BIOMETRIC_SUCCESS
    } catch (_: Exception) {
      false
    }
  }

  fun authenticate(
    activity: FragmentActivity,
    title: String,
    subtitle: String,
    onSuccess: () -> Unit,
    onFallbackOrError: (String) -> Unit,
  ) {
    if (!isAvailable(activity)) {
      onFallbackOrError("Biometric lock not enrolled on this device.")
      return
    }
    try {
      val executor = ContextCompat.getMainExecutor(activity)
      val prompt = BiometricPrompt(
        activity,
        executor,
        object : BiometricPrompt.AuthenticationCallback() {
          override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            super.onAuthenticationSucceeded(result)
            onSuccess()
          }

          override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            super.onAuthenticationError(errorCode, errString)
            onFallbackOrError(errString.toString())
          }
        },
      )
      val builder = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setSubtitle(subtitle)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        builder.setAllowedAuthenticators(supportedAuthenticators())
      } else {
        builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        builder.setNegativeButtonText("Cancel")
      }
      prompt.authenticate(builder.build())
    } catch (e: Exception) {
      onFallbackOrError(e.localizedMessage ?: "Biometric authentication unavailable")
    }
  }
}
