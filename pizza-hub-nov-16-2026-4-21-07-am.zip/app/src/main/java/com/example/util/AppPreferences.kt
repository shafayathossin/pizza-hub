package com.example.util

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pizza_hub_prefs")

data class LocalAppSettings(
  val darkMode: String = "system",
  val language: String = "en",
  val biometricEnabled: Boolean = false,
  val lowBandwidthSync: Boolean = false,
  val encryptedVaultReceipt: String = "",
)

class AppPreferences(private val context: Context) {
  private object Keys {
    val DARK_MODE = stringPreferencesKey("dark_mode")
    val LANGUAGE = stringPreferencesKey("language")
    val BIOMETRIC = booleanPreferencesKey("biometric_enabled")
    val LOW_BANDWIDTH = booleanPreferencesKey("low_bandwidth_sync")
    val VAULT_RECEIPT = stringPreferencesKey("encrypted_vault_receipt")
  }

  val settingsFlow: Flow<LocalAppSettings> = context.dataStore.data.map { prefs ->
    LocalAppSettings(
      darkMode = prefs[Keys.DARK_MODE] ?: "system",
      language = prefs[Keys.LANGUAGE] ?: "en",
      biometricEnabled = prefs[Keys.BIOMETRIC] ?: false,
      lowBandwidthSync = prefs[Keys.LOW_BANDWIDTH] ?: false,
      encryptedVaultReceipt = prefs[Keys.VAULT_RECEIPT] ?: "",
    )
  }

  suspend fun setDarkMode(mode: String) {
    context.dataStore.edit { it[Keys.DARK_MODE] = mode }
  }

  suspend fun setLanguage(lang: String) {
    context.dataStore.edit { it[Keys.LANGUAGE] = lang }
  }

  suspend fun setBiometricEnabled(enabled: Boolean) {
    context.dataStore.edit { it[Keys.BIOMETRIC] = enabled }
  }

  suspend fun setLowBandwidthSync(enabled: Boolean) {
    context.dataStore.edit { it[Keys.LOW_BANDWIDTH] = enabled }
  }

  suspend fun saveEncryptedReceipt(cipherText: String) {
    context.dataStore.edit { it[Keys.VAULT_RECEIPT] = cipherText }
  }
}
