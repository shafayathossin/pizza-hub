package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

object ImageUtils {

  private val base64BitmapCache = LruCache<String, ImageBitmap>(24)

  @DrawableRes
  fun drawableForKey(imageKey: String, category: String): Int = when (imageKey) {
    "img_hero_pizzahub" -> R.drawable.img_hero_pizzahub
    "img_pizza_category" -> R.drawable.img_pizza_category
    "img_burger_category" -> R.drawable.img_burger_category
    "img_sandwich_category" -> R.drawable.img_sandwich_category
    else -> when (category) {
      "burger" -> R.drawable.img_burger_category
      "sandwich" -> R.drawable.img_sandwich_category
      "sides" -> R.drawable.img_hero_pizzahub
      else -> R.drawable.img_pizza_category
    }
  }

  /**
   * Compresses a Photo Picker image URI into a compact <= 45KB JPEG Base64 string
   * so admins can upload real photos cleanly within Firestore document & low-bandwidth limits.
   */
  fun uriToCompactBase64(context: Context, uri: Uri): String? {
    return try {
      val input = context.contentResolver.openInputStream(uri) ?: return null
      val original = input.use { BitmapFactory.decodeStream(it) } ?: return null
      val maxDim = 420f
      val scale = minOf(maxDim / original.width, maxDim / original.height, 1f)
      val targetW = (original.width * scale).toInt().coerceAtLeast(1)
      val targetH = (original.height * scale).toInt().coerceAtLeast(1)
      val resized = Bitmap.createScaledBitmap(original, targetW, targetH, true)

      var quality = 75
      var bytes: ByteArray
      do {
        val baos = ByteArrayOutputStream()
        resized.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        bytes = baos.toByteArray()
        quality -= 15
      } while (bytes.size > 48_000 && quality >= 30)

      Base64.encodeToString(bytes, Base64.NO_WRAP)
    } catch (_: Exception) {
      null
    }
  }

  fun cachedBase64Bitmap(base64: String?): ImageBitmap? {
    if (base64.isNullOrBlank()) return null
    val key = "${base64.length}_${base64.hashCode()}"
    return base64BitmapCache.get(key)
  }

  suspend fun decodeBase64Async(base64: String?): ImageBitmap? {
    if (base64.isNullOrBlank()) return null
    val key = "${base64.length}_${base64.hashCode()}"
    base64BitmapCache.get(key)?.let { return it }
    return withContext(Dispatchers.Default) {
      decodeBase64ToImageBitmap(base64)
    }
  }

  fun decodeBase64ToImageBitmap(base64: String?): ImageBitmap? {
    if (base64.isNullOrBlank()) return null
    val key = "${base64.length}_${base64.hashCode()}"
    base64BitmapCache.get(key)?.let { return it }
    return try {
      val raw = Base64.decode(base64, Base64.NO_WRAP)
      val opts = BitmapFactory.Options().apply {
        inPreferredConfig = Bitmap.Config.RGB_565
      }
      BitmapFactory.decodeByteArray(raw, 0, raw.size, opts)?.asImageBitmap()?.also {
        base64BitmapCache.put(key, it)
      }
    } catch (_: Exception) {
      null
    }
  }
}
