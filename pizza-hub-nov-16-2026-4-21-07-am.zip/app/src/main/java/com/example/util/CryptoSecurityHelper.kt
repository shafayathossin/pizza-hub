package com.example.util

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object CryptoSecurityHelper {
  private const val AES_GCM = "AES/GCM/NoPadding"
  private const val GCM_TAG_BITS = 128
  private const val IV_LEN = 12

  fun sha256Hex(input: String): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val hash = digest.digest(input.toByteArray(StandardCharsets.UTF_8))
    return hash.joinToString("") { "%02x".format(it) }
  }

  private fun deriveKey(secretSeed: String): SecretKeySpec {
    val digest = MessageDigest.getInstance("SHA-256")
    val keyBytes = digest.digest("PizzaHubSylhet::$secretSeed".toByteArray(StandardCharsets.UTF_8))
    return SecretKeySpec(keyBytes, "AES")
  }

  fun encryptPayload(plainText: String, userSeed: String): String {
    val iv = ByteArray(IV_LEN)
    SecureRandom().nextBytes(iv)
    val cipher = Cipher.getInstance(AES_GCM)
    cipher.init(Cipher.ENCRYPT_MODE, deriveKey(userSeed), GCMParameterSpec(GCM_TAG_BITS, iv))
    val encrypted = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
    val combined = iv + encrypted
    return Base64.encodeToString(combined, Base64.NO_WRAP)
  }

  fun decryptPayload(cipherTextBase64: String, userSeed: String): String? {
    return try {
      val combined = Base64.decode(cipherTextBase64, Base64.NO_WRAP)
      if (combined.size <= IV_LEN) return null
      val iv = combined.copyOfRange(0, IV_LEN)
      val cipherBytes = combined.copyOfRange(IV_LEN, combined.size)
      val cipher = Cipher.getInstance(AES_GCM)
      cipher.init(Cipher.DECRYPT_MODE, deriveKey(userSeed), GCMParameterSpec(GCM_TAG_BITS, iv))
      String(cipher.doFinal(cipherBytes), StandardCharsets.UTF_8)
    } catch (_: Exception) {
      null
    }
  }
}
