package com.example.data.repository

import com.example.data.model.AdminEntry
import com.example.data.model.AuditLog
import com.example.data.model.DefaultMenuCatalog
import com.example.data.model.MenuItem
import com.example.data.model.Order
import com.example.data.model.Review
import com.example.data.model.StoreInfo
import com.example.data.model.UserOrder
import com.example.data.model.UserProfile
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.example.util.CryptoSecurityHelper
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class SyncSnapshot<T>(
  val items: List<T>,
  val isFromCache: Boolean = false,
  val hasPendingWrites: Boolean = false,
)

class PizzaHubRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth,
) {

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  private fun <T> handleFlowError(
    error: Throwable,
    op: OperationType,
    path: String,
    expectedUid: String? = null,
  ): Nothing {
    val firestoreError = generateSequence(error) { it.cause }
      .filterIsInstance<FirebaseFirestoreException>()
      .firstOrNull()
    if (firestoreError == null && error is CancellationException) throw error
    val exceptionToLog = firestoreError ?: (error as? Exception)
    if (exceptionToLog != null && (expectedUid == null || auth.currentUser?.uid == expectedUid)) {
      handleFirestoreError(exceptionToLog, op, path)
    }
    throw error
  }

  fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
    val path = "users/$userId"
    emitAll(
      db.collection("users").document(userId)
        .snapshots()
        .map { snapshot ->
          if (snapshot.exists()) {
            snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          } else {
            null
          }
        }
        .catch { e -> handleFlowError<UserProfile?>(e, OperationType.GET, path, userId) }
    )
  }

  suspend fun ensureUserProfile(
    userId: String,
    displayName: String,
    email: String,
  ): Result<UserProfile> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(userId)
    return try {
      val existing = docRef.get().await()
      if (existing.exists()) {
        val profile = existing.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          ?: UserProfile(id = userId, userId = userId, displayName = displayName, email = email)
        Result.success(profile)
      } else {
        val safeName = displayName.ifBlank { "Pizza Hub Guest" }.take(80)
        val payload = mapOf(
          "userId" to uid,
          "displayName" to safeName,
          "email" to email.take(150),
          "phone" to "",
          "deliveryAddress" to "Sylhet City",
          "role" to "customer",
          "preferredLanguage" to "en",
          "darkMode" to "system",
          "biometricEnabled" to false,
          "lowBandwidthSync" to false,
          "favoriteItemIds" to emptyList<String>(),
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        docRef.set(payload).await()
        Result.success(
          UserProfile(
            id = uid,
            userId = uid,
            displayName = safeName,
            email = email.take(150),
            deliveryAddress = "Sylhet City",
            role = "customer",
          )
        )
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateUserProfile(
    userId: String,
    displayName: String,
    phone: String,
    deliveryAddress: String,
    preferredLanguage: String,
    darkMode: String,
    biometricEnabled: Boolean,
    lowBandwidthSync: Boolean,
  ): Result<Unit> {
    requireUserId()
    val docRef = db.collection("users").document(userId)
    return try {
      val updates = mapOf(
        "displayName" to displayName.ifBlank { "Pizza Hub Guest" }.take(80),
        "phone" to phone.take(30),
        "deliveryAddress" to deliveryAddress.take(250),
        "preferredLanguage" to preferredLanguage,
        "darkMode" to darkMode,
        "biometricEnabled" to biometricEnabled,
        "lowBandwidthSync" to lowBandwidthSync,
        "updatedAt" to FieldValue.serverTimestamp(),
      )
      docRef.update(updates).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun toggleFavoriteMenuItem(
    userId: String,
    menuItemId: String,
    shouldBeFavorite: Boolean,
  ): Result<Unit> {
    requireUserId()
    val docRef = db.collection("users").document(userId)
    return try {
      val op = if (shouldBeFavorite) {
        FieldValue.arrayUnion(menuItemId)
      } else {
        FieldValue.arrayRemove(menuItemId)
      }
      docRef.update(
        mapOf(
          "favoriteItemIds" to op,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  fun observeIsAdmin(userId: String, email: String?, emailVerified: Boolean): Flow<Boolean> = flow {
    if (emailVerified && email == StoreInfo.BOOTSTRAP_ADMIN_EMAIL) {
      emit(true)
      return@flow
    }
    val path = "admins/$userId"
    emitAll(
      db.collection("admins").document(userId)
        .snapshots()
        .map { snapshot -> snapshot.exists() }
        .catch { e ->
          val firestoreError = generateSequence(e) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
          if (firestoreError == null && e is CancellationException) throw e
          if (firestoreError?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
            emit(false)
          } else {
            handleFlowError<Boolean>(e, OperationType.GET, path, userId)
          }
        }
    )
  }

  fun observeMenuItems(): Flow<SyncSnapshot<MenuItem>> = flow {
    val uid = requireUserId()
    val path = "menu_items"
    emitAll(
      db.collection(path)
        .snapshots(MetadataChanges.INCLUDE)
        .map { snapshot ->
          val items = snapshot.toObjects(MenuItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedWith(compareBy<MenuItem> { categorySortKey(it.category) }.thenBy { it.name })
          SyncSnapshot(
            items = items,
            isFromCache = snapshot.metadata.isFromCache,
            hasPendingWrites = snapshot.metadata.hasPendingWrites(),
          )
        }
        .flowOn(Dispatchers.Default)
        .catch { e -> handleFlowError<SyncSnapshot<MenuItem>>(e, OperationType.LIST, path, uid) }
    )
  }

  suspend fun seedDefaultMenuIfEmpty(adminUid: String, actorEmail: String): Result<Int> {
    requireUserId()
    val colRef = db.collection("menu_items")
    return try {
      val existing = colRef.limit(1).get().await()
      if (!existing.isEmpty) return Result.success(0)
      var count = 0
      val batch = db.batch()
      for (item in DefaultMenuCatalog.items) {
        val docRef = colRef.document(item.id)
        val payload = mapOf(
          "name" to item.name,
          "description" to item.description,
          "category" to item.category,
          "price" to item.price,
          "premiumPrice" to item.premiumPrice,
          "imageKey" to item.imageKey,
          "imageUrl" to item.imageUrl,
          "ingredients" to item.resolvedIngredients(),
          "servingSize" to item.resolvedNutrition().servingSize,
          "calories" to item.resolvedNutrition().calories,
          "proteinGrams" to item.resolvedNutrition().proteinGrams,
          "carbsGrams" to item.resolvedNutrition().carbsGrams,
          "fatGrams" to item.resolvedNutrition().fatGrams,
          "available" to item.available,
          "prepMinutes" to item.prepMinutes,
          "isVeg" to item.isVeg,
          "ratingAvg" to item.ratingAvg,
          "reviewCount" to item.reviewCount,
          "version" to 1L,
          "updatedBy" to adminUid,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        batch.set(docRef, payload)
        count++
      }
      batch.commit().await()
      appendAuditLog(
        userId = adminUid,
        actorEmail = actorEmail,
        action = "CATALOG_SEEDED",
        entityType = "menu_items",
        entityId = "batch_$count",
        strategy = "ADMIN_OVERRIDE",
        details = "Initialized $count Pizza Hub Sylhet menu items",
      )
      Result.success(count)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, colRef.path)
      Result.failure(e)
    }
  }

  suspend fun upsertMenuItem(
    itemId: String?,
    item: MenuItem,
    adminUid: String,
    actorEmail: String,
  ): Result<String> {
    requireUserId()
    val safeId = itemId?.takeIf { it.isNotBlank() } ?: "item_${UUID.randomUUID().toString().take(12)}"
    val docRef = db.collection("menu_items").document(safeId)
    return try {
      val existingDoc = docRef.get().await()
      val nextVersion = if (existingDoc.exists()) {
        (existingDoc.getLong("version") ?: 1L) + 1L
      } else {
        1L
      }
      val nutrition = item.resolvedNutrition()
      val ingredientsList = item.resolvedIngredients().take(30)
      if (existingDoc.exists()) {
        val updates = mutableMapOf<String, Any>(
          "name" to item.name.take(80),
          "description" to item.description.take(600),
          "category" to item.category,
          "price" to item.price.coerceIn(1L, 50000L),
          "premiumPrice" to item.premiumPrice.coerceIn(0L, 50000L),
          "imageKey" to item.imageKey.take(80),
          "imageUrl" to item.imageUrl.take(500),
          "ingredients" to ingredientsList,
          "servingSize" to nutrition.servingSize.take(80),
          "calories" to nutrition.calories.coerceIn(0L, 10000L),
          "proteinGrams" to nutrition.proteinGrams.coerceIn(0L, 1000L),
          "carbsGrams" to nutrition.carbsGrams.coerceIn(0L, 1000L),
          "fatGrams" to nutrition.fatGrams.coerceIn(0L, 1000L),
          "available" to item.available,
          "prepMinutes" to item.prepMinutes.coerceIn(1L, 180L),
          "isVeg" to item.isVeg,
          "ratingAvg" to item.ratingAvg.coerceIn(0.0, 5.0),
          "reviewCount" to item.reviewCount.coerceAtLeast(0L),
          "version" to nextVersion,
          "updatedBy" to adminUid,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        if (!item.imageBase64.isNullOrBlank()) {
          updates["imageBase64"] = item.imageBase64.take(120000)
        }
        docRef.update(updates).await()
      } else {
        val payload = mutableMapOf<String, Any>(
          "name" to item.name.take(80),
          "description" to item.description.take(600),
          "category" to item.category,
          "price" to item.price.coerceIn(1L, 50000L),
          "premiumPrice" to item.premiumPrice.coerceIn(0L, 50000L),
          "imageKey" to item.imageKey.take(80),
          "imageUrl" to item.imageUrl.take(500),
          "ingredients" to ingredientsList,
          "servingSize" to nutrition.servingSize.take(80),
          "calories" to nutrition.calories.coerceIn(0L, 10000L),
          "proteinGrams" to nutrition.proteinGrams.coerceIn(0L, 1000L),
          "carbsGrams" to nutrition.carbsGrams.coerceIn(0L, 1000L),
          "fatGrams" to nutrition.fatGrams.coerceIn(0L, 1000L),
          "available" to item.available,
          "prepMinutes" to item.prepMinutes.coerceIn(1L, 180L),
          "isVeg" to item.isVeg,
          "ratingAvg" to item.ratingAvg.coerceIn(0.0, 5.0),
          "reviewCount" to item.reviewCount.coerceAtLeast(0L),
          "version" to nextVersion,
          "updatedBy" to adminUid,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        if (!item.imageBase64.isNullOrBlank()) {
          payload["imageBase64"] = item.imageBase64.take(120000)
        }
        docRef.set(payload).await()
      }
      appendAuditLog(
        userId = adminUid,
        actorEmail = actorEmail,
        action = if (existingDoc.exists()) "MENU_UPDATE" else "MENU_CREATE",
        entityType = "menu_item",
        entityId = safeId,
        strategy = "LWW",
        details = "${item.name} v$nextVersion (৳${item.price})",
      )
      Result.success(safeId)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun deleteMenuItem(itemId: String, adminUid: String, actorEmail: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("menu_items").document(itemId)
    return try {
      docRef.delete().await()
      appendAuditLog(
        userId = adminUid,
        actorEmail = actorEmail,
        action = "MENU_DELETE",
        entityType = "menu_item",
        entityId = itemId,
        strategy = "ADMIN_OVERRIDE",
        details = "Removed menu item $itemId",
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
      Result.failure(e)
    }
  }

  fun observeCustomerOrders(userId: String): Flow<SyncSnapshot<Order>> = flow {
    val path = "orders"
    emitAll(
      db.collection(path)
        .whereEqualTo("userId", userId)
        .snapshots(MetadataChanges.INCLUDE)
        .map { snapshot ->
          val orders = snapshot.toObjects(Order::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
          SyncSnapshot(
            items = orders,
            isFromCache = snapshot.metadata.isFromCache,
            hasPendingWrites = snapshot.metadata.hasPendingWrites(),
          )
        }
        .flowOn(Dispatchers.Default)
        .catch { e -> handleFlowError<SyncSnapshot<Order>>(e, OperationType.LIST, path, userId) }
    )
  }

  fun observeUserOrderHistory(userId: String): Flow<SyncSnapshot<UserOrder>> = flow {
    val path = "user_orders"
    emitAll(
      db.collection(path)
        .whereEqualTo("userId", userId)
        .snapshots(MetadataChanges.INCLUDE)
        .map { snapshot ->
          val history = snapshot.toObjects(UserOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
          SyncSnapshot(
            items = history,
            isFromCache = snapshot.metadata.isFromCache,
            hasPendingWrites = snapshot.metadata.hasPendingWrites(),
          )
        }
        .flowOn(Dispatchers.Default)
        .catch { e -> handleFlowError<SyncSnapshot<UserOrder>>(e, OperationType.LIST, path, userId) }
    )
  }

  fun observeAllOrdersAdmin(): Flow<SyncSnapshot<Order>> = flow {
    val uid = requireUserId()
    val path = "orders"
    emitAll(
      db.collection(path)
        .snapshots(MetadataChanges.INCLUDE)
        .map { snapshot ->
          val orders = snapshot.toObjects(Order::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
          SyncSnapshot(
            items = orders,
            isFromCache = snapshot.metadata.isFromCache,
            hasPendingWrites = snapshot.metadata.hasPendingWrites(),
          )
        }
        .flowOn(Dispatchers.Default)
        .catch { e -> handleFlowError<SyncSnapshot<Order>>(e, OperationType.LIST, path, uid) }
    )
  }

  suspend fun getOrderById(orderId: String): Result<Order?> {
    requireUserId()
    val docRef = db.collection("orders").document(orderId)
    return try {
      val snap = docRef.get().await()
      Result.success(snap.toObject(Order::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE))
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun placeOrder(order: Order, actorEmail: String): Result<String> {
    val uid = requireUserId()
    val docRef = db.collection("orders").document()
    val userOrderRef = db.collection("user_orders").document(docRef.id)
    val encryptedHash = CryptoSecurityHelper.sha256Hex(
      "$uid|${order.itemsSummary}|${order.totalAmount}|${order.paymentMethod}|${System.currentTimeMillis()}"
    )
    val safeName = order.customerName.ifBlank { "Pizza Hub Guest" }.take(80)
    val safeAddress = order.deliveryAddress.ifBlank { "Ambarkhana, Sylhet" }.take(250)
    val safeSummary = order.itemsSummary.take(1000)
    val safeCount = order.itemCount.coerceIn(1L, 100L)
    val safeSubtotal = order.subtotal.coerceAtLeast(1L)
    val safeDeliveryFee = order.deliveryFee.coerceAtLeast(0L)
    val safeDiscount = order.discount.coerceAtLeast(0L)
    val safeTotal = order.totalAmount.coerceAtLeast(1L)
    val safeRef = order.paymentRef.take(100)

    val payload = mapOf(
      "userId" to uid,
      "customerName" to safeName,
      "customerPhone" to order.customerPhone.ifBlank { "01974378075" }.take(30),
      "deliveryAddress" to safeAddress,
      "itemsSummary" to safeSummary,
      "itemCount" to safeCount,
      "subtotal" to safeSubtotal,
      "deliveryFee" to safeDeliveryFee,
      "discount" to safeDiscount,
      "totalAmount" to safeTotal,
      "paymentMethod" to order.paymentMethod,
      "paymentStatus" to order.paymentStatus,
      "paymentRef" to safeRef,
      "orderStatus" to "placed",
      "riderName" to "",
      "riderPhone" to "",
      "riderLat" to order.riderLat.coerceIn(-90.0, 90.0),
      "riderLng" to order.riderLng.coerceIn(-180.0, 180.0),
      "destinationLat" to order.destinationLat.coerceIn(-90.0, 90.0),
      "destinationLng" to order.destinationLng.coerceIn(-180.0, 180.0),
      "etaMinutes" to order.etaMinutes.coerceIn(10L, 180L),
      "deliveryNotes" to order.deliveryNotes.take(300),
      "encryptedPayloadHash" to encryptedHash,
      "syncVersion" to 1L,
      "lastConflictNote" to "",
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    val userOrderPayload = mapOf(
      "orderId" to docRef.id,
      "userId" to uid,
      "customerName" to safeName,
      "deliveryAddress" to safeAddress,
      "itemsSummary" to safeSummary,
      "itemCount" to safeCount,
      "subtotal" to safeSubtotal,
      "deliveryFee" to safeDeliveryFee,
      "discount" to safeDiscount,
      "totalAmount" to safeTotal,
      "paymentMethod" to order.paymentMethod,
      "paymentStatus" to order.paymentStatus,
      "paymentRef" to safeRef,
      "orderStatus" to "placed",
      "encryptedPayloadHash" to encryptedHash,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    return try {
      val batch = db.batch()
      batch.set(docRef, payload)
      batch.set(userOrderRef, userOrderPayload)
      batch.commit().await()
      appendAuditLog(
        userId = uid,
        actorEmail = actorEmail,
        action = "ORDER_PLACED",
        entityType = "order",
        entityId = docRef.id,
        strategy = "LWW",
        details = "Placed ৳${order.totalAmount} via ${order.paymentMethod} (${order.paymentStatus})",
      )
      Result.success(docRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun cancelOrderByCustomer(order: Order, actorEmail: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("orders").document(order.id)
    val userOrderRef = db.collection("user_orders").document(order.id)
    return try {
      val nextVer = order.syncVersion + 1L
      docRef.update(
        mapOf(
          "orderStatus" to "cancelled",
          "syncVersion" to nextVer,
          "lastConflictNote" to "Cancelled by customer (v$nextVer)",
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      val userOrderSnap = userOrderRef.get().await()
      if (userOrderSnap.exists()) {
        userOrderRef.update(
          mapOf(
            "orderStatus" to "cancelled",
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
      appendAuditLog(
        userId = uid,
        actorEmail = actorEmail,
        action = "ORDER_CANCELLED",
        entityType = "order",
        entityId = order.id,
        strategy = "LWW",
        details = "Customer cancelled order at v$nextVer",
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateOrderByAdmin(
    order: Order,
    newStatus: String,
    newPaymentStatus: String,
    riderName: String,
    riderPhone: String,
    etaMinutes: Long,
    conflictNote: String,
    actorEmail: String,
    riderLat: Double? = null,
    riderLng: Double? = null,
  ): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("orders").document(order.id)
    val userOrderRef = db.collection("user_orders").document(order.id)
    return try {
      val latestSnap = docRef.get().await()
      val serverVersion = latestSnap.getLong("syncVersion") ?: order.syncVersion
      val resolvedVersion = maxOf(serverVersion, order.syncVersion) + 1L
      val lwwNote = if (serverVersion > order.syncVersion) {
        "LWW merged server v$serverVersion -> v$resolvedVersion"
      } else {
        conflictNote.ifBlank { "Updated by admin (v$resolvedVersion)" }
      }
      val updates = mutableMapOf<String, Any>(
        "orderStatus" to newStatus,
        "paymentStatus" to newPaymentStatus,
        "riderName" to riderName.take(80),
        "riderPhone" to riderPhone.take(30),
        "etaMinutes" to etaMinutes.coerceIn(0L, 240L),
        "syncVersion" to resolvedVersion,
        "lastConflictNote" to lwwNote.take(200),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
      if (riderLat != null) {
        updates["riderLat"] = riderLat.coerceIn(-90.0, 90.0)
      }
      if (riderLng != null) {
        updates["riderLng"] = riderLng.coerceIn(-180.0, 180.0)
      }
      docRef.update(updates).await()
      val userOrderSnap = userOrderRef.get().await()
      if (userOrderSnap.exists()) {
        userOrderRef.update(
          mapOf(
            "orderStatus" to newStatus,
            "paymentStatus" to newPaymentStatus,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
      appendAuditLog(
        userId = uid,
        actorEmail = actorEmail,
        action = "ADMIN_ORDER_UPDATE",
        entityType = "order",
        entityId = order.id,
        strategy = if (serverVersion > order.syncVersion) "LWW" else "ADMIN_OVERRIDE",
        details = "Status=$newStatus Payment=$newPaymentStatus ($lwwNote)",
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  fun observeReviews(): Flow<List<Review>> = flow {
    val uid = requireUserId()
    val path = "reviews"
    emitAll(
      db.collection(path)
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(Review::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
        }
        .flowOn(Dispatchers.Default)
        .catch { e -> handleFlowError<List<Review>>(e, OperationType.LIST, path, uid) }
    )
  }

  suspend fun submitReview(review: Review): Result<String> {
    val uid = requireUserId()
    val docRef = db.collection("reviews").document()
    val payload = mapOf(
      "userId" to uid,
      "authorName" to review.authorName.ifBlank { "Pizza Hub Lover" }.take(80),
      "menuItemId" to review.menuItemId.take(128),
      "menuItemName" to review.menuItemName.take(80),
      "rating" to review.rating.coerceIn(1L, 5L),
      "comment" to review.comment.take(500),
      "orderId" to review.orderId.take(128),
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    return try {
      docRef.set(payload).await()
      Result.success(docRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun deleteReview(reviewId: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("reviews").document(reviewId)
    return try {
      docRef.delete().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
      Result.failure(e)
    }
  }

  fun observeAuditLogs(userId: String, isAdmin: Boolean): Flow<List<AuditLog>> = flow {
    val path = "audit_logs"
    val query = if (isAdmin) {
      db.collection(path).limit(50)
    } else {
      db.collection(path).whereEqualTo("userId", userId).limit(30)
    }
    emitAll(
      query.snapshots()
        .map { snapshot ->
          snapshot.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
        }
        .flowOn(Dispatchers.Default)
        .catch { e -> handleFlowError<List<AuditLog>>(e, OperationType.LIST, path, userId) }
    )
  }

  suspend fun grantAdminRole(
    targetUid: String,
    targetEmail: String,
    roleLabel: String,
    grantedByUid: String,
    actorEmail: String,
  ): Result<Unit> {
    requireUserId()
    val cleanUid = targetUid.trim()
    val docRef = db.collection("admins").document(cleanUid)
    val payload = mapOf(
      "uid" to cleanUid,
      "email" to targetEmail.trim().take(150),
      "roleLabel" to roleLabel.ifBlank { "Store Manager" }.take(40),
      "grantedBy" to grantedByUid,
      "createdAt" to FieldValue.serverTimestamp(),
      "updatedAt" to FieldValue.serverTimestamp(),
    )
    return try {
      docRef.set(payload).await()
      appendAuditLog(
        userId = grantedByUid,
        actorEmail = actorEmail,
        action = "RBAC_ADMIN_GRANTED",
        entityType = "admin",
        entityId = cleanUid,
        strategy = "ADMIN_OVERRIDE",
        details = "Granted $roleLabel role to $targetEmail",
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  fun observeAdmins(): Flow<List<AdminEntry>> = flow {
    val uid = requireUserId()
    val path = "admins"
    emitAll(
      db.collection(path)
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(AdminEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }
        .catch { e -> handleFlowError<List<AdminEntry>>(e, OperationType.LIST, path, uid) }
    )
  }

  private suspend fun appendAuditLog(
    userId: String,
    actorEmail: String,
    action: String,
    entityType: String,
    entityId: String,
    strategy: String,
    details: String,
  ) {
    val docRef = db.collection("audit_logs").document()
    val payload = mapOf(
      "userId" to userId,
      "actorEmail" to actorEmail.take(150),
      "action" to action.take(60),
      "entityType" to entityType.take(40),
      "entityId" to entityId.take(128),
      "resolutionStrategy" to strategy,
      "details" to details.take(400),
      "createdAt" to FieldValue.serverTimestamp(),
    )
    try {
      docRef.set(payload).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
    }
  }

  private fun categorySortKey(category: String): Int = when (category) {
    "pizza" -> 0
    "burger" -> 1
    "sandwich" -> 2
    else -> 3
  }
}
