package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "",
  val email: String = "",
  val phone: String = "",
  val deliveryAddress: String = "",
  val role: String = "customer",
  val preferredLanguage: String = "en",
  val darkMode: String = "system",
  val biometricEnabled: Boolean = false,
  val lowBandwidthSync: Boolean = false,
  val favoriteItemIds: List<String> = emptyList(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class AdminEntry(
  @DocumentId val id: String = "",
  val uid: String = "",
  val email: String = "",
  val roleLabel: String = "Manager",
  val grantedBy: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

data class NutritionInfo(
  val servingSize: String = "1 Regular Serving",
  val calories: Long = 0L,
  val proteinGrams: Long = 0L,
  val carbsGrams: Long = 0L,
  val fatGrams: Long = 0L,
)

@IgnoreExtraProperties
data class MenuItem(
  @DocumentId val id: String = "",
  val name: String = "",
  val description: String = "",
  val category: String = "pizza",
  val price: Long = 0L,
  val premiumPrice: Long = 0L,
  val imageKey: String = "img_pizza_category",
  val imageUrl: String = "",
  val imageBase64: String? = null,
  val ingredients: List<String> = emptyList(),
  val servingSize: String = "",
  val calories: Long = 0L,
  val proteinGrams: Long = 0L,
  val carbsGrams: Long = 0L,
  val fatGrams: Long = 0L,
  val available: Boolean = true,
  val prepMinutes: Long = 20L,
  val isVeg: Boolean = false,
  val ratingAvg: Double = 4.8,
  val reviewCount: Long = 0L,
  val version: Long = 1L,
  val updatedBy: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun resolvedIngredients(): List<String> {
    if (ingredients.isNotEmpty()) return ingredients
    val catalogMatch = DefaultMenuCatalog.items.firstOrNull { it.id == id || it.name.equals(name, ignoreCase = true) }
    if (catalogMatch != null && catalogMatch.ingredients.isNotEmpty()) return catalogMatch.ingredients
    return when (category) {
      "pizza" -> listOf("Hand-stretched pizza dough", "San Marzano house sauce", "Mozzarella cheese", "Italian oregano herbs")
      "burger" -> listOf("Toasted brioche bun", "Seasoned patty", "Aged cheddar cheese", "Crisp lettuce", "House garlic sauce")
      "sandwich" -> listOf("Artisan toasted bread", "Grilled spiced filling", "Melted cheese", "Fresh garden greens")
      else -> listOf("Fresh house ingredients", "Garlic herb seasoning", "Signature dipping sauce")
    }
  }

  fun resolvedNutrition(): NutritionInfo {
    if (calories > 0L) {
      return NutritionInfo(
        servingSize = servingSize.ifBlank { defaultServingForCategory(category) },
        calories = calories,
        proteinGrams = proteinGrams,
        carbsGrams = carbsGrams,
        fatGrams = fatGrams,
      )
    }
    val catalogMatch = DefaultMenuCatalog.items.firstOrNull { it.id == id || it.name.equals(name, ignoreCase = true) }
    if (catalogMatch != null && catalogMatch.calories > 0L) {
      return NutritionInfo(
        servingSize = catalogMatch.servingSize,
        calories = catalogMatch.calories,
        proteinGrams = catalogMatch.proteinGrams,
        carbsGrams = catalogMatch.carbsGrams,
        fatGrams = catalogMatch.fatGrams,
      )
    }
    return when (category) {
      "pizza" -> NutritionInfo("2 Slices (240g)", 580L, 26L, 58L, 26L)
      "burger" -> NutritionInfo("1 Burger (260g)", 540L, 29L, 44L, 27L)
      "sandwich" -> NutritionInfo("1 Sandwich (220g)", 430L, 24L, 42L, 18L)
      else -> NutritionInfo("1 Portion (200g)", 380L, 14L, 45L, 16L)
    }
  }

  private fun defaultServingForCategory(cat: String): String = when (cat) {
    "pizza" -> "2 Slices (240g)"
    "burger" -> "1 Burger (260g)"
    "sandwich" -> "1 Sandwich (220g)"
    else -> "1 Portion (200g)"
  }
}

@IgnoreExtraProperties
data class Order(
  @DocumentId val id: String = "",
  val userId: String = "",
  val customerName: String = "",
  val customerPhone: String = "",
  val deliveryAddress: String = "",
  val itemsSummary: String = "",
  val itemCount: Long = 1L,
  val subtotal: Long = 0L,
  val deliveryFee: Long = 50L,
  val discount: Long = 0L,
  val totalAmount: Long = 0L,
  val paymentMethod: String = "bkash",
  val paymentStatus: String = "pending",
  val paymentRef: String = "",
  val orderStatus: String = "placed",
  val riderName: String = "",
  val riderPhone: String = "",
  val riderLat: Double = SylhetLocations.KITCHEN_LAT,
  val riderLng: Double = SylhetLocations.KITCHEN_LNG,
  val destinationLat: Double = SylhetLocations.DEFAULT_DEST_LAT,
  val destinationLng: Double = SylhetLocations.DEFAULT_DEST_LNG,
  val etaMinutes: Long = 35L,
  val deliveryNotes: String = "",
  val encryptedPayloadHash: String = "",
  val syncVersion: Long = 1L,
  val lastConflictNote: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class UserOrder(
  @DocumentId val id: String = "",
  val orderId: String = "",
  val userId: String = "",
  val customerName: String = "",
  val deliveryAddress: String = "",
  val itemsSummary: String = "",
  val itemCount: Long = 1L,
  val subtotal: Long = 0L,
  val deliveryFee: Long = 50L,
  val discount: Long = 0L,
  val totalAmount: Long = 0L,
  val paymentMethod: String = "bkash",
  val paymentStatus: String = "pending",
  val paymentRef: String = "",
  val orderStatus: String = "placed",
  val encryptedPayloadHash: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class Review(
  @DocumentId val id: String = "",
  val userId: String = "",
  val authorName: String = "",
  val menuItemId: String = "",
  val menuItemName: String = "",
  val rating: Long = 5L,
  val comment: String = "",
  val orderId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class AuditLog(
  @DocumentId val id: String = "",
  val userId: String = "",
  val actorEmail: String = "",
  val action: String = "",
  val entityType: String = "",
  val entityId: String = "",
  val resolutionStrategy: String = "LWW",
  val details: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

data class CartItem(
  val menuItem: MenuItem,
  val isPremiumSize: Boolean = false,
  val quantity: Int = 1,
  val extraCheese: Boolean = false,
) {
  val unitPrice: Long
    get() {
      val base = if (isPremiumSize && menuItem.premiumPrice > 0L) menuItem.premiumPrice else menuItem.price
      return base + if (extraCheese) 60L else 0L
    }

  val lineTotal: Long
    get() = unitPrice * quantity

  val sizeLabel: String
    get() = if (menuItem.category == "pizza") {
      if (isPremiumSize) "12\" Premium" else "8\" Regular"
    } else {
      if (isPremiumSize) "Large Combo" else "Standard"
    }
}

object StoreInfo {
  const val BRAND_NAME = "Pizza Hub"
  const val SUBTITLE = "Sylhet Signature"
  const val ADDRESS = "G-66, Eastern Plaza, Ambarkhana, Sylhet"
  const val PHONE = "01974378075"
  const val EMAIL = "pizzahubsylhet.com@gmail.com"
  const val WEBSITE = "pizzahubsylhet.com"
  const val HOURS = "Sat-Thu: 11 AM - 11 PM | Fri: 3 PM - 11 PM"
  const val BOOTSTRAP_ADMIN_EMAIL = "monkeydesignersagency@gmail.com"
}

object SylhetLocations {
  const val KITCHEN_LAT = 24.9036
  const val KITCHEN_LNG = 91.8697
  const val DEFAULT_DEST_LAT = 24.8949
  const val DEFAULT_DEST_LNG = 91.8687

  private val neighborhoodCoords = listOf(
    "ambarkhana" to (24.9046 to 91.8716),
    "zindabazar" to (24.8949 to 91.8687),
    "shibganj" to (24.8975 to 91.8842),
    "upashahar" to (24.8898 to 91.8825),
    "kumarpara" to (24.8970 to 91.8758),
    "mirabazar" to (24.8941 to 91.8794),
    "subidbazar" to (24.9082 to 91.8569),
    "tilagor" to (24.8978 to 91.9035),
    "chowhatta" to (24.8992 to 91.8691),
    "bondor" to (24.8914 to 91.8688),
  )

  fun resolveAddressLatLng(address: String): Pair<Double, Double> {
    val lower = address.lowercase()
    return neighborhoodCoords.firstOrNull { (area, _) -> lower.contains(area) }?.second
      ?: (DEFAULT_DEST_LAT to DEFAULT_DEST_LNG)
  }

  fun distanceKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lng2 - lng1)
    val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
      kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
      kotlin.math.sin(dLng / 2) * kotlin.math.sin(dLng / 2)
    val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
    return earthRadiusKm * c
  }
}

object DefaultMenuCatalog {
  val items: List<MenuItem> = listOf(
    MenuItem(
      id = "pizza_cheese_blast",
      name = "Cheese Blast Pizza",
      description = "Pizza Hub Sylhet's signature stone-baked crust loaded with double melted mozzarella, creamy cheddar burst, herb-marinated grilled chicken, and house tomato basil sauce.",
      category = "pizza",
      price = 420L,
      premiumPrice = 690L,
      imageKey = "img_pizza_category",
      ingredients = listOf(
        "Hand-stretched pan dough",
        "Double mozzarella & cheddar",
        "Herb-grilled chicken",
        "House tomato basil sauce",
        "Oregano & garlic butter",
      ),
      servingSize = "2 Slices (250g)",
      calories = 640L,
      proteinGrams = 31L,
      carbsGrams = 56L,
      fatGrams = 32L,
      available = true,
      prepMinutes = 20L,
      isVeg = false,
      ratingAvg = 4.9,
      reviewCount = 48L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "pizza_bbq_more",
      name = "BBQ & More Pizza",
      description = "Smoky hickory BBQ glaze topped with tender roasted chicken cubes, sliced smoked chicken sausage, fresh green chili, caramelized red onions, and gooey mozzarella.",
      category = "pizza",
      price = 460L,
      premiumPrice = 740L,
      imageKey = "img_hero_pizzahub",
      ingredients = listOf(
        "Smoky hickory BBQ sauce",
        "Char-roasted chicken",
        "Smoked chicken sausage",
        "Red onions & green chili",
        "Whole-milk mozzarella",
      ),
      servingSize = "2 Slices (260g)",
      calories = 615L,
      proteinGrams = 30L,
      carbsGrams = 60L,
      fatGrams = 27L,
      available = true,
      prepMinutes = 22L,
      isVeg = false,
      ratingAvg = 4.8,
      reviewCount = 36L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "pizza_mexican_hot",
      name = "Mexican Hot Pizza",
      description = "Fiery chipotle-spiced chicken, sliced button mushrooms, crisp bell capsicum, crushed red chili flakes, and golden stretchy mozzarella baked to perfection.",
      category = "pizza",
      price = 450L,
      premiumPrice = 720L,
      imageKey = "img_pizza_category",
      ingredients = listOf(
        "Chipotle spiced chicken",
        "Fresh button mushrooms",
        "Crisp green capsicum",
        "Crushed red chili flakes",
        "Mozzarella & marinara sauce",
      ),
      servingSize = "2 Slices (245g)",
      calories = 585L,
      proteinGrams = 28L,
      carbsGrams = 57L,
      fatGrams = 26L,
      available = true,
      prepMinutes = 20L,
      isVeg = false,
      ratingAvg = 4.7,
      reviewCount = 29L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "pizza_bombay_blast",
      name = "Bombay Blast Pizza",
      description = "Ambarkhana crowd favorite blending smoky chicken sausage, earthy mushrooms, tangy Bombay chili zest, diced tomatoes, and Pizza Hub's signature special sauce.",
      category = "pizza",
      price = 480L,
      premiumPrice = 760L,
      imageKey = "img_hero_pizzahub",
      ingredients = listOf(
        "Bombay chili zest",
        "Smoky chicken sausage",
        "Sauteed mushrooms",
        "House signature sauce",
        "Aged mozzarella blend",
      ),
      servingSize = "2 Slices (265g)",
      calories = 650L,
      proteinGrams = 29L,
      carbsGrams = 59L,
      fatGrams = 31L,
      available = true,
      prepMinutes = 22L,
      isVeg = false,
      ratingAvg = 4.9,
      reviewCount = 41L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "pizza_veggies",
      name = "Veggies Garden Pizza",
      description = "Loaded garden harvest of Kalamata-style black olives, fresh button mushrooms, sweet bell capsicum, crisp red onions, and golden herb mozzarella on crisp dough.",
      category = "pizza",
      price = 360L,
      premiumPrice = 590L,
      imageKey = "img_pizza_category",
      ingredients = listOf(
        "Black olives",
        "Button mushrooms",
        "Sweet bell capsicum",
        "Red onions & sweet corn",
        "Herb mozzarella & tomato sauce",
      ),
      servingSize = "2 Slices (230g)",
      calories = 470L,
      proteinGrams = 19L,
      carbsGrams = 54L,
      fatGrams = 19L,
      available = true,
      prepMinutes = 18L,
      isVeg = true,
      ratingAvg = 4.6,
      reviewCount = 19L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "pizza_big_shot",
      name = "Big Shot Sausage Pizza",
      description = "Double savory smoked chicken sausage layered over rich cheddar cheese drizzle, dried oregano, and Pizza Hub's crisp golden pan crust.",
      category = "pizza",
      price = 440L,
      premiumPrice = 710L,
      imageKey = "img_hero_pizzahub",
      ingredients = listOf(
        "Double chicken sausage",
        "Rich cheddar drizzle",
        "Mozzarella cheese",
        "Oregano & black pepper",
        "Crisp pan crust",
      ),
      servingSize = "2 Slices (255g)",
      calories = 630L,
      proteinGrams = 28L,
      carbsGrams = 55L,
      fatGrams = 33L,
      available = true,
      prepMinutes = 20L,
      isVeg = false,
      ratingAvg = 4.8,
      reviewCount = 24L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "burger_smash_hub",
      name = "Hub Signature Smash Burger",
      description = "Two juicy seared beef patties with crisp lacy edges, double molten cheddar slices, sweet caramelized onions, pickles, and house burger sauce in a buttered brioche bun.",
      category = "burger",
      price = 320L,
      premiumPrice = 440L,
      imageKey = "img_burger_category",
      ingredients = listOf(
        "Double smashed beef patties",
        "Molten cheddar cheese",
        "Caramelized onions",
        "Dill pickles & house sauce",
        "Buttered brioche bun",
      ),
      servingSize = "1 Burger (285g)",
      calories = 690L,
      proteinGrams = 38L,
      carbsGrams = 42L,
      fatGrams = 40L,
      available = true,
      prepMinutes = 15L,
      isVeg = false,
      ratingAvg = 4.9,
      reviewCount = 33L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "burger_crispy_chicken",
      name = "Loaded Crispy Chicken Burger",
      description = "Crunchy spiced chicken breast fillet paired with creamy roasted garlic aioli, tangy jalapenos, cheddar slice, crisp iceberg lettuce, and toasted sesame bun.",
      category = "burger",
      price = 260L,
      premiumPrice = 370L,
      imageKey = "img_burger_category",
      ingredients = listOf(
        "Crispy spiced chicken fillet",
        "Roasted garlic aioli",
        "Pickled jalapenos",
        "Aged cheddar & iceberg lettuce",
        "Toasted sesame bun",
      ),
      servingSize = "1 Burger (250g)",
      calories = 560L,
      proteinGrams = 29L,
      carbsGrams = 48L,
      fatGrams = 28L,
      available = true,
      prepMinutes = 14L,
      isVeg = false,
      ratingAvg = 4.7,
      reviewCount = 27L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "sandwich_club_grill",
      name = "Ambarkhana Club Grill Sandwich",
      description = "Triple-decker golden toasted club layered with herb-grilled chicken breast, fried farm egg, aged cheddar, crisp cucumber, tomato, and house mayo with seasoned fries.",
      category = "sandwich",
      price = 240L,
      premiumPrice = 340L,
      imageKey = "img_sandwich_category",
      ingredients = listOf(
        "Triple-decker toasted bread",
        "Herb-grilled chicken",
        "Farm-fresh fried egg",
        "Cheddar cheese & lettuce",
        "Tomato, cucumber & seasoned fries",
      ),
      servingSize = "1 Club + Fries (310g)",
      calories = 520L,
      proteinGrams = 31L,
      carbsGrams = 49L,
      fatGrams = 22L,
      available = true,
      prepMinutes = 12L,
      isVeg = false,
      ratingAvg = 4.8,
      reviewCount = 22L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "sandwich_smoked_sub",
      name = "Smoked Chicken Sub Sandwich",
      description = "Warm artisan sub roll stuffed generously with smoky grilled chicken strips, melted mozzarella, sweet corn, crisp greens, and smoky chipotle mayo.",
      category = "sandwich",
      price = 220L,
      premiumPrice = 310L,
      imageKey = "img_sandwich_category",
      ingredients = listOf(
        "Warm artisan sub roll",
        "Smoky grilled chicken strips",
        "Melted mozzarella cheese",
        "Smoky chipotle mayo",
        "Crisp lettuce & sweet corn",
      ),
      servingSize = "1 Sub (240g)",
      calories = 445L,
      proteinGrams = 27L,
      carbsGrams = 44L,
      fatGrams = 17L,
      available = true,
      prepMinutes = 12L,
      isVeg = false,
      ratingAvg = 4.7,
      reviewCount = 15L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "sides_baked_pasta",
      name = "Oven-Baked Chicken Pasta",
      description = "Velvety roasted-garlic Alfredo penne tossed with seasoned grilled chicken, mushrooms, and oregano, oven-baked beneath a bubbly golden crust of mozzarella.",
      category = "sides",
      price = 310L,
      premiumPrice = 420L,
      imageKey = "img_hero_pizzahub",
      ingredients = listOf(
        "Al-dente penne pasta",
        "Roasted garlic Alfredo sauce",
        "Seasoned grilled chicken",
        "Sliced mushrooms",
        "Bubbly baked mozzarella",
      ),
      servingSize = "1 Bowl (320g)",
      calories = 610L,
      proteinGrams = 32L,
      carbsGrams = 58L,
      fatGrams = 28L,
      available = true,
      prepMinutes = 18L,
      isVeg = false,
      ratingAvg = 4.8,
      reviewCount = 28L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
    MenuItem(
      id = "sides_garlic_fries",
      name = "Cheesy Garlic Bread & Fries",
      description = "Crispy golden hand-cut fries paired with oven-toasted herb garlic bread brushed with parsley butter and served with Pizza Hub creamy house dip.",
      category = "sides",
      price = 160L,
      premiumPrice = 230L,
      imageKey = "img_sandwich_category",
      ingredients = listOf(
        "Golden crispy fries",
        "Oven-toasted garlic bread",
        "Parsley garlic butter",
        "Melted mozzarella sprinkle",
        "Creamy house garlic dip",
      ),
      servingSize = "1 Platter (210g)",
      calories = 410L,
      proteinGrams = 11L,
      carbsGrams = 48L,
      fatGrams = 19L,
      available = true,
      prepMinutes = 10L,
      isVeg = true,
      ratingAvg = 4.6,
      reviewCount = 18L,
      version = 1L,
      updatedBy = "catalog_seed",
    ),
  )
}
