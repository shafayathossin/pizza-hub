package com.example.data.remote

import android.content.Context
import com.example.R
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings

object FirestoreProvider {
  @Volatile
  private var configuredDb: FirebaseFirestore? = null

  fun getDb(context: Context): FirebaseFirestore {
    configuredDb?.let { return it }
    synchronized(this) {
      configuredDb?.let { return it }
      val appContext = context.applicationContext
      val databaseId = appContext.getString(R.string.firestore_database_id)
      val db = FirebaseFirestore.getInstance(databaseId)
      try {
        // Enable durable disk persistence for offline mode and low-connectivity sync
        val cacheSettings = PersistentCacheSettings.newBuilder()
          .setSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
          .build()
        db.firestoreSettings = FirebaseFirestoreSettings.Builder()
          .setLocalCacheSettings(cacheSettings)
          .build()
      } catch (_: IllegalStateException) {
        // Settings were already applied on this instance
      }
      configuredDb = db
      return db
    }
  }
}
