package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.MenuItem
import com.example.data.model.Order
import com.example.data.model.Review
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class PizzaHubRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun ensureUserProfile_and_placeOrder_succeedsForAuthenticatedOwner() = runBlocking {
    val uid = signInTestUser(ALICE_EMAIL)
    val repo = PizzaHubRepository(firestore, auth)

    val profileResult = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.ensureUserProfile(uid, "Alice Rahman", ALICE_EMAIL)
    }
    assertTrue(profileResult.isSuccess)

    val order = Order(
      userId = uid,
      customerName = "Alice Rahman",
      customerPhone = "01974378075",
      deliveryAddress = "Zindabazar, Sylhet",
      itemsSummary = "1x Cheese Blast Pizza (8\" Regular)",
      itemCount = 1L,
      subtotal = 420L,
      deliveryFee = 50L,
      discount = 50L,
      totalAmount = 420L,
      paymentMethod = "bkash",
      paymentStatus = "paid",
      paymentRef = "BK-${UUID.randomUUID().toString().take(8)}",
      riderLat = 24.9036,
      riderLng = 91.8697,
      destinationLat = 24.8949,
      destinationLng = 91.8687,
      etaMinutes = 35L,
      deliveryNotes = "Call at gate",
    )

    val orderId = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.placeOrder(order, ALICE_EMAIL).getOrThrow()
    }
    assertTrue(orderId.isNotBlank())

    val observed = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeCustomerOrders(uid).first { snap -> snap.items.any { it.id == orderId } }
    }
    val placedOrder = observed.items.firstOrNull { it.id == orderId }
    assertNotNull(placedOrder)
    assertEquals("placed", placedOrder?.orderStatus)
    assertEquals(24.9036, placedOrder?.riderLat ?: 0.0, 0.0001)
    assertEquals(91.8687, placedOrder?.destinationLng ?: 0.0, 0.0001)

    val history = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeUserOrderHistory(uid).first { snap -> snap.items.any { it.orderId == orderId } }
    }
    assertTrue(history.items.any { it.orderId == orderId && it.totalAmount == 420L })

    val favAddRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.toggleFavoriteMenuItem(uid, "pizza_cheese_blast", true)
    }
    assertTrue(favAddRes.isSuccess)
    val updatedProfile = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeUserProfile(uid).first { it != null && it.favoriteItemIds.contains("pizza_cheese_blast") }
    }
    assertTrue(updatedProfile?.favoriteItemIds?.contains("pizza_cheese_blast") == true)
  }

  @Test
  fun getOrderById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = PizzaHubRepository(firestore, auth)
    val orderId = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.placeOrder(
        Order(
          userId = aliceUid,
          customerName = "Alice",
          customerPhone = "01974378075",
          deliveryAddress = "Ambarkhana, Sylhet",
          itemsSummary = "1x BBQ & More Pizza",
          itemCount = 1L,
          subtotal = 460L,
          deliveryFee = 50L,
          totalAmount = 510L,
          paymentMethod = "cod",
          paymentStatus = "pending",
        ),
        ALICE_EMAIL,
      ).getOrThrow()
    }

    signInTestUser(BOB_EMAIL)
    val bobRepo = PizzaHubRepository(firestore, auth)
    val result = withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.getOrderById(orderId) }
    assertTrue(result.isFailure)
    val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
    assertNotNull(fsEx)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
  }

  @Test
  fun upsertMenuItem_nonAdminCustomer_failsWithPermissionDenied() = runBlocking {
    val bobUid = signInTestUser(BOB_EMAIL)
    val bobRepo = PizzaHubRepository(firestore, auth)
    val result = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.upsertMenuItem(
        itemId = "unauthorized_pizza_${UUID.randomUUID().toString().take(6)}",
        item = MenuItem(name = "Free Pizza", category = "pizza", price = 1L),
        adminUid = bobUid,
        actorEmail = BOB_EMAIL,
      )
    }
    assertTrue(result.isFailure)
    val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
    assertNotNull(fsEx)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
  }

  @Test
  fun submitReview_authenticatedUser_createsAndObservesReview() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val repo = PizzaHubRepository(firestore, auth)
    val reviewId = withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.submitReview(
        Review(
          userId = aliceUid,
          authorName = "Alice Rahman",
          menuItemId = "pizza_cheese_blast",
          menuItemName = "Cheese Blast Pizza",
          rating = 5L,
          comment = "Hot cheesy crust right from Eastern Plaza!",
          orderId = "ord_test",
        )
      ).getOrThrow()
    }
    val reviews = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeReviews().first { list -> list.any { it.id == reviewId } }
    }
    assertTrue(reviews.any { it.id == reviewId && it.rating == 5L })
  }

  @Test
  fun observeCustomerOrders_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = PizzaHubRepository(firestore, auth)
    var caught: Exception? = null
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observeCustomerOrders("fake_uid").first() }
    } catch (e: Exception) {
      caught = e
    }
    val fsEx = caught?.unwrapFirestoreException()
    assertNotNull("Expected nested FirebaseFirestoreException, got $caught", fsEx)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
  }

  @Test
  fun observeUserOrderHistory_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = PizzaHubRepository(firestore, auth)
    var caught: Exception? = null
    try {
      withTimeout(FLOW_TIMEOUT_MS) { repo.observeUserOrderHistory("fake_uid").first() }
    } catch (e: Exception) {
      caught = e
    }
    val fsEx = caught?.unwrapFirestoreException()
    assertNotNull("Expected nested FirebaseFirestoreException, got $caught", fsEx)
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
  }

  private companion object {
    const val ALICE_EMAIL = "alice.pizzahub@test.com"
    const val BOB_EMAIL = "bob.pizzahub@test.com"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
