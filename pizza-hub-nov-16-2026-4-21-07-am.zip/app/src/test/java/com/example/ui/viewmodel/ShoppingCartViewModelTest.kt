package com.example.ui.viewmodel

import com.example.data.model.MenuItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ShoppingCartViewModelTest {

  private val testDispatcher = StandardTestDispatcher()
  private lateinit var viewModel: ShoppingCartViewModel

  private val pizza = MenuItem(
    id = "pizza_1",
    name = "Cheese Blast Pizza",
    category = "pizza",
    description = "Loaded with melted mozzarella and cheddar",
    price = 420L,
    premiumPrice = 680L,
    imageUrl = "https://pizzahubsylhet.com/images/cheese-blast.jpg",
  )

  private val burger = MenuItem(
    id = "burger_1",
    name = "Smoky Beef Burger",
    category = "burger",
    description = "Chargrilled patty with house sauce",
    price = 280L,
    premiumPrice = 380L,
    imageUrl = "https://pizzahubsylhet.com/images/smoky-burger.jpg",
  )

  @Before
  fun setUp() {
    Dispatchers.setMain(testDispatcher)
    viewModel = ShoppingCartViewModel()
  }

  @After
  fun tearDown() {
    Dispatchers.resetMain()
  }

  @Test
  fun addItem_combinesIdenticalVariants_andSeparatesDistinctVariants() {
    viewModel.addItem(pizza, isPremiumSize = false, extraCheese = false, quantity = 1)
    viewModel.addItem(pizza, isPremiumSize = false, extraCheese = false, quantity = 2)
    viewModel.addItem(pizza, isPremiumSize = true, extraCheese = true, quantity = 1)

    val items = viewModel.items.value
    assertEquals(2, items.size)
    assertEquals(3, items[0].quantity)
    assertEquals(1, items[1].quantity)
  }

  @Test
  fun updateQuantity_and_removeItem_updatesCartState() {
    viewModel.addItem(pizza)
    viewModel.addItem(burger)

    val burgerEntry = viewModel.items.value.first { it.menuItem.id == "burger_1" }
    viewModel.updateQuantity(burgerEntry, delta = 1)
    assertEquals(2, viewModel.items.value.first { it.menuItem.id == "burger_1" }.quantity)

    val updatedBurger = viewModel.items.value.first { it.menuItem.id == "burger_1" }
    viewModel.removeItem(updatedBurger)
    assertEquals(1, viewModel.items.value.size)
    assertEquals("pizza_1", viewModel.items.value.single().menuItem.id)
  }

  @Test
  fun decrementOrRemoveMenuItem_and_clearCart_removesItemsProperly() {
    viewModel.addItem(pizza, quantity = 2)
    viewModel.decrementOrRemoveMenuItem("pizza_1")
    assertEquals(1, viewModel.items.value.single().quantity)

    viewModel.decrementOrRemoveMenuItem("pizza_1")
    assertTrue(viewModel.items.value.isEmpty())

    viewModel.addItem(burger)
    viewModel.clearCart()
    assertTrue(viewModel.items.value.isEmpty())
  }

  @Test
  fun applyPromoCode_updatesDiscountAndFinalTotal_andValidatesCodes() = runTest(testDispatcher) {
    val job = backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
      viewModel.uiState.collect()
    }

    // 1x pizza = 420, delivery = 50 -> total 470
    viewModel.addItem(pizza, quantity = 1)
    advanceUntilIdle()
    assertEquals(420L, viewModel.uiState.value.subtotal)
    assertEquals(470L, viewModel.uiState.value.total)

    // PIZZA100 requires >= 500 subtotal
    val lowSubtotalRes = viewModel.applyPromoCode("PIZZA100")
    advanceUntilIdle()
    assertTrue(lowSubtotalRes is PromoFeedback.Error)
    assertEquals(0L, viewModel.uiState.value.discount)

    // HUB10 gives 10% off 420 = 42 -> total = 420 + 50 - 42 = 428
    val hub10Res = viewModel.applyPromoCode("hub10")
    advanceUntilIdle()
    assertTrue(hub10Res is PromoFeedback.Applied)
    assertEquals("HUB10", viewModel.uiState.value.appliedPromoCode)
    assertEquals(42L, viewModel.uiState.value.discount)
    assertEquals(428L, viewModel.uiState.value.total)

    // Add burger (280) -> subtotal = 700, HUB10 recalculates to 70, delivery = 50 -> total = 680
    viewModel.addItem(burger, quantity = 1)
    advanceUntilIdle()
    assertEquals(700L, viewModel.uiState.value.subtotal)
    assertEquals(70L, viewModel.uiState.value.discount)
    assertEquals(680L, viewModel.uiState.value.total)

    // Apply PIZZA100 now that subtotal >= 500 -> discount = 100, total = 650
    val pizza100Res = viewModel.applyPromoCode("PIZZA100")
    advanceUntilIdle()
    assertTrue(pizza100Res is PromoFeedback.Applied)
    assertEquals(100L, viewModel.uiState.value.discount)
    assertEquals(650L, viewModel.uiState.value.total)

    // Invalid code should fail and preserve valid applied discount
    val invalidRes = viewModel.applyPromoCode("NOPE999")
    advanceUntilIdle()
    assertTrue(invalidRes is PromoFeedback.Error)
    assertEquals("PIZZA100", viewModel.uiState.value.appliedPromoCode)

    // Remove promo clears discount & feedback
    viewModel.removePromoCode()
    advanceUntilIdle()
    assertEquals(0L, viewModel.uiState.value.discount)
    assertEquals(750L, viewModel.uiState.value.total)
    assertNull(viewModel.promoFeedback.value)

    job.cancel()
  }
}
